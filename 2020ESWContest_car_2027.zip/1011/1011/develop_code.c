/*******************************************************************************
 *  INCLUDE FILES
 *******************************************************************************
 */
//#include <termios.h>
//#include <unistd.h> 
//#include <fcntl.h>
//#include <sys/signal.h>
#include <sys/types.h>
#include <time.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "car_lib.h"
#include <math.h>

/*******************************************************************************
 *  Defines
 *******************************************************************************
 */


/*******************************************************************************
 *  Functions
 *******************************************************************************
 */
unsigned char status;
short speed;
unsigned char gain;
int position, posInit, posDes, posRead;
short angle;
//int channel;
//int data;
char sensor;
int tol;
//char byte = 0x80;


int dist_milli(int sensor_num)	// Made by Realbro, optimization
{
	double data_centi;
	int data;
	data = DistanceSensor(sensor_num);

	switch (sensor_num) {
	case 1:
		data_centi = exp((-(double)data + 4219.8) / 1187) + 3;
		//printf("data=%d", data);
		//printf("distance= %fcm\n", data_centi);
		break;
	case 2:
		data_centi = exp((4409.5 - (double)data) / 1244) + 3;
		//printf("data=%d", data);
		//printf("distance= %fcm\n", data_centi);
		break;
	case 3:
		data_centi = exp((4740.6 - (double)data) / 1431) + 3;
		//printf("data=%d", data);
		//printf("distance= %fcm\n", data_centi);
		break;
	case 4:
		data_centi = exp((4199.8 - (double)data) / 1207) + 3;
		//printf("data=%d", data);
		//printf("distance= %fcm\n", data_centi);
		break;
	case 5:
		data_centi = exp((4336.4 - (double)data) / 1129) + 3;
		//printf("data=%d", data);
		//printf("distance= %fcm\n", data_centi);
		break;
	case 6:
		data_centi = exp((4366.2 - (double)data) / 1124) + 3;
		//printf("data=%d", data);
		//printf("distance= %fcm\n", data_centi);
		break;
	}

	return data_centi*10;
}

double dist_centi(int sensor_num)	// New version _ Modified by Realbro
{
	double data_centi;
	int data;
    data = DistanceSensor(sensor_num);
    //printf("channel = %d, distance = 0x%04X(%d) \n", channel, data, data);
    usleep(10000);

    //avg[j]=distance;
    

    switch(sensor_num){
    	case 1:
		    data_centi = exp((-(double)data+4219.8)/1187)+3;
		    printf("data=%d",data);
		    printf("distance= %fcm\n",data_centi);
    		break;
    	case 2:
		    data_centi = exp((4409.5-(double)data)/1244)+3;
		    printf("data=%d",data);
		    printf("distance= %fcm\n",data_centi);
    		break;
    	case 3:
		    data_centi = exp((4740.6-(double)data)/1431)+3;
		    printf("data=%d",data);
		    printf("distance= %fcm\n",data_centi);
    		break;
    	case 4:
		    data_centi = exp((4199.8-(double)data)/1207)+3;
		    printf("data=%d",data);
		    printf("distance= %fcm\n",data_centi);
    		break;
    	case 5: 
		    data_centi = exp((4336.4-(double)data)/1129)+3;
		    printf("data=%d",data);
		    printf("distance= %fcm\n",data_centi);
	    	break;
    	case 6:
		    data_centi = exp((4366.2-(double)data)/1124)+3;
		    printf("data=%d",data);
		    printf("distance= %fcm\n",data_centi);
	    	break;
    }

    return data_centi;
   
}

// Old version
/*  
int dist_centi(int sensor_num)
{
double data;
int centi;
   switch(sensor_num)
   {
          case 1: data = DistanceSensor(1);
		  centi = exp((data- 4247.1)/(-1150))+3;
	         break;
          case 2: data = DistanceSensor(2);
		  centi = exp((data- 4391.4)/(-1219))+3;
	         break;
	  case 3: data = DistanceSensor(3);
		  centi = exp((data- 4230)/(-1177))+3;
	         break;
	  case 4: data = DistanceSensor(4);
		  centi = exp((data- 4259.1)/(-1226))+3;
	         break;
	  case 5: data = DistanceSensor(5);
		  centi = exp((data- 4284.1)/(-1087))+3;
	         break;
	  case 6: data = DistanceSensor(6);
		  centi = exp((data- 4290.8)/(-1089))+3;
	         break;
	  default: break;
     }

    return centi;
}
*/

void start()        
{
    for (;;)
    {
        if (dist_centi(1) < 5)
        {
            speed = 80;
            DesireSpeed_Write(speed);
            break;
        }
        usleep(100000);
    }
}










/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void V_Parking(void)//14~15sec
{
    unsigned char status;
    short speed;
    unsigned char gain;
    int position, posInit, posDes, posRead;
    short angle;
    int channel;
    int data;
    char sensor;
    int i, j;
    int tol;
    char byte = 0x80;
    int num_sensor;


    CarControlInit();

        PositionControlOnOff_Write(UNCONTROL); 
	status=SpeedControlOnOff_Read();
    	printf("SpeedControlOnOff_Read() = %d\n", status);
    	SpeedControlOnOff_Write(CONTROL);
    	gain = SpeedPIDProportional_Read();        // default value = 10, range : 1~50
    	printf("SpeedPIDProportional_Read() = %d \n", gain);
    	gain = 20;
    	SpeedPIDProportional_Write(gain);
    	gain = SpeedPIDIntegral_Read();        // default value = 10, range : 1~50
    	printf("SpeedPIDIntegral_Read() = %d \n", gain);
    	gain = 20;
	SpeedPIDIntegral_Write(gain);
	gain = SpeedPIDDifferential_Read();        // default value = 10, range : 1~50
	printf("SpeedPIDDefferential_Read() = %d \n", gain);
	gain = 20;
	SpeedPIDDifferential_Write(gain);

//-------------------------------------------intro

	speed = DesireSpeed_Read();
	angle = SteeringServoControl_Read();
	angle = 2000; 
	speed=100;
	for(;;)
	{
	     SteeringServoControl_Write(angle);
	     DesireSpeed_Write(speed);
	     usleep(10000);
	     if(dist_centi(3)>29)
	     {		


	DesireSpeed_Write(0);
	usleep(100000);
	speed= -65;
	angle = 1125;
   
	for(;;)
	{

	     SteeringServoControl_Write(angle);
	     DesireSpeed_Write(speed);
	     CarLight_Write(REAR_ON);
	     usleep(10000);
	     if(dist_centi(5)<20)
	     {		
			CarLight_Write(ALL_OFF);
			speed= 0;
			DesireSpeed_Write(speed);
			usleep(100000);
			speed=65;
		        for(;;)
		        {   
	     			 angle += 100; 
	     		         SteeringServoControl_Write(angle);
				 DesireSpeed_Write(speed);
				 usleep(10000); 
				if(dist_centi(2) == dist_centi(3))
	     			{
					speed= 0;
					angle = 1500;
					DesireSpeed_Write(speed);
					SteeringServoControl_Write(angle);
					usleep(100000);
					speed=-60;
		                        for(;;)
		                       { 
					  DesireSpeed_Write(speed);						
					  CarLight_Write(REAR_ON);
					  usleep(10000);
		                           if(dist_centi(4)<12)
		                          {
						CarLight_Write(ALL_OFF);
								speed = 0;							
								DesireSpeed_Write(speed);
								usleep(100000);
								Alarm_Write(ON);
    								usleep(2000000);
    								Alarm_Write(OFF);
								goto  escape1;
						


					   }
		                        }
				 }
		         }
	      }
	} 
}
}
escape1:

        speed = 100;
	DesireSpeed_Write(speed);
        usleep(750000);
	
	angle = 1000;
 	speed = 100;
	SteeringServoControl_Write(angle);
	DesireSpeed_Write(speed);
        usleep(2100000);
	angle = 1500;

 	speed = 0;
	SteeringServoControl_Write(angle);
	DesireSpeed_Write(speed);
        usleep(1000000);
}








void H_Parking(void)//17sec
{
    unsigned char status;
    short speed;
    unsigned char gain;
    int position, posInit, posDes, posRead;
    short angle;
    int channel;
    int data;
    char sensor;
    int i, j;
    int tol;
    char byte = 0x80;
    int num_sensor;

    CarControlInit();

    PositionControlOnOff_Write(UNCONTROL); 
    status=SpeedControlOnOff_Read();
    printf("SpeedControlOnOff_Read() = %d\n", status);
    SpeedControlOnOff_Write(CONTROL);

    //speed controller gain set
    //P-gain
    gain = SpeedPIDProportional_Read();        // default value = 10, range : 1~50
    printf("SpeedPIDProportional_Read() = %d \n", gain);
    gain = 20;
    SpeedPIDProportional_Write(gain);

    //I-gain
    gain = SpeedPIDIntegral_Read();        // default value = 10, range : 1~50
    printf("SpeedPIDIntegral_Read() = %d \n", gain);
    gain = 20;
    SpeedPIDIntegral_Write(gain);
    
    //D-gain
    gain = SpeedPIDDifferential_Read();        // default value = 10, range : 1~50
    printf("SpeedPIDDefferential_Read() = %d \n", gain);
    gain = 20;
    SpeedPIDDifferential_Write(gain);




	speed = DesireSpeed_Read();
	angle = SteeringServoControl_Read();
	angle = 2000; 
	SteeringServoControl_Write(angle);
	usleep(100000);

	speed=150;


		        for(;;)
		        {   
	     			SteeringServoControl_Write(angle);
				DesireSpeed_Write(speed);
				usleep(10000); 
				if(dist_centi(3) > 29)
	     			{
					speed= 0;
					DesireSpeed_Write(speed);
					usleep(100000);
					angle = 1400;
					speed=-60;
 				 for(;;)
		        	{   
	     			  SteeringServoControl_Write(angle);
				  DesireSpeed_Write(speed);
				  CarLight_Write(REAR_ON);
				  usleep(10000); 
				  if(dist_centi(4)<21)
	     			  {
					CarLight_Write(ALL_OFF);
					speed= 0;
					DesireSpeed_Write(speed);
					usleep(100000);
					speed= -40;
					angle = 2000; 
					for(;;){
	     				  SteeringServoControl_Write(angle);
					  CarLight_Write(REAR_ON);
					  DesireSpeed_Write(speed);
					  usleep(10000); 
		                          if(dist_centi(4) ==4)
		                          
				           {
						/*speed= 0;
						angle = 1500;
						DesireSpeed_Write(speed);
						SteeringServoControl_Write(angle);
						CarLight_Write(ALL_OFF);
						usleep(100000);
						speed= 20;
		                                for(;;)
		                                { 
					          angle -= 200; 
	     				          SteeringServoControl_Write(angle);
						  DesireSpeed_Write(speed);
						  usleep(10000); 
				                  if(dist_centi(2) == dist_centi(3) || dist_centi(4)>17)
				                  {
				
							speed= 0;
							angle = 1500;
							DesireSpeed_Write(speed);
							SteeringServoControl_Write(angle);
							usleep(100000);
							speed=-35;
							for(;;)
							{
							 
							 CarLight_Write(REAR_ON);
						  	 DesireSpeed_Write(speed);
							 usleep(10000);
							 if(dist_centi(4)<7){*/
							 
							 							
								speed = 0;
								DesireSpeed_Write(speed);
								CarLight_Write(ALL_OFF);
								usleep(100000);
								Alarm_Write(ON);
	    							usleep(2000000);
	    							Alarm_Write(OFF);
								goto  escape1;
			
							/* }
							}*/			



					   }
		                        }
				 }
		         }
	      
	}
}

escape1:
	
	angle = 2000;
	SteeringServoControl_Write(angle);
	speed = 100;
	DesireSpeed_Write(speed);
	usleep(300000);

	angle = 1500;
	SteeringServoControl_Write(angle);
	speed = -100;
	DesireSpeed_Write(speed);
	usleep(300000);
	
	angle = 2000;
	SteeringServoControl_Write(angle);
	speed = 100;
	DesireSpeed_Write(speed);
	usleep(1000000);
	
	angle = 1500;
 	speed = 100;
	SteeringServoControl_Write(angle);
	DesireSpeed_Write(speed);
        usleep(500000);
	
	angle = 1000;
 	speed = 100;
	SteeringServoControl_Write(angle);
	DesireSpeed_Write(speed);
        usleep(1500000);
	
}








void traffic_turn_left()
{
	short traffic_speed;
	short traffic_angle;

	traffic_speed = 100;
	traffic_angle = 1500;
	SteeringServoControl_Write(traffic_angle);
	usleep(100000);
printf("1\n");
	for (;;)
	{
printf("2\n");
		DesireSpeed_Write(traffic_speed);
		usleep(10000);
		if (dist_centi(1) < 26)
		{
printf("3\n");
printf("distance : %d",dist_centi(1));
			traffic_speed = 0;
			DesireSpeed_Write(traffic_speed);
			usleep(100000);
			break;
		}
	}

printf("4\n");

	traffic_angle = 2000;
	SteeringServoControl_Write(traffic_angle);
	usleep(100000);
	traffic_speed = 100;
	DesireSpeed_Write(traffic_speed);
	usleep(2200000);
	traffic_speed = 0;
	DesireSpeed_Write(traffic_speed);
	traffic_angle = 1500;
	SteeringServoControl_Write(traffic_angle);
	usleep(100000);
	traffic_speed = 100;
	DesireSpeed_Write(traffic_speed);
	usleep(1400000);
	traffic_speed = 0;
	DesireSpeed_Write(traffic_speed);
	usleep(1000000);

}



void traffic_turn_right()
{
	short traffic_speed;
	short traffic_angle;

	traffic_speed = 100;
	traffic_angle = 1500;
	SteeringServoControl_Write(traffic_angle);
	usleep(100000);
printf("1\n");
DesireSpeed_Write(traffic_speed);
	for (;;)
	{
printf("2\n");
		
		usleep(10000);
		if (dist_centi(1) < 26)
		{	
printf("3\n");
			printf("distance : %d \n",dist_centi(1));
			traffic_speed = 0;
			DesireSpeed_Write(traffic_speed);
			usleep(100000);
			break;
		}
	}


printf("4\n");
	traffic_angle = 1000;
	SteeringServoControl_Write(traffic_angle);
	usleep(100000);
	traffic_speed = 100;
	DesireSpeed_Write(traffic_speed);
	usleep(2100000);
	traffic_speed = 0;
	DesireSpeed_Write(traffic_speed);
	traffic_angle = 1500;
	SteeringServoControl_Write(traffic_angle);
	usleep(100000);
	traffic_speed = 100;
	DesireSpeed_Write(traffic_speed);
	usleep(1300000);
	traffic_speed = 0;
	DesireSpeed_Write(traffic_speed);
	usleep(1000000);
}


