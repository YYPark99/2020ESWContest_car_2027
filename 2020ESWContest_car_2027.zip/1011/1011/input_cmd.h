#ifndef INPUT_CMD_H_
#define INPUT_CMD_H_ 

#ifdef __cplusplus
extern "C" {
#endif

extern char StandbyInput(char *inputbuf); 

#ifdef __cplusplus
}
#endif

#endif //INPUT_CMD_H_

