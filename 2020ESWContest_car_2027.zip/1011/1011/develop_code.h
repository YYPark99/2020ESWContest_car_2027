#ifndef DEVELOP_CODE_H
#define DEVELOP_CODE_H

#ifdef __cplusplus
extern "C" {
#endif

/*******************************************************************************
 *  Defines
 *******************************************************************************
 */
// #define OFF         0x00
// #define ON          0xFF

// // Light
// #define ALL_OFF     0x00
// #define REAR_ON     0x02
// #define FRONT_ON    0x01
// #define ALL_ON      0x03
// #define RIGHT_ON    0x01
// #define LEFT_ON     0x02

// // Speed and position controller setting
// #define UNCONTROL   0x00
// #define CONTROL     0x01
// #define CHECKSUMERROR 0xFEFE

/*******************************************************************************
 *  Functions
 *******************************************************************************
 */



void traffic_turn_right();
void traffic_turn_left();
void H_Parking(void);
void V_Parking(void);
double dist_centi(int sensor_num);
int dist_milli(int sensor_num);
void start();
//void highway();

//void tunnel();
//void parking();



#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif


/*@}*/
