/*
Update 2019.08.20.

중요변수들 포인터 변수로 변경 및 연동작업 완료

기존의 filter_lane_detector 함수의 사용에서
openCV_code 함수를 사용, opencv 단독으로 사용 할 때 main으로 이해하면 됨.

* Mat 에서 포인터 변수를 사용할 때 주의할 점
	img.copyTo()  에서 img가 포인터 변수일 때에는 다른 표현을 사용
	img->copyTo() 로 사용해야 됨.

*main.c 에서 정의된 변수들 (포인터 사용)
	int* pointer_driving_status = &driving_status;
	short* pointer_speed = &speed;
	short* pointer_angle = &angle;

	bool* pointer_steering_control = &steering_control;
	bool* pointer_stop_line_control = &stop_line_control;
	bool* pointer_cout_control = &cout_control;
*/
#include <iostream>
#include <stdio.h>
#include <string.h>
//#include <sys/time.h>
#include <math.h>
#include <opencv2/opencv.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
//#include <opencv2/gpu/device/utility.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/objdetect/objdetect.hpp>
#include "car_lib.h"
#include "develop_code.h"
#include <unistd.h>
#include <sstream>

#include <sys/types.h>
#include <dirent.h>

#define pi 3.1415926
#define PI 3.1415926





using namespace std;
using namespace cv;

extern "C" {

/**
  * @brief  To load image file to the buffer.
  * @param  file: pointer for load image file in local path
             outBuf: destination buffer pointer to load
             nw : width value of the destination buffer
             nh : height value of the destination buffer
  * @retval none
  */
	


void filter_lane_detector(Mat* input_img, Mat* output_img, Mat* img_out, Mat* img_grayline, bool* pointer_steering_control, bool* pointer_cout_control, int* pointer_lcd_control);
void filter_colors(Mat _img_bgr, Mat &img_filtered);
void filter_white_colors(Mat _img_bgr, Mat &img_filtered);
void mission_check(Mat input_img, Mat* img_out, int* pointer_driving_status, bool* pointer_steering_control, bool* pointer_cout_control, int* pointer_lcd_control);




void calculate_steering_angle(Mat input_img, Mat& output_img);
void calculate_steering_angle2(Mat input_img, Mat& output_img);
int calculate_steering_angle3(Mat input_img, Mat& output_img, bool steering_control_onoff);
	int lane_mode = 0;
int calculate_steering_angle4(Mat input_img, Mat& output_img, bool steering_control_onoff);
int calculate_steering_angle5(Mat input_img, Mat& output_img, bool steering_control_onoff);


// 2020-10-05 11 :31 AM 
int overtaking_lane_driving(Mat input_img, Mat& output_img);
char go_turn_right_overtaking(Mat input_img, Mat& output_img);

void WARP(Mat input_img, Mat& output_img);
void inRange_white(Mat input_img, Mat& output_img);
void inRange_yellow(Mat input_img, Mat &output_img);
void Hough_line(Mat input_img, Mat& output_img);
//int parking_check();

// 2020-10-10 09 :10 PM 
int parking_check(Mat input_img, Mat& output_img);
// 2020-10-10 04 :08 PM 
	bool step_1=0;
	bool step_2=0;
	bool step_3=0;
	int encoder_start=0;
	int encoder_end=0;

// 2020-10-10 11 :53 AM 
	int parking_length=0;
int V_parking(int parking_length, Mat input_img, Mat& output_img);
//void H_parking(int parking_length);
int H_parking(int parking_length, Mat input_img, Mat& output_img);
// 2020-10-10 06 :09 PM 
char parking_status = 0b00000000;
void distance_driving()	;
int distance_driving_2();
int distance_driving_3(int steering_control_onoff);
//int distance_driving_4(int steering_control_onoff);		// 2020-09-27 07:00 PM Add
int distance_driving_4(Mat input_img, Mat& output_img,int steering_control_onoff); // 2020-09-28 02 :50 AM 

		int pre_dist2 = 0;
		int pre_dist3 = 0;
		int pre_dist5 = 0;
		int pre_dist6 = 0;
		int pre_encoder = 0;

		short pre_speed=0;
		int pre_speed_check = 0;

// 2020-10-09 11 :40 PM 
int distance_driving_tunnel(Mat input_img, Mat& output_img,int steering_control_onoff);




//2020/09/07 09:50
void traffic_sign_new(Mat input_image, Mat* img_out);
		int traffic_step = 0;
		int red_left=0, yellow_left=0, left_left=0, right_left=0;
		int red_right=0, yellow_right=0, left_right=0, right_right=0;
		Rect red_roi;// = Rect(Point(red_left, max_row - (red_right - red_left) / 2), Point(red_right, max_row + (red_right - red_left) / 2));
		Rect yellow_roi;// = Rect(Point(yellow_left, max_row - (yellow_right - yellow_left) / 2), Point(yellow_right, max_row + (yellow_right - yellow_left) / 2));
		Rect left_roi;// = Rect(Point(left_left, max_row - (left_right - left_left) / 2), Point(left_right, max_row + (left_right - left_left) / 2));
		Rect right_roi;// = Rect(Point(right_left, max_row - (right_right - right_left) / 2), Point(right_right, max_row + (right_right - right_left) / 2));
		
int highway(Mat input_img, Mat& output_img);
		int highway_end_count = 0;
		//highway_end_count > 5  :  FINISH
		int highway_step = 0;	// 2020-09-28 02 :52 AM 



int tunnel(Mat input_img, Mat &output_img);
		int tunnel_end_count = 0;
		int tunnel_step = 0;
		// 2020-09-28 02 :00 PM 
		bool downhill_check = 0;



// 2020-10-04 06 :29 PM 
int overtaking(Mat input_img, Mat& output_img);

// 2020-10-10 07 :36 PM 
char go_straight(Mat input_img, Mat& output_img);

char go_turn_right(Mat input_img, Mat& output_img);


Mat make_line(Mat img, bool* pointer_steering_control, bool* pointer_cout_control);
void line_detector(Mat img);
void Find_curve_lane(Mat input_img1);
int find_stop_sign(Mat input_image);
int stop_line();
int round_rotary(Mat input_image, Mat& img_out);
// 2020-10-11 05 :26 AM 
char go_turn_right_rotary(Mat input_img, Mat& output_img);
int round_rotary_step = 0;


void traffic_sign(Mat input_image, Mat* img_out);
void capture(Mat input_img);
void fine_stopline(Mat input_img);
Mat RoI_triangle(Mat img);
Mat FIND_LINE(Mat img1, Mat img2);

int S_curve(Mat input_img, Mat& output_img, bool steering_control_onoff);




/// jinhyeong varialbls	///
int opencv_driving_status =0 ;

bool opencv_steering_control = 0;
bool opencv_stop_line_control = 0;
bool opencv_cout_control = 0;
int opencv_lcd_control = 0;





















/////////////////////////////////////////////////		test		///////////////////////////////////////////////////////////////
void encoder_test();
void speed_encoder_test();






/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////









int Hough_line_val=0;
float rho = 2; // distance resolution in pixels of the Hough grid
float theta = 1 * CV_PI / 180; // angular resolution in radians of the Hough grid
float hough_threshold = 15;	 // minimum number of votes(intersections in Hough grid cell)
float minLineLength = 10; //minimum number of pixels making up a line
float maxLineGap = 20;	//maximum gap in pixels between connectable line segments


int left_lane;
int right_lane;


//int left1_start, left1_end, left2_start, left2_end, left3_start, left3_end, left4_start, left4_end;
int left1_start=0;
int left1_end=60;
  
int left2_start=0;
int left2_end=60;
  
int left3_start=0;
int left3_end=60;
 

bool left1=0, left2=0, left3=0, right1=0, right2=0, right3=0;
bool layer4=0, layer5=0;
bool high_bool=0, low_bool=0;
bool lane_middle = 0;


int left1_x, left2_x, left3_x, right1_x, right2_x, right3_x;
  
Point high, low;
int low_x=0;
int high_x=0;
  
  
int layer_1=65;
int layer_2=layer_1-2;
int layer_3=layer_2-2;

int layer_4=80;	//85
int layer_5=110;

bool turn_left = 0;
bool turn_right = 0;



/*round rotary*/
Mat img_pre;
int safety_counter = 0;		// 안전하게 회전 교차로를 진입하기 위해, 안전한 상황이 맞는지 판단하는 변수

/*traffic*/
Rect red;
Rect yellow;
Rect green_left;
Rect green_right;
Point upper, lower, middle[8];
bool traffic_find = 1;
bool traffic_servo = 1;
int cam_counter = 0;




int capture_num = 0;


int angle=1500;

int stop_line_counter = 0;
Mat follow(Mat input_img);

int red_find = 0;
string mission;


// Add 0804 // show distance
Point dist_pt[6]={Point(140, 40), Point(210, 70), Point(210, 130),Point(140, 160),Point(90, 130),Point(90, 70)};
// dist_pt[0] = Point(140, 40);
// dist_pt[1] = Point(210, 70);
// dist_pt[2] = Point(210, 130);
// dist_pt[3] = Point(140, 160);
// dist_pt[4] = Point(90, 130);
// dist_pt[5] = Point(90, 70);
///////////////

// Add 0807 // show red_count
bool red_count_global_bool = 0;
int red_count_global;

// Add 0808 // more develop find_stop_sign()
int lane_distance=300;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





// Add 2020-09-28 01 :50 PM 
short main_speed = 200;
int gloabal_encoder_read=0;



// 2020-10-09 09 :23 PM 
bool auto_status = 0;


// 2020-10-09 09 :43 PM 
int S_curve_step = 0;

int parking_detect = 0;





// 2020-10-11 07 :50 AM 
int go_turn_right_overtaking_mode = 0;
char go_turn_right_overtaking(Mat input_img, Mat& output_img)
{
	//input_img 는 color 이미지 입력받아야함


	Mat img;
	input_img.copyTo(img);


	//이미지 표시용 Mat 선언
	Mat img_line;
	input_img.copyTo(img_line);

	int steering_angle = 1507;

	if(go_turn_right_overtaking_mode == 0)
	{
		Mat img_yellow;
		Mat img_warp;

		inRange_yellow(img, img_yellow);
		WARP(img_yellow, img_warp);

		Mat img_warp_rotate(img.cols,img.rows,CV_8UC1);
		
		for (int i = 0; i < img.cols;i++)	//rows
		{
			uchar* img_warp_rotate_pointer_row = img_warp_rotate.ptr<uchar>(i);
			for (int j = 0; j < img.rows;j++)	//cols
			{
				img_warp_rotate_pointer_row[j] = img_warp.at<uchar>(179-j,i);
			}
		}

		img_warp.copyTo(img_line);
		cvtColor(img_line, img_line, COLOR_GRAY2BGR);
		//보조선
//		cvtColor(img_line, img_line, COLOR_GRAY2BGR);
		line(img_line, Point2f(0, 70), Point2f(320, 70), Scalar(0, 255, 255), 2);
		line(img_line, Point2f(160, 90), Point2f(160, 180), Scalar(255, 0, 255), 2);

		// 직진 차선 검출용
		line(img_line, Point2f(9, 70), Point2f(149, 70), Scalar(0, 255, 0), 2);
		line(img_line, Point2f(169, 70), Point2f(309, 70), Scalar(0, 255, 0), 2);

		// 직진 차선 중앙 유지용
		line(img_line, Point2f(52, 60), Point2f(52, 80), Scalar(0, 0, 255), 2);
		line(img_line, Point2f(267, 60), Point2f(267, 80), Scalar(0, 0, 255), 2);


		bool curve_check = 0, left_check = 0, right_check = 0;
		int curve_y = 0, left_x = 0, right_x = 0;

		double angle = 0;

		

		//커브 검출
		uchar* curve_pointer_row = img_warp_rotate.ptr<uchar>(160);
		for (int col = 0; col < 179; col++)
		{
			uchar color1 = curve_pointer_row[col];
			uchar color2 = curve_pointer_row[col+1];
			//printf("%d ", color);
			if (color1 > 0 && color2 >0)
			{
				printf("CURVE OK\n");
				curve_check = 1;
				curve_y = col;
				circle(img_line, Point(160, 180 - col), 5, Scalar(0, 0, 255), -1);
				break;
			}
		}


		//직진 차선 검출 왼쪽
		uchar* left_pointer_row = img_warp.ptr<uchar>(70);
		for (int col = 9; col < 149; col += 2)
		{
			uchar color1 = left_pointer_row[col];
			uchar color2 = left_pointer_row[col + 1];
			//printf("%d ", color);
			if (color1 > 0 && color2 > 0)
			{
				printf("LEFT OK\n");
				left_check = 1;
				left_x = col;
				circle(img_line, Point(col, 70), 5, Scalar(0, 0, 255), -1);
				break;
			}
		}


		//직진 차선 검출 오른쪽
		uchar* right_pointer_row = img_warp.ptr<uchar>(70);
		for (int col = 309; col > 169; col -= 2)
		{
			uchar color1 = right_pointer_row[col];
			uchar color2 = right_pointer_row[col - 1];
			//printf("%d ", color);
			if (color1 > 0 && color2 > 0)
			{
				right_check = 1;
				printf("RIGHT OK\n");
				right_x = col;
				circle(img_line, Point(col, 70), 5, Scalar(0, 0, 255), -1);
				break;
			}
		}



		if (curve_check)
		{
			if(curve_y<=40)
			{
				int left_pixel_count = 0, right_pixel_count = 0;

				for(int row = 90; row<170; row++)
				{
					uchar* curve_down_pointer_row = img_warp.ptr<uchar>(row);

					for(int col = 0; col<160; col++)
					{
						uchar left_pixel = curve_down_pointer_row[col];
						if(left_pixel>0)
							left_pixel_count++;
					}
					for(int col = 160; col<320; col++)
					{
						uchar right_pixel = curve_down_pointer_row[col];
						if(right_pixel>0)
							right_pixel_count++;
					}
				}

				if(left_pixel_count>right_pixel_count)
				{
					go_turn_right_overtaking_mode =1;

					return 0;
				}





			}
			else
			{
				if (left_check && right_check)
				{
					int avg_x=(left_x +  right_x)/2;
					angle = atan2(160 - avg_x, 70)*180/CV_PI;
					printf("angle : %lf\n", angle);

					line(img_line, Point(160, 180), Point(avg_x, 70), Scalar(230, 180, 100), 3);
				}
				else if (left_check && !right_check)
				{//215
					circle(img_line, Point(left_x + 215, 70), 5, Scalar(220, 100, 220), -1);
					
					int avg_x = (left_x*2 + 215) / 2;
					angle = atan2(160 - avg_x, 70)*180/CV_PI;
					printf("angle : %lf\n", angle);

					line(img_line, Point(160, 180), Point(avg_x, 70), Scalar(230, 180, 100), 3);
				}
				else if (!left_check && right_check)
				{
					circle(img_line, Point(right_x - 215, 70), 5, Scalar(220, 100, 220), -1);

					int avg_x = (right_x * 2 - 215) / 2;
					angle = atan2(160 - avg_x, 70)*180/CV_PI;
					printf("angle : %lf\n", angle);

					line(img_line, Point(160, 180), Point(avg_x, 70), Scalar(230, 180, 100), 3);
				}	
					if (angle > -50 && angle < 50)
				{
					//cout<<"test"<<endl;
					steering_angle = 1507 + angle * 5;
						SteeringServoControl_Write(steering_angle);
					//usleep(50000);
				}

			}
			

		}
		else
		{

			if (left_check && right_check)
			{
				int avg_x=(left_x +  right_x)/2;
				angle = atan2(160 - avg_x, 70)*180/CV_PI;
				printf("angle : %lf\n", angle);

				line(img_line, Point(160, 180), Point(avg_x, 70), Scalar(230, 180, 100), 3);
			}
			else if (left_check && !right_check)
			{//215
				circle(img_line, Point(left_x + 215, 70), 5, Scalar(220, 100, 220), -1);
				
				int avg_x = (left_x*2 + 215) / 2;
				angle = atan2(160 - avg_x, 70)*180/CV_PI;
				printf("angle : %lf\n", angle);

				line(img_line, Point(160, 180), Point(avg_x, 70), Scalar(230, 180, 100), 3);
			}
			else if (!left_check && right_check)
			{
				circle(img_line, Point(right_x - 215, 70), 5, Scalar(220, 100, 220), -1);

				int avg_x = (right_x * 2 - 215) / 2;
				angle = atan2(160 - avg_x, 70)*180/CV_PI;
				printf("angle : %lf\n", angle);

				line(img_line, Point(160, 180), Point(avg_x, 70), Scalar(230, 180, 100), 3);
			}

				if (angle > -50 && angle < 50)	
			{
				//cout<<"test"<<endl;
				steering_angle = 1507 + angle * 5;
					SteeringServoControl_Write(steering_angle);
				//usleep(50000);
			}

		
			

		}




	}
	else if(go_turn_right_overtaking_mode == 1)
	{
		SteeringServoControl_Write(2000);
		usleep(50000);
		SpeedControlOnOff_Write(CONTROL);   // speed controller must be also ON !!!
        int speed = 150; // speed set     --> speed must be set when using position controller
        DesireSpeed_Write(speed);

		 PositionControlOnOff_Write(CONTROL);


		 int gain = 5;
        PositionProportionPoint_Write(gain);
  		int move_distance = 800*CV_PI/2 + 200;
        if(move_distance>0)
	        DesireEncoderCount_Write(move_distance);


	
        cout<<"move_distance : "<<move_distance<<endl;
        int sleep_time = (move_distance/500)*1000000 + 1000000;
        usleep(sleep_time);
        PositionControlOnOff_Write(UNCONTROL);
        
        usleep(50000);
        SteeringServoControl_Write(1507);
                usleep(100000);
                SteeringServoControl_Write(1507);
                SteeringServoControl_Write(1507);
                SteeringServoControl_Write(1507);
        
        //DesireSpeed_Write(80);
        main_speed = 120;
        lane_mode = 0;

        
        DesireSpeed_Write(120);
        go_turn_right_overtaking_mode ++;
		return 100;





	}



	img_line.copyTo(output_img);

	// if (!left_check && !right_check && !curve_check)
	// {
	// 	return 0;
	// }


	return steering_angle;
}










// 2020-10-10 09 :10 PM 
//int parking_status =0;

int parking_check_step = 0; 	

/*
input img : yellow img
*/
int parking_check(Mat input_img, Mat& output_img)
{
	Mat img;

	input_img.copyTo(img);




	if(parking_check_step == 0)
	{
		if(go_straight(img,output_img)  &&   dist_milli(2)>240)
		{
			encoder_start = EncoderCounter_Read();
			parking_check_step++;
			return 0;
		}
	}
	else if(parking_check_step == 1)	//parking lot length check
	{
		
		if(go_straight(img,output_img)  && dist_milli(2)<240)
		{
			encoder_end = EncoderCounter_Read();
			parking_check_step++;
			return 0;
		}
	}	
	else if(parking_check_step == 2)
	{
		if(go_straight(img,output_img)  && dist_milli(3)<240 )
		{
			DesireSpeed_Write(0);
			parking_length = encoder_end-encoder_start;

			if(parking_length<850)
			{
				cout<<"V_parking"<<endl;
				opencv_steering_control = 0;
				Alarm_Write(ON);
				usleep(200000);
				Alarm_Write(ON);
				usleep(10000);

				parking_status |= 0b00001111;
				parking_check_step ++;

				return 0;	//vertical 

				//V_parking(parking_length);
			}
			else
			{
				cout<<"H_parking"<<endl;
				opencv_steering_control = 0;
				Alarm_Write(ON);
				usleep(10000);
				//H_parking(parking_length);

				parking_status |= 0b11110000;
				parking_check_step ++;

				return 0;	//helical

			}

		}

	}	
	else if(parking_check_step == 3)	
	{
		if(parking_status == 0b00001111)
		{
			if( V_parking(parking_length, input_img, output_img) == 1)
			{
				DesireSpeed_Write(80);
				parking_check_step++;
			}
		}
		else if(parking_status == 0b11110000)
		{
			if( H_parking(parking_length, input_img, output_img) == 1)
			{
				DesireSpeed_Write(80);
				parking_check_step++;
			}
		}
		return 0;

	}
	else if(parking_check_step == 4)
	{
		SteeringServoControl_Write(1050);
		usleep(50000);
		SpeedControlOnOff_Write(CONTROL);   // speed controller must be also ON !!!
        int speed = 150; // speed set     --> speed must be set when using position controller
        DesireSpeed_Write(speed);

		 PositionControlOnOff_Write(CONTROL);


		 int gain = 5;
        PositionProportionPoint_Write(gain);
  		int move_distance = 800*CV_PI/2 ;
        if(move_distance>0)
	        DesireEncoderCount_Write(move_distance);


	
        cout<<"move_distance : "<<move_distance<<endl;
        int sleep_time = (move_distance/500)*1000000 + 1000000;
        usleep(sleep_time);
        PositionControlOnOff_Write(UNCONTROL);
        
        usleep(50000);
        SteeringServoControl_Write(1507);
                usleep(100000);
                SteeringServoControl_Write(1507);
                SteeringServoControl_Write(1507);
                SteeringServoControl_Write(1507);
        parking_check_step++;
        //DesireSpeed_Write(80);
        main_speed = 120;
        lane_mode = 0;

        cout<<"parking step :" << parking_check_step<<endl;

        DesireSpeed_Write(120);
		return 0;
	}
	else if(parking_check_step == 5)
	{
		
		//calculate_steering_angle5(img, output_img, 1);
				
		go_turn_right(img, output_img);
		//calculate_steering_angle5(img, output_img, 1);
		cout<<"parking step :" << parking_check_step<<endl;
		if(dist_milli(2)<240 )
		{
			calculate_steering_angle5(img, output_img, 1);
			parking_check_step++;
			return 0;
		}

		// if(go_straight(input_img,output_img)  &&   dist_milli(2)>240)
		// {
		// 	encoder_start = EncoderCounter_Read();
		// 	parking_check_step++;
		// 	return 0;
		// }
	}
	else if(parking_check_step ==6 )
	{	cout<<"parking step :" << parking_check_step<<endl;
		if(go_straight(img,output_img)  && dist_milli(2)>240)
		{
			encoder_start = EncoderCounter_Read();
			parking_check_step++;
			return 0;
		}
	}
	else if(parking_check_step == 7)	//parking lot length check
	{
			cout<<"parking step :" << parking_check_step<<endl;
		if(go_straight(img,output_img)  && dist_milli(2)<240)
		{
				cout<<"parking step :" << parking_check_step<<endl;
			encoder_end = EncoderCounter_Read();
			parking_check_step++;
			return 0;
		}
	}	
	else if(parking_check_step == 8)
	{
			cout<<"parking step :" << parking_check_step<<endl;
			go_straight(img,output_img);
		if(dist_milli(3)<240 )
		{
			DesireSpeed_Write(0);
			parking_length = encoder_end-encoder_start;

			parking_status = 0b11111111 - parking_status;
			parking_check_step++;
			return 0; 
		}

	}
	else if(parking_check_step == 9)
	{
				cout<<"parking step :" << parking_check_step<<endl;
		if(parking_status == 0b00001111)
		{
			if( V_parking(parking_length, input_img, output_img) == 1)
			{
				DesireSpeed_Write(80);
				parking_check_step++;
			}
		}
		else if(parking_status == 0b11110000)
		{
			if( H_parking(parking_length, input_img, output_img) == 1)
			{
				DesireSpeed_Write(80);
				parking_check_step++;
			}
		}
		return 0;
	}
	else if(parking_check_step == 10)
	{
				cout<<"parking step :" << parking_check_step<<endl;
				SteeringServoControl_Write(1050);
		usleep(50000);
		SpeedControlOnOff_Write(CONTROL);   // speed controller must be also ON !!!
        int speed = 150; // speed set     --> speed must be set when using position controller
        DesireSpeed_Write(speed);

		 PositionControlOnOff_Write(CONTROL);


		 int gain = 5;
        PositionProportionPoint_Write(gain);
  		int move_distance = 800*CV_PI/2+100;
        if(move_distance>0)
	        DesireEncoderCount_Write(move_distance);


	
        cout<<"move_distance : "<<move_distance<<endl;
        int sleep_time = (move_distance/500)*1000000 + 1000000;
        usleep(sleep_time);
        parking_check_step++;
		PositionControlOnOff_Write(UNCONTROL);
		SteeringServoControl_Write(1507);


		return 100;

	}
	// else if(parking_check_step == 11)
	// {
	// 	if(go_turn_right( input_img, output_img) == 1)
	// 	{
	// 		parking_check_step++;
	// 	}
	// 	return 100;
	// }

	return 0;

}

int go_turn_right_rotary_mode = 0;
char go_turn_right_rotary(Mat input_img, Mat& output_img)
{
	//input_img 는 WARP 이미지 입력받아야함


	Mat img;
	input_img.copyTo(img);


	//이미지 표시용 Mat 선언
	Mat img_line;
	input_img.copyTo(img_line);

	int steering_angle = 1507;

	if(go_turn_right_rotary_mode == 0)
	{
		Mat img_yellow;
		Mat img_warp;

		inRange_yellow(img, img_yellow);
		WARP(img_yellow, img_warp);

		Mat img_warp_rotate(img.cols,img.rows,CV_8UC1);
		
		for (int i = 0; i < img.cols;i++)	//rows
		{
			uchar* img_warp_rotate_pointer_row = img_warp_rotate.ptr<uchar>(i);
			for (int j = 0; j < img.rows;j++)	//cols
			{
				img_warp_rotate_pointer_row[j] = img_warp.at<uchar>(179-j,i);
			}
		}


		//보조선
//		cvtColor(img_line, img_line, COLOR_GRAY2BGR);
		line(img_line, Point2f(0, 70), Point2f(320, 70), Scalar(0, 255, 255), 2);
		line(img_line, Point2f(160, 90), Point2f(160, 180), Scalar(255, 0, 255), 2);

		// 직진 차선 검출용
		line(img_line, Point2f(9, 70), Point2f(149, 70), Scalar(0, 255, 0), 2);
		line(img_line, Point2f(169, 70), Point2f(309, 70), Scalar(0, 255, 0), 2);

		// 직진 차선 중앙 유지용
		line(img_line, Point2f(52, 60), Point2f(52, 80), Scalar(0, 0, 255), 2);
		line(img_line, Point2f(267, 60), Point2f(267, 80), Scalar(0, 0, 255), 2);


		bool curve_check = 0, left_check = 0, right_check = 0;
		int curve_y = 0, left_x = 0, right_x = 0;

		double angle = 0;

		

		//커브 검출
		uchar* curve_pointer_row = img_warp_rotate.ptr<uchar>(160);
		for (int col = 0; col < 179; col++)
		{
			uchar color1 = curve_pointer_row[col];
			uchar color2 = curve_pointer_row[col+1];

			//printf("%d ", color);
			if (color1 > 0 && color2 >0)
			{
				printf("CURVE OK\n");
				curve_check = 1;
				curve_y = col;
				circle(img_line, Point(160, 180 - col), 5, Scalar(0, 0, 255), -1);
				break;
			}
		}


		//직진 차선 검출 왼쪽
		uchar* left_pointer_row = img_warp.ptr<uchar>(70);
		for (int col = 9; col < 149; col += 2)
		{
			uchar color1 = left_pointer_row[col];
			uchar color2 = left_pointer_row[col + 1];
			//printf("%d ", color);
			if (color1 > 0 && color2 > 0)
			{
				printf("LEFT OK\n");
				left_check = 1;
				left_x = col;
				circle(img_line, Point(col, 70), 5, Scalar(0, 0, 255), -1);
				break;
			}
		}


		//직진 차선 검출 오른쪽
		uchar* right_pointer_row = img_warp.ptr<uchar>(70);
		for (int col = 309; col > 169; col -= 2)
		{
			uchar color1 = right_pointer_row[col];
			uchar color2 = right_pointer_row[col - 1];
			//printf("%d ", color);
			if (color1 > 0 && color2 > 0)
			{
				right_check = 1;
				printf("RIGHT OK\n");
				right_x = col;
				circle(img_line, Point(col, 70), 5, Scalar(0, 0, 255), -1);
				break;
			}
		}



		if (curve_check)
		{
			if(curve_y<=30)
			{
				int left_pixel_count = 0, right_pixel_count = 0;

				for(int row = 90; row<170; row++)
				{
					uchar* curve_down_pointer_row = img_warp.ptr<uchar>(row);

					for(int col = 0; col<160; col++)
					{
						uchar left_pixel = curve_down_pointer_row[col];
						if(left_pixel>0)
							left_pixel_count++;
					}
					for(int col = 160; col<320; col++)
					{
						uchar right_pixel = curve_down_pointer_row[col];
						if(right_pixel>0)
							right_pixel_count++;
					}
				}

				if(left_pixel_count<right_pixel_count)
				{
					go_turn_right_rotary_mode =1;
					SteeringServoControl_Write(1100);
					return 0;
				}
			}
			

		}
		else
		{

			if (left_check && right_check)
			{
				int avg_x=(left_x +  right_x)/2;
				angle = atan2(160 - avg_x, 70)*180/CV_PI;
				printf("angle : %lf\n", angle);

				line(img_line, Point(160, 180), Point(avg_x, 70), Scalar(230, 180, 100), 3);
			}
			else if (left_check && !right_check)
			{//215
				circle(img_line, Point(left_x + 215, 70), 5, Scalar(220, 100, 220), -1);
				
				int avg_x = (left_x*2 + 215) / 2;
				angle = atan2(160 - avg_x, 70)*180/CV_PI;
				printf("angle : %lf\n", angle);

				line(img_line, Point(160, 180), Point(avg_x, 70), Scalar(230, 180, 100), 3);
			}
			else if (!left_check && right_check)
			{
				circle(img_line, Point(right_x - 215, 70), 5, Scalar(220, 100, 220), -1);

				int avg_x = (right_x * 2 - 215) / 2;
				angle = atan2(160 - avg_x, 70)*180/CV_PI;
				printf("angle : %lf\n", angle);

				line(img_line, Point(160, 180), Point(avg_x, 70), Scalar(230, 180, 100), 3);
			}
		
			if (angle > -50 && angle < 50)
			{
				//cout<<"test"<<endl;
				steering_angle = 1507 + angle * 5;
					SteeringServoControl_Write(steering_angle);
				//usleep(50000);
			}

		}




	}
	else if(go_turn_right_rotary_mode == 1)
	{
		SteeringServoControl_Write(1050);
		usleep(50000);
		SpeedControlOnOff_Write(CONTROL);   // speed controller must be also ON !!!
        int speed = 150; // speed set     --> speed must be set when using position controller
        DesireSpeed_Write(speed);

		 PositionControlOnOff_Write(CONTROL);


		 int gain = 5;
        PositionProportionPoint_Write(gain);
  		int move_distance = 800*CV_PI/2;
        if(move_distance>0)
	        DesireEncoderCount_Write(move_distance);


	
        cout<<"move_distance : "<<move_distance<<endl;
        int sleep_time = (move_distance/500)*1000000 + 1000000;
        usleep(sleep_time);
        PositionControlOnOff_Write(UNCONTROL);

        DesireSpeed_Write(0);
		SteeringServoControl_Write(1507);
        usleep(100000);
       
        DesireSpeed_Write(80);
        
        // usleep(50000);
        //          SteeringServoControl_Write(1507);
        //         SteeringServoControl_Write(1507);
        //         SteeringServoControl_Write(1507);
        
        //DesireSpeed_Write(80);
        main_speed = 80;
        lane_mode = 0;

        
        DesireSpeed_Write(80);
        go_turn_right_rotary_mode ++;
		return 0;







		// Mat img_threshold;
		// Mat img_warp;
		// threshold(img,img_threshold, 150,255,THRESH_BINARY);

		// WARP(img_threshold, img_warp);

		// Mat img_warp_rotate(img.cols,img.rows,CV_8UC1);
		
		// for (int i = 0; i < img.cols;i++)	//rows
		// {
		// 	uchar* img_warp_rotate_pointer_row = img_warp_rotate.ptr<uchar>(i);
		// 	for (int j = 0; j < img.rows;j++)	//cols
		// 	{
		// 		img_warp_rotate_pointer_row[j] = img_warp.at<uchar>(179-j,i);
		// 	}
		// }
		// SteeringServoControl_Write(1100);

		// bool curve_check = 0, left_check = 0, right_check = 0;
		// int curve_y = 0, left_x = 0, right_x = 0;

		// 	//커브 검출
		// uchar* curve_pointer_row = img_warp_rotate.ptr<uchar>(160);
		
		// int h_lane_detect = 0;

		// for (int col = 0; col < 180; col++)
		// {
		// 	uchar color = curve_pointer_row[col];
		// 	//printf("%d ", color);
		// 	if (color > 0)
		// 	{
		// 		printf("CURVE OK\n");                         
		// 		h_lane_detect = 1;
		// 		curve_y = col;
		// 		circle(img_line, Point(160, 180 - col), 5, Scalar(0, 0, 255), -1);
		// 		break;
		// 	}
		// }



		// if( h_lane_detect)
		// {
		// 	int left = 0, right = 0;

		// 	uchar* img_warp_rotate_pointer_row = img_warp_rotate.ptr<uchar>(100);
		// 	for (int i = 0; i< 179; i++)
		// 	{
		// 		if(img_warp_rotate_pointer_row[i] && img_warp_rotate_pointer_row[i+1])
		// 		{
		// 			left = i;
		// 			break;
		// 		}
				
		// 	}
		// 	img_warp_rotate_pointer_row = img_warp_rotate.ptr<uchar>(220);
		// 	for (int i = 0; i< 179; i++)
		// 	{
		// 		if(img_warp_rotate_pointer_row[i]  && img_warp_rotate_pointer_row[i+1] )
		// 		{
		// 			right = i;
		// 			break;
		// 		}
				
		// 	}

		// 	int left_right_sub;
		// 	left_right_sub = abs(left-right);

		// 	if(left&&right&&left_right_sub<20)
		// 	{

		// 		SteeringServoControl_Write(1507 + (right-left)*10);
		// 		line(img_line, Point2f(80,180-left),Point2f(240,180-right), Scalar(0,0,255),2);

		// 	}
		// }





	}




	img_line.copyTo(output_img);

	// if (!left_check && !right_check && !curve_check)
	// {
	// 	return 0;
	// }


	return steering_angle;
}











// 2020-10-10 08 :29 PM 
int go_turn_right_check = 0;

// 2020-10-10 08 :19 PM 

char go_turn_right(Mat input_img, Mat& output_img)
{
	//input_img 는 WARP 이미지 입력받아야함

	Mat img;
	input_img.copyTo(img);

	int steering_angle = 1507;

	//이미지 회전
	// Mat img_warp_rotate;
	// rotate(img, img_warp_rotate, 1);

	Mat img_warp_rotate(img.cols,img.rows,CV_8UC1);
		
	for (int i = 0; i < img.cols;i++)	//rows
	{
		uchar* img_warp_rotate_pointer_row = img_warp_rotate.ptr<uchar>(i);
		for (int j = 0; j < img.rows;j++)	//cols
		{
			img_warp_rotate_pointer_row[j] = img.at<uchar>(179-j,i);
		}
	}

	//이미지 표시용 Mat 선언
	Mat img_line;
	input_img.copyTo(img_line);

	//보조선
	cvtColor(img_line, img_line, COLOR_GRAY2BGR);
	line(img_line, Point2f(0, 70), Point2f(320, 70), Scalar(0, 255, 255), 2);
	line(img_line, Point2f(160, 90), Point2f(160, 180), Scalar(255, 0, 255), 2);

	// 직진 차선 검출용
	line(img_line, Point2f(9, 70), Point2f(149, 70), Scalar(0, 255, 0), 2);
	line(img_line, Point2f(169, 70), Point2f(309, 70), Scalar(0, 255, 0), 2);

	// 직진 차선 중앙 유지용
	line(img_line, Point2f(52, 60), Point2f(52, 80), Scalar(0, 0, 255), 2);
	line(img_line, Point2f(267, 60), Point2f(267, 80), Scalar(0, 0, 255), 2);


	bool curve_check = 0, left_check = 0, right_check = 0;
	int curve_y = 0, left_x = 0, right_x = 0;

	double angle = 0;

	

	//커브 검출
	uchar* curve_pointer_row = img_warp_rotate.ptr<uchar>(160);
	for (int col = 0; col < 179; col++)
	{
		uchar color1 = curve_pointer_row[col];
		uchar color2 = curve_pointer_row[col+1];
		//printf("%d ", color);
		if (color1 > 0 && color2 >0)
		{
			printf("CURVE OK\n");
			curve_check = 1;
			curve_y = col;
			circle(img_line, Point(160, 180 - col), 5, Scalar(0, 0, 255), -1);
			break;
		}
	}


	//직진 차선 검출 왼쪽
	uchar* left_pointer_row = img.ptr<uchar>(70);
	for (int col = 9; col < 149; col += 2)
	{
		uchar color1 = left_pointer_row[col];
		uchar color2 = left_pointer_row[col + 1];
		//printf("%d ", color);
		if (color1 > 0 && color2 > 0)
		{
			printf("LEFT OK\n");
			left_check = 1;
			left_x = col;
			circle(img_line, Point(col, 70), 5, Scalar(0, 0, 255), -1);
			break;
		}
	}


	//직진 차선 검출 오른쪽
	uchar* right_pointer_row = img.ptr<uchar>(70);
	for (int col = 309; col > 169; col -= 2)
	{
		uchar color1 = right_pointer_row[col];
		uchar color2 = right_pointer_row[col - 1];
		//printf("%d ", color);
		if (color1 > 0 && color2 > 0)
		{
			right_check = 1;
			printf("RIGHT OK\n");
			right_x = col;
			circle(img_line, Point(col, 70), 5, Scalar(0, 0, 255), -1);
			break;
		}
	}



	if( lane_mode == 0 )	//직진
	{
		if (curve_check)
		{
			if(curve_y<=40)
			{
				int left_pixel_count = 0, right_pixel_count = 0;

				for(int row = 90; row<170; row++)
				{
					uchar* curve_down_pointer_row = img.ptr<uchar>(row);

					for(int col = 0; col<160; col++)
					{
						uchar left_pixel = curve_down_pointer_row[col];
						if(left_pixel>0)
							left_pixel_count++;
					}
					for(int col = 160; col<320; col++)
					{
						uchar right_pixel = curve_down_pointer_row[col];
						if(right_pixel>0)
							right_pixel_count++;
					}
				}

				if(left_pixel_count<right_pixel_count)
				{
					lane_mode = -1;
				}
			}
			

		}
		else
		{

			if (left_check && right_check)
			{
				int avg_x=(left_x +  right_x)/2;
				angle = atan2(160 - avg_x, 70)*180/CV_PI;
				printf("angle : %lf\n", angle);

				line(img_line, Point(160, 180), Point(avg_x, 70), Scalar(230, 180, 100), 3);
			}
			else if (left_check && !right_check)
			{//215
				circle(img_line, Point(left_x + 215, 70), 5, Scalar(220, 100, 220), -1);
				
				int avg_x = (left_x*2 + 215) / 2;
				angle = atan2(160 - avg_x, 70)*180/CV_PI;
				printf("angle : %lf\n", angle);

				line(img_line, Point(160, 180), Point(avg_x, 70), Scalar(230, 180, 100), 3);
			}
			else if (!left_check && right_check)
			{
				circle(img_line, Point(right_x - 215, 70), 5, Scalar(220, 100, 220), -1);

				int avg_x = (right_x * 2 - 215) / 2;
				angle = atan2(160 - avg_x, 70)*180/CV_PI;
				printf("angle : %lf\n", angle);

				line(img_line, Point(160, 180), Point(avg_x, 70), Scalar(230, 180, 100), 3);
			}
		}

	}
	else if(lane_mode==-1)	//우회전
	{
		if (left_check && right_check && !curve_check)
		{
			
			lane_mode=0;
			return 1;	// END
			
		}

	}

	
	if(lane_mode==-1)
	{
		// steering_angle = 1050;

		if(curve_y < 90)
	        steering_angle = 1050;// + curve_y*2;
      	else	
        	steering_angle = 1050;

			
		SteeringServoControl_Write(steering_angle);
	}
	else if (angle > -50 && angle < 50)
	{
		//cout<<"test"<<endl;
		steering_angle = 1507 + angle * 5;
			SteeringServoControl_Write(steering_angle);
		//usleep(50000);
	}


	
		


	img_line.copyTo(output_img);

	if (!left_check && !right_check && !curve_check)
	{
		return 0;
	}


	return steering_angle;
}

// 2020-10-10 07 :36 PM 

char go_straight(Mat input_img, Mat& output_img)
{
	Mat img;
	input_img.copyTo(img);

	int steering_angle = 1507;

	//이미지 표시용 Mat 선언
	Mat img_line;
	input_img.copyTo(img_line);

	//보조선
	cvtColor(img_line, img_line, COLOR_GRAY2BGR);
	line(img_line, Point2f(0, 90), Point2f(320, 90), Scalar(0, 255, 255), 2);
	line(img_line, Point2f(160, 90), Point2f(160, 180), Scalar(255, 0, 255), 2);

	// 직진 차선 검출용
	line(img_line, Point2f(9, 90), Point2f(149, 90), Scalar(0, 255, 0), 2);
	line(img_line, Point2f(169, 90), Point2f(309, 90), Scalar(0, 255, 0), 2);

	// 직진 차선 중앙 유지용
	line(img_line, Point2f(52, 80), Point2f(52, 100), Scalar(0, 0, 255), 2);
	line(img_line, Point2f(267, 80), Point2f(267, 100), Scalar(0, 0, 255), 2);


	bool curve_check = 0, left_check = 0, right_check = 0;
	int curve_y = 0, left_x = 0, right_x = 0;

	double angle = 0;

	//직진 차선 검출 왼쪽
	uchar* left_pointer_row = img.ptr<uchar>(90);
	for (int col = 9; col < 149; col += 2)
	{
		uchar color1 = left_pointer_row[col];
		uchar color2 = left_pointer_row[col + 1];
		//printf("%d ", color);
		if (color1 > 0 && color2 > 0)
		{
			printf("LEFT OK\n");
			left_check = 1;
			left_x = col;
			circle(img_line, Point(col, 90), 5, Scalar(0, 0, 255), -1);
			break;
		}
	}


	//직진 차선 검출 오른쪽
	uchar* right_pointer_row = img.ptr<uchar>(90);
	for (int col = 309; col > 169; col -= 2)
	{
		uchar color1 = right_pointer_row[col];
		uchar color2 = right_pointer_row[col - 1];
		//printf("%d ", color);
		if (color1 > 0 && color2 > 0)
		{
			right_check = 1;
			printf("RIGHT OK\n");
			right_x = col;
			circle(img_line, Point(col, 90), 5, Scalar(0, 0, 255), -1);
			break;
		}
	}




	if (left_check && right_check)
	{
		int avg_x=(left_x +  right_x)/2;
		angle = atan2(160 - avg_x, 90)*180/CV_PI;
		printf("angle : %lf\n", angle);
		steering_angle = 1507 + angle * 5;
		SteeringServoControl_Write(steering_angle);

		line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
	
		img_line.copyTo(output_img);

		return 0b11111111; 
	}
	else if (left_check && !right_check)
	{//215
		circle(img_line, Point(left_x + 215, 90), 5, Scalar(220, 100, 220), -1);
		
		int avg_x = (left_x*2 + 215) / 2;
		angle = atan2(160 - avg_x, 90)*180/CV_PI;
		printf("angle : %lf\n", angle);
		steering_angle = 1507 + angle * 5;
		SteeringServoControl_Write(steering_angle);
		line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
		img_line.copyTo(output_img);
		return 0b11110000;
	}
	else if (!left_check && right_check)
	{
		circle(img_line, Point(right_x - 215, 90), 5, Scalar(220, 100, 220), -1);

		int avg_x = (right_x * 2 - 215) / 2;
		angle = atan2(160 - avg_x, 90)*180/CV_PI;
		printf("angle : %lf\n", angle);

		steering_angle = 1507 + angle * 5;
		SteeringServoControl_Write(steering_angle);

		line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
		img_line.copyTo(output_img);
		return 0b00001111;
	}
	
	steering_angle = 1507 + angle * 5;
	SteeringServoControl_Write(steering_angle);
	img_line.copyTo(output_img);

	return 0;		
}








// 2020-10-09 11 :31 PM 


int distance_driving_tunnel(Mat input_img, Mat& output_img,int steering_control_onoff)
{
	
	// steering_control_onoff
	//	1 = on
	//	0 = off

	// return 
	// 0 : escape mission
	// steering_angle

	Mat img;
	input_img.copyTo(img);
	
	int dist_num[7];	//add null data
		dist_num[0] = 0;	
		dist_num[1] = 0;	//dist_2
		dist_num[2] = 0;	//dist_3
		dist_num[3] = 0;
		dist_num[4] = 0;	//dist_5
		dist_num[5] = 0;	//dist_6



	Point dist_pt[7];
		dist_pt[0] = Point(140, 40);
		dist_pt[1] = Point(210, 70);
		dist_pt[2] = Point(210, 130);
		dist_pt[3] = Point(140, 160);
		dist_pt[4] = Point(90, 130);
		dist_pt[5] = Point(90, 70);

	for (int i = 0; i < 6; i++)
	{
		if(i!=0 && i!=3)
		{
			char myText[20];
			dist_num[i] = dist_milli(i + 1);
			//myText = double.toString(dist_cesnti(i+1));
			sprintf(myText, "%d", dist_num[i]);
			//sprintf(myText, "%d", i+1);
			if(dist_num[i]<80)
			{
				putText(img, myText, dist_pt[i], 3, 1, Scalar(0,0,255), 1, 8);
			}
			else if(dist_num[i]<150)
			{
				putText(img, myText, dist_pt[i], 3, 1, Scalar(0,255,0), 1, 8);
			}
			else if(dist_num[i]<250)
			{
				putText(img, myText, dist_pt[i], 3, 1, Scalar(255,0,0), 1, 8);
			}
			else 
				putText(img, myText, dist_pt[i], 3, 1, Scalar::all(255), 1, 8);

		}		
	}

	img.copyTo(output_img);

	int dist_2 = 0;
	int dist_3 = 0;
	int dist_5 = 0;
	int dist_6 = 0;

	int steering_angle = 1507;

	if (dist_num[1] < 220)
		dist_2 = dist_num[1];
	if (dist_num[2] < 220)
		dist_3 = dist_num[2];
	if (dist_num[4] < 220)
		dist_5 = dist_num[4];
	if (dist_num[5] < 220)
		dist_6 = dist_num[5];



	if (dist_2 + dist_3 + dist_5 + dist_6 == 0)
	{
		cout << "non detect" << endl;
		return 0;
	}


	if(tunnel_step ==0)
	{
		if(!dist_2 && dist_3 && dist_5 && dist_6)
		{
			steering_angle=1350;
			if (steering_control_onoff)
				SteeringServoControl_Write(steering_angle);

		}
		else if (dist_2 && dist_3 && dist_5 && !dist_6)
		{
			steering_angle=1950;
			if (steering_control_onoff)
				SteeringServoControl_Write(steering_angle);

		}

		else if (dist_2 && dist_3 && dist_5 && dist_6 )
		{

			// cout << "all distance detect" <<  endl;

			double left_angle = 0, right_angle = 0, avg_angle = 0;
			int left_dist, right_dist, sub_dist;
			left_dist = dist_5 + dist_6;
			right_dist = dist_2 + dist_3;
			sub_dist = left_dist - right_dist;

			left_angle = atan(double(dist_6 - dist_5) / 280) * 180 / CV_PI;
			right_angle = atan(double(dist_3 - dist_2) / 280) * 180 / CV_PI;
			avg_angle = (left_angle + right_angle) / 2;

			// cout<<"left_angle : " << left_angle <<endl;
			// cout<<"right_angle : " << right_angle <<endl;

			//cout << "avg_angle : " << avg_angle << endl;
			//    / : '-'  , \ : '+'

			steering_angle = 1507 + int(avg_angle * 16.67) + sub_dist;
			if (steering_angle <= 1000)
				steering_angle = 1000;
			else if (steering_angle >= 2000)
				steering_angle = 2000;

			//cout << "steering_angle : " << steering_angle << endl;
			// 60 : 1000, 90 : 1507,  120 : 2000
			if (steering_control_onoff)
				SteeringServoControl_Write(steering_angle);

			pre_dist2 = dist_2;
			pre_dist3 = dist_3;
			pre_dist5 = dist_5;
			pre_dist6 = dist_6;
			pre_encoder = EncoderCounter_Read();

			usleep(10000);
			tunnel_step ++;
			DesireSpeed_Write(120);
		}

	}	
	else if(tunnel_step == 1)
	{
		if(!dist_2 && dist_3 && dist_5 && dist_6)
		{
			steering_angle=1350;
			if (steering_control_onoff)
				SteeringServoControl_Write(steering_angle);

		}
		else if (dist_2 && dist_3 && !dist_5 && !dist_6)
		{
			steering_angle=2000;
			if (steering_control_onoff)
				SteeringServoControl_Write(steering_angle);

		}

		else if (dist_2 && dist_3 && dist_5 && dist_6 )
		{

			// cout << "all distance detect" <<  endl;

			double left_angle = 0, right_angle = 0, avg_angle = 0;
			int left_dist, right_dist, sub_dist;
			left_dist = dist_5 + dist_6;
			right_dist = dist_2 + dist_3;
			sub_dist = left_dist - right_dist;

			left_angle = atan(double(dist_6 - dist_5) / 280) * 180 / CV_PI;
			right_angle = atan(double(dist_3 - dist_2) / 280) * 180 / CV_PI;
			avg_angle = (left_angle + right_angle) / 2;

			// cout<<"left_angle : " << left_angle <<endl;
			// cout<<"right_angle : " << right_angle <<endl;

			//cout << "avg_angle : " << avg_angle << endl;
			//    / : '-'  , \ : '+'

			steering_angle = 1507 + int(avg_angle * 16.67) + sub_dist;
			if (steering_angle <= 1000)
				steering_angle = 1000;
			else if (steering_angle >= 2000)
				steering_angle = 2000;

			//cout << "steering_angle : " << steering_angle << endl;
			// 60 : 1000, 90 : 1507,  120 : 2000
			if (steering_control_onoff)
				SteeringServoControl_Write(steering_angle);

			pre_dist2 = dist_2;
			pre_dist3 = dist_3;
			pre_dist5 = dist_5;
			pre_dist6 = dist_6;
			pre_encoder = EncoderCounter_Read();
			usleep(10000);
		}
		else if (dist_2 && dist_6)
		{
			//cout << "front distance detect" << endl;
			//pre_dist_right = dist_2, pre_dist_left = dist_6;


			double left_angle = 0, right_angle = 0, avg_angle = 0;

			int left_dist, right_dist, sub_dist;
			left_dist = dist_6;
			right_dist = dist_2;
			sub_dist = left_dist - right_dist;


			int now_encoder = EncoderCounter_Read();
			usleep(10000);
			//cout << "now_encoder : " << now_encoder << endl;
			//cout << "pre_encoder_front : " << pre_encoder << endl;


			if (now_encoder != pre_encoder && pre_dist2 && pre_dist6)
			{
				left_angle = atan(double(dist_6 - pre_dist6) / double((now_encoder - pre_encoder) / 2)) * 180 / CV_PI;

				right_angle = atan(double(pre_dist2 - dist_2) / double((now_encoder - pre_encoder) / 2)) * 180 / CV_PI;

				avg_angle = (left_angle + right_angle) / 2;
			//	cout << "avg_angle : " << avg_angle << endl;



				steering_angle = 1507 + int(avg_angle * 16.67) + sub_dist;
				if (steering_angle <= 1000)
					steering_angle = 1000;
				else if (steering_angle >= 2000)
					steering_angle = 2000;

			//	cout << "steering_angle : " << steering_angle << endl;
				// 60 : 1000, 90 : 1507,  120 : 2000
				if (steering_control_onoff)
					SteeringServoControl_Write(steering_angle);
			}

			pre_dist2 = dist_2;
			pre_dist6 = dist_6;
			pre_encoder = now_encoder;

		}
		else if (dist_3 && dist_5 && !dist_2 && !dist_6)
		{
			//cout << "rear distance detect" << endl;		

			double left_angle = 0, right_angle = 0, avg_angle = 0;

			int left_dist, right_dist, sub_dist;
			left_dist = dist_5;
			right_dist = dist_3;
			sub_dist = left_dist - right_dist;


			int now_encoder = EncoderCounter_Read();
			usleep(10000);
			//cout << "now_encoder : " << now_encoder << endl;
			//cout << "pre_encoder_rear : " << pre_encoder << endl;

			if (now_encoder != pre_encoder && pre_dist3 && pre_dist5)
			{
				left_angle = atan(double(dist_5 - pre_dist5) / double((now_encoder - pre_encoder) / 2)) * 180 / CV_PI;

				right_angle = atan(double(pre_dist3 - dist_3) / double((now_encoder - pre_encoder) / 2)) * 180 / CV_PI;

				avg_angle = (left_angle + right_angle) / 2;
			//	cout << "avg_angle : " << avg_angle << endl;


				steering_angle = 1507 + int(avg_angle * 16.67) + sub_dist;
				if (steering_angle <= 1000)
					steering_angle = 1000;
				else if (steering_angle >= 2000)
					steering_angle = 2000;

			//	cout << "steering_angle : " << steering_angle << endl;
				// 60 : 1000, 90 : 1507,  120 : 2000
				if (steering_control_onoff)
					SteeringServoControl_Write(steering_angle);
			

			}

			pre_dist3 = dist_3;
			pre_dist5 = dist_5;
			

		}
		else
		{
			pre_dist2 = dist_2;
			pre_dist6 = dist_6;
			pre_dist3 = dist_3;
			pre_dist5 = dist_5;
			
			usleep(10000);
		}
	}

	return steering_angle;
}













int S_curve(Mat input_img, Mat& output_img, bool steering_control_onoff)
{
   //input_img 는 WARP 이미지 입력받아야함

   Mat img;
   input_img.copyTo(img);

   int steering_angle = 1507;

   //이미지 회전
   // Mat img_warp_rotate;
   // rotate(img, img_warp_rotate, 1);

   if(lane_mode == 0 && dist_milli(2)<200)//straight&right sensor
   {
      usleep(10000);
      if (dist_milli(2)<200)//again
      {

         return 1;
      }
   }

   Mat img_warp_rotate(img.cols,img.rows,CV_8UC1);
      
   for (int i = 0; i < img.cols;i++)   //rows
   {
      uchar* img_warp_rotate_pointer_row = img_warp_rotate.ptr<uchar>(i);
      for (int j = 0; j < img.rows;j++)   //cols
      {
         img_warp_rotate_pointer_row[j] = img.at<uchar>(179-j,i);
      }
   }

   //이미지 표시용 Mat 선언
   Mat img_line;
   input_img.copyTo(img_line);

   //보조선
   cvtColor(img_line, img_line, COLOR_GRAY2BGR);
   line(img_line, Point2f(0, 90), Point2f(320, 90), Scalar(0, 255, 255), 2);
   line(img_line, Point2f(160, 90), Point2f(160, 180), Scalar(255, 0, 255), 2);

   // 직진 차선 검출용
   line(img_line, Point2f(9, 90), Point2f(149, 90), Scalar(0, 255, 0), 2);
   line(img_line, Point2f(169, 90), Point2f(309, 90), Scalar(0, 255, 0), 2);

   // 직진 차선 중앙 유지용
   line(img_line, Point2f(52, 80), Point2f(52, 100), Scalar(0, 0, 255), 2);
   line(img_line, Point2f(267, 80), Point2f(267, 100), Scalar(0, 0, 255), 2);


   bool curve_check = 0, left_check = 0, right_check = 0;
   int curve_y = 0, left_x = 0, right_x = 0;

   double angle = 0;

   

   //커브 검출
   uchar* curve_pointer_row = img_warp_rotate.ptr<uchar>(160);
   for (int col = 0; col < 180; col++)
   {
      uchar color = curve_pointer_row[col];
      //printf("%d ", color);
      if (color > 0)
      {
         printf("CURVE OK\n");
         curve_check = 1;
         curve_y = col;
         circle(img_line, Point(160, 180 - col), 5, Scalar(0, 0, 255), -1);
         break;
      }
   }


   //직진 차선 검출 왼쪽
   uchar* left_pointer_row = img.ptr<uchar>(90);
   for (int col = 9; col < 149; col += 2)
   {
      uchar color1 = left_pointer_row[col];
      uchar color2 = left_pointer_row[col + 1];
      //printf("%d ", color);
      if (color1 > 0 && color2 > 0)
      {
         printf("LEFT OK\n");
         left_check = 1;
         left_x = col;
         circle(img_line, Point(col, 90), 5, Scalar(0, 0, 255), -1);
         break;
      }
   }


   //직진 차선 검출 오른쪽
   uchar* right_pointer_row = img.ptr<uchar>(90);
   for (int col = 309; col > 169; col -= 2)
   {
      uchar color1 = right_pointer_row[col];
      uchar color2 = right_pointer_row[col - 1];
      //printf("%d ", color);
      if (color1 > 0 && color2 > 0)
      {
         right_check = 1;
         printf("RIGHT OK\n");
         right_x = col;
         circle(img_line, Point(col, 90), 5, Scalar(0, 0, 255), -1);
         break;
      }
   }


   if( lane_mode == 0 )   //직진
   {
      if (curve_check)
      {
         if(curve_y<80)
         {
            short speed;
            speed = DesireSpeed_Read();

            if(speed>20)
            {
               DesireSpeed_Write(150);
            }
         }
         

         if(curve_y<=30)
         {
            int left_pixel_count = 0, right_pixel_count = 0;

            for(int row = 90; row<170; row++)
            {
               uchar* curve_down_pointer_row = img.ptr<uchar>(row);

               for(int col = 0; col<160; col++)
               {
                  uchar left_pixel = curve_down_pointer_row[col];
                  if(left_pixel>0)
                     left_pixel_count++;
               }
               for(int col = 160; col<320; col++)
               {
                  uchar right_pixel = curve_down_pointer_row[col];
                  if(right_pixel>0)
                     right_pixel_count++;
               }
            }

            if(left_pixel_count>right_pixel_count)
            {
               lane_mode = 1;
            }
            else
            {
               lane_mode = -1;
            }

         }
         

      }
      else
      {

         if (left_check && right_check)
         {
            int avg_x=(left_x +  right_x)/2;
            angle = atan2(160 - avg_x, 90)*180/CV_PI;
            printf("angle : %lf\n", angle);

            line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
         }
         else if (left_check && !right_check)
         {//215
            circle(img_line, Point(left_x + 215, 90), 5, Scalar(220, 100, 220), -1);
            
            int avg_x = (left_x*2 + 215) / 2;
            angle = atan2(160 - avg_x, 90)*180/CV_PI;
            printf("angle : %lf\n", angle);

            line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
         }
         else if (!left_check && right_check)
         {
            circle(img_line, Point(right_x - 215, 90), 5, Scalar(220, 100, 220), -1);

            int avg_x = (right_x * 2 - 215) / 2;
            angle = atan2(160 - avg_x, 90)*180/CV_PI;
            printf("angle : %lf\n", angle);

            line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
         }
      }

   }
   else if(lane_mode==1)   //좌회전
   {
      if (left_check && right_check && !curve_check)
      {
         lane_mode=0;
         short speed;
         speed = DesireSpeed_Read();

         if(speed>0)
         {
            DesireSpeed_Write(main_speed);
         }
      }
   }
   else if(lane_mode==-1)   //우회전
   {
      if (left_check && right_check && !curve_check)
      {
         lane_mode=0;
         short speed;
         speed = DesireSpeed_Read();

         if(speed>0)
         {
            DesireSpeed_Write(main_speed);
         }
      }

   }

   
   if(lane_mode==1)
   {
      //steering_angle = 1950;
      if(curve_y < 90)
         steering_angle = 1925 - curve_y*2;
      else
         steering_angle = 1950;
      if (steering_control_onoff == 1)
         SteeringServoControl_Write(steering_angle);
   }
   else if(lane_mode==-1)
   {
      if(curve_y < 90)
         steering_angle = 1050 + curve_y*2;
      else
         steering_angle = 1050;
      // steering_angle = 1050;
            //steering_angle = 1050 + curve_y*2;
      if (steering_control_onoff == 1)
         SteeringServoControl_Write(steering_angle);
   }
   else if (angle > -50 && angle < 50)
   {
      //cout<<"test"<<endl;
      steering_angle = 1507 + angle * 5;
      if (steering_control_onoff == 1)
         SteeringServoControl_Write(steering_angle);
      //usleep(50000);
   }


   if(S_curve_step==0)
   {
      if(lane_mode!=0)
         S_curve_step ++;
      //S_curve start!
   }
   else if(S_curve_step == 1)
   {

   }
      


   img_line.copyTo(output_img);

   if (!left_check && !right_check && !curve_check)
   {
      return 0;
   }


   return steering_angle;
}
/*
int S_curve(Mat input_img, Mat& output_img, bool steering_control_onoff)
{
	//input_img 는 WARP 이미지 입력받아야함

	Mat img;
	input_img.copyTo(img);

	int steering_angle = 1507;

	//이미지 회전
	// Mat img_warp_rotate;
	// rotate(img, img_warp_rotate, 1);

	if(lane_mode == 0 && dist_milli(2)<200)
	{
		usleep(10000);
		if (dist_milli(2)<200)
		{

			return 1;
		}
	}

	Mat img_warp_rotate(img.cols,img.rows,CV_8UC1);
		
	for (int i = 0; i < img.cols;i++)	//rows
	{
		uchar* img_warp_rotate_pointer_row = img_warp_rotate.ptr<uchar>(i);
		for (int j = 0; j < img.rows;j++)	//cols
		{
			img_warp_rotate_pointer_row[j] = img.at<uchar>(179-j,i);
		}
	}

	//이미지 표시용 Mat 선언
	Mat img_line;
	input_img.copyTo(img_line);

	//보조선
	cvtColor(img_line, img_line, COLOR_GRAY2BGR);
	line(img_line, Point2f(0, 90), Point2f(320, 90), Scalar(0, 255, 255), 2);
	line(img_line, Point2f(160, 90), Point2f(160, 180), Scalar(255, 0, 255), 2);

	// 직진 차선 검출용
	line(img_line, Point2f(9, 90), Point2f(149, 90), Scalar(0, 255, 0), 2);
	line(img_line, Point2f(169, 90), Point2f(309, 90), Scalar(0, 255, 0), 2);

	// 직진 차선 중앙 유지용
	line(img_line, Point2f(52, 80), Point2f(52, 100), Scalar(0, 0, 255), 2);
	line(img_line, Point2f(267, 80), Point2f(267, 100), Scalar(0, 0, 255), 2);


	bool curve_check = 0, left_check = 0, right_check = 0;
	int curve_y = 0, left_x = 0, right_x = 0;

	double angle = 0;

	

	//커브 검출
	uchar* curve_pointer_row = img_warp_rotate.ptr<uchar>(160);
	for (int col = 0; col < 180; col++)
	{
		uchar color = curve_pointer_row[col];
		//printf("%d ", color);
		if (color > 0)
		{
			printf("CURVE OK\n");
			curve_check = 1;
			curve_y = col;
			circle(img_line, Point(160, 180 - col), 5, Scalar(0, 0, 255), -1);
			break;
		}
	}


	//직진 차선 검출 왼쪽
	uchar* left_pointer_row = img.ptr<uchar>(90);
	for (int col = 9; col < 149; col += 2)
	{
		uchar color1 = left_pointer_row[col];
		uchar color2 = left_pointer_row[col + 1];
		//printf("%d ", color);
		if (color1 > 0 && color2 > 0)
		{
			printf("LEFT OK\n");
			left_check = 1;
			left_x = col;
			circle(img_line, Point(col, 90), 5, Scalar(0, 0, 255), -1);
			break;
		}
	}


	//직진 차선 검출 오른쪽
	uchar* right_pointer_row = img.ptr<uchar>(90);
	for (int col = 309; col > 169; col -= 2)
	{
		uchar color1 = right_pointer_row[col];
		uchar color2 = right_pointer_row[col - 1];
		//printf("%d ", color);
		if (color1 > 0 && color2 > 0)
		{
			right_check = 1;
			printf("RIGHT OK\n");
			right_x = col;
			circle(img_line, Point(col, 90), 5, Scalar(0, 0, 255), -1);
			break;
		}
	}


	if( lane_mode == 0 )	//직진
	{
		if (curve_check)
		{
			if(curve_y<80)
			{
				short speed;
				speed = DesireSpeed_Read();

				if(speed>20)
				{
					DesireSpeed_Write(150);
				}
			}
			

			if(curve_y<=30)
			{
				int left_pixel_count = 0, right_pixel_count = 0;

				for(int row = 90; row<170; row++)
				{
					uchar* curve_down_pointer_row = img.ptr<uchar>(row);

					for(int col = 0; col<160; col++)
					{
						uchar left_pixel = curve_down_pointer_row[col];
						if(left_pixel>0)
							left_pixel_count++;
					}
					for(int col = 160; col<320; col++)
					{
						uchar right_pixel = curve_down_pointer_row[col];
						if(right_pixel>0)
							right_pixel_count++;
					}
				}

				if(left_pixel_count>right_pixel_count)
				{
					lane_mode = 1;
				}
				else
				{
					lane_mode = -1;
				}

			}
			

		}
		else
		{

			if (left_check && right_check)
			{
				int avg_x=(left_x +  right_x)/2;
				angle = atan2(160 - avg_x, 90)*180/CV_PI;
				printf("angle : %lf\n", angle);

				line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
			}
			else if (left_check && !right_check)
			{//215
				circle(img_line, Point(left_x + 215, 90), 5, Scalar(220, 100, 220), -1);
				
				int avg_x = (left_x*2 + 215) / 2;
				angle = atan2(160 - avg_x, 90)*180/CV_PI;
				printf("angle : %lf\n", angle);

				line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
			}
			else if (!left_check && right_check)
			{
				circle(img_line, Point(right_x - 215, 90), 5, Scalar(220, 100, 220), -1);

				int avg_x = (right_x * 2 - 215) / 2;
				angle = atan2(160 - avg_x, 90)*180/CV_PI;
				printf("angle : %lf\n", angle);

				line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
			}
		}

	}
	else if(lane_mode==1)	//좌회전
	{
		if (left_check && right_check && !curve_check)
		{
			lane_mode=0;
			short speed;
			speed = DesireSpeed_Read();

			if(speed>0)
			{
				DesireSpeed_Write(main_speed);
			}
		}
	}
	else if(lane_mode==-1)	//우회전
	{
		if (left_check && right_check && !curve_check)
		{
			lane_mode=0;
			short speed;
			speed = DesireSpeed_Read();

			if(speed>0)
			{
				DesireSpeed_Write(main_speed);
			}
		}

	}

	
	if(lane_mode==1)
	{
		//steering_angle = 1950;
		if(curve_y < 90)
			steering_angle = 1950 - curve_y*2;
		else
			steering_angle = 1950;
		if (steering_control_onoff == 1)
			SteeringServoControl_Write(steering_angle);
	}
	else if(lane_mode==-1)
	{
		if(curve_y < 90)
			steering_angle = 1050 + curve_y*2;
		else
			steering_angle = 1050;
		// steering_angle = 1050;
				//steering_angle = 1050 + curve_y*2;
		if (steering_control_onoff == 1)
			SteeringServoControl_Write(steering_angle);
	}
	else if (angle > -50 && angle < 50)
	{
		//cout<<"test"<<endl;
		steering_angle = 1507 + angle * 5;
		if (steering_control_onoff == 1)
			SteeringServoControl_Write(steering_angle);
		//usleep(50000);
	}


	if(S_curve_step==0)
	{
		if(lane_mode!=0)
			S_curve_step ++;
		//S_curve start!
	}
	else if(S_curve_step == 1)
	{

	}
		


	img_line.copyTo(output_img);

	if (!left_check && !right_check && !curve_check)
	{
		return 0;
	}


	return steering_angle;
}
*/




// 2020-10-04 06 :04 PM 
int overtaking_step = 0;
int overtaking_left_count = 0;
int overtaking_right_count = 0;

// //test
int threshold_value = 200;
// 2020-10-04 06 :04 PM 
/*
	input img = color img;
*/

// 2020-10-09 11 :04 PM 
int tunnel_check = 0;

int overtaking(Mat input_img, Mat& output_img)
{
	if (overtaking_step == 0)
	{
		if(go_turn_right_overtaking(input_img,output_img) == 100)
			overtaking_step ++;


	}
   else if(overtaking_step == 1)
   {
      Mat img;
      input_img.copyTo(img);

      Mat img_grayscale;
      cvtColor(img,img_grayscale,COLOR_RGB2GRAY);

      Mat img_threshold;
      threshold(img_grayscale,img_threshold,threshold_value,255,THRESH_BINARY);

      Mat img_warp;
      WARP(img_threshold,img_warp);

      calculate_steering_angle5(img_warp, img_warp, 1);

      int dist_1;
         dist_1 = dist_milli(1);

      if(dist_1<300)
      {
         
         if(dist_1 <250)
         {
            DesireSpeed_Write(-50);/////////*********dist
         }
         else if(dist_1 > 280)
         {
            DesireSpeed_Write(50);
         }
         else
         {
            overtaking_step ++;
            DesireSpeed_Write(0);
         }
      }
      //cvtColor(img_warp,img_warp,COLOR_GRAY2BGR);
   
      img_warp.copyTo(output_img);
      return 0;

   }
   else if(overtaking_step == 2)
   {
      CameraXServoControl_Write(1800);
      usleep(700000);
      overtaking_step++;

   }
   else if(overtaking_step < 8)   
   {
      usleep(10000);
      overtaking_step++;
   }
   else if(overtaking_step == 8)
   {
      Mat img_left;
      input_img.copyTo(img_left);

      Mat img_left_grayscale;
      cvtColor(img_left, img_left_grayscale, COLOR_RGB2GRAY);

      Mat img_left_threshold;
      threshold(img_left_grayscale, img_left_threshold, 40, 255, THRESH_BINARY);

      rectangle(input_img, Point(120, 50), Point(200, 100), Scalar(0, 0, 255), 1, 8);
      for(int row = 50; row < 100; row++)
      {
         uchar* overtake_left_row = img_left_threshold.ptr<uchar>(row);

         for(int col = 120; col<200; col++)
         {
            if(overtake_left_row[col] == 0)
               overtaking_left_count++;
         }
      }
      cout<<" LEFT count : "<<overtaking_left_count<<endl;
      overtaking_step++;
   }
   else if(overtaking_step == 9)
   {
      CameraXServoControl_Write(1200);
      usleep(700000);
      overtaking_step++;
   }
   else if(overtaking_step < 15)
   {
      usleep(10000);
      overtaking_step++;
   }
   else if(overtaking_step == 15)
   {
      Mat img_right;
      input_img.copyTo(img_right);

      Mat img_right_grayscale;
      cvtColor(img_right, img_right_grayscale, COLOR_RGB2GRAY);

      Mat img_right_threshold;
      threshold(img_right_grayscale, img_right_threshold, 40, 255, THRESH_BINARY);

      for(int row = 50; row < 100; row++)
      {
         uchar* overtake_right_row = img_right_threshold.ptr<uchar>(row);

         for(int col = 120; col<200; col++)
         {
            if(overtake_right_row[col] == 0)
               overtaking_right_count++;
         }
      }
      cout<<" RIGHT count : "<<overtaking_right_count<<endl;
      overtaking_step++;
   }
   else if(overtaking_step == 16)
   {
      if(overtaking_left_count > overtaking_right_count)
      {
         Winker_Write(RIGHT_ON);
         overtaking_step = 20;   //turn right       
      }
      else if(overtaking_left_count < overtaking_right_count)
      {
         Winker_Write(LEFT_ON);
         overtaking_step = 30;   //turn left
      }
      CameraXServoControl_Write(1500);
      usleep(500000);
      //overtaking_step++;
   }
   //////////////////////////////////////////////////////////////
   else if(overtaking_step == 20)   //turn right
   {
      //Winker_Write(ALL_OFF);
      //overtaking_step++;
      SteeringServoControl_Write(1507-450);
      overtaking_step++;
   }
   else if(overtaking_step == 21)
   {
      int speed = 110; // speed set     --> speed must be set when using position controller
        DesireSpeed_Write(speed);

        //control on/off
        PositionControlOnOff_Write(CONTROL);
        
        int gain = 5;
        PositionProportionPoint_Write(gain);

        int move_distance = 865; //**1
        
        if(move_distance>0)
           DesireEncoderCount_Write(move_distance);

      int sleep_time = (move_distance/500)*1000000 + 2000000;
        usleep(sleep_time);
      PositionControlOnOff_Write(UNCONTROL);

        SteeringServoControl_Write(1950);
        usleep(25000);
        move_distance = 998; //**2
        
        DesireSpeed_Write(speed);
       PositionControlOnOff_Write(CONTROL);

        if(move_distance>0)
       DesireEncoderCount_Write(move_distance);
       usleep(sleep_time);

       PositionControlOnOff_Write(UNCONTROL);
       DesireSpeed_Write(100);
       SteeringServoControl_Write(1507);
       Winker_Write(ALL_OFF);
        overtaking_step++;
   }
   else if(overtaking_step == 22)
   {

      Mat img;
      input_img.copyTo(img);

      //Mat img_grayscale;
      //cvtColor(img,img_grayscale,COLOR_RGB2GRAY);

      //Mat img_threshold;
      //threshold(img_grayscale,img_threshold,threshold_value,255,THRESH_BINARY);
      Mat img_warp;
      Mat img_yellow;
      inRange_yellow(img, img_yellow);
      WARP(img_yellow, img_warp);


//      WARP(img_threshold, img_warp);

      //calculate_steering_angle5(img_warp, img_warp, 1);
      overtaking_lane_driving(img_warp, output_img);

      int dist_5;
      dist_5 = dist_milli(5);

      if(dist_5 < 250)   // overtaking start!
      {
         Winker_Write(LEFT_ON);
         overtaking_step++;
      }
      return 0;

   }
   else if(overtaking_step == 23)
   {
      Mat img;
      input_img.copyTo(img);

      Mat img_warp;
      Mat img_yellow;
      inRange_yellow(img, img_yellow);
      WARP(img_yellow, img_warp);


      overtaking_lane_driving(img_warp, output_img);

      int dist_5;
      dist_5 = dist_milli(5);

      if(dist_5 > 250)   // overtaking end!
      {
         SteeringServoControl_Write(1950);
         overtaking_step++;
      }
      return 0;
   }
   else if(overtaking_step == 24)
   {
      int speed = 110; // speed set     --> speed must be set when using position controller
        DesireSpeed_Write(speed);

        //control on/off
        PositionControlOnOff_Write(CONTROL);
        
        int gain = 5;
        PositionProportionPoint_Write(gain);

        int move_distance = 1000; //**3
        
        if(move_distance>0)
           DesireEncoderCount_Write(move_distance);

      int sleep_time = (move_distance/500)*1000000 + 2000000;
        usleep(sleep_time);
        PositionControlOnOff_Write(UNCONTROL);


   
        SteeringServoControl_Write(1050);
        usleep(25000);

      DesireSpeed_Write(speed);
       PositionControlOnOff_Write(CONTROL);

        move_distance = 950; //**4
        
        if(move_distance>0)
           DesireEncoderCount_Write(move_distance);
       
       usleep(sleep_time);

       PositionControlOnOff_Write(UNCONTROL);
       // SteeringServoControl_Write(1507);
       // usleep(25000);
       // DesireSpeed_Write(80);

       DesireSpeed_Write(0);
       SteeringServoControl_Write(1507);
       usleep(100000);
        overtaking_step=50;
        Winker_Write(ALL_OFF);
   }




///////////////////////////////////////////////////////////////
   else if(overtaking_step == 30)   //turn left
   {
//      Winker_Write(ALL_OFF);

      SteeringServoControl_Write(1950);
      overtaking_step++;
   }
    else if(overtaking_step == 31)
    {
        int speed = 110; // speed set     --> speed must be set when using position controller
       DesireSpeed_Write(speed);

       //control on/off
       PositionControlOnOff_Write(CONTROL);
       
       int gain = 5;
       PositionProportionPoint_Write(gain);

       int move_distance = 980; //**1L
       
       if(move_distance>0)
            DesireEncoderCount_Write(move_distance);

        int sleep_time = (move_distance/500)*1000000 + 2000000;
       usleep(sleep_time);
       PositionControlOnOff_Write(UNCONTROL);


       SteeringServoControl_Write(1050);
       usleep(25000);
       move_distance = 970; //**2L
       DesireSpeed_Write(speed);
       PositionControlOnOff_Write(CONTROL);
       if(move_distance>0)
            DesireEncoderCount_Write(move_distance);

        usleep(sleep_time);
           
        PositionControlOnOff_Write(UNCONTROL);
        DesireSpeed_Write(80);
        SteeringServoControl_Write(1507);
        Winker_Write(ALL_OFF);
       overtaking_step++;

      
    }
    else if(overtaking_step == 32)
    {
        Mat img;
        input_img.copyTo(img);

         Mat img_warp;
         Mat img_yellow;
      inRange_yellow(img, img_yellow);
      WARP(img_yellow, img_warp);

        //calculate_steering_angle5(img_warp, img_warp, 1);
        overtaking_lane_driving(img_warp, output_img);
        

        int dist_3;
        dist_3 = dist_milli(3);

        if(dist_3 < 250)        // overtaking start!
        {

           Winker_Write(RIGHT_ON);
            overtaking_step++;
        }
        return 0;
    }
    else if(overtaking_step == 33)
    {
        Mat img;
        input_img.copyTo(img);

        Mat img_warp;
        Mat img_yellow;
      inRange_yellow(img, img_yellow);
      WARP(img_yellow, img_warp);

        overtaking_lane_driving(img_warp, output_img);

        int dist_3;
        dist_3 = dist_milli(3);

        if(dist_3 > 250)        // overtaking end!
        {
            SteeringServoControl_Write(1050);
            overtaking_step++;
        }
        return 0;
    }
    else if(overtaking_step == 34)
    {
        int speed = 110; // speed set     --> speed must be set when using position controller
       DesireSpeed_Write(speed);

       //control on/off
       PositionControlOnOff_Write(CONTROL);
       
       int gain = 5;
       PositionProportionPoint_Write(gain);

       int move_distance = 995; //**3L
       
       if(move_distance>0)
            DesireEncoderCount_Write(move_distance);

        int sleep_time = (move_distance/500)*1000000 + 2000000;
       usleep(sleep_time);
       PositionControlOnOff_Write(UNCONTROL);


       SteeringServoControl_Write(1950);
       usleep(25000);

       DesireSpeed_Write(speed);
       PositionControlOnOff_Write(CONTROL);

       move_distance = 950; //**4L
       
       if(move_distance>0)
            DesireEncoderCount_Write(move_distance);
           
        usleep(sleep_time);
/*org
        PositionControlOnOff_Write(UNCONTROL);
        DesireSpeed_Write(80);

        Winker_Write(ALL_OFF);
       overtaking_step=50;
*/


       PositionControlOnOff_Write(UNCONTROL);
       // SteeringServoControl_Write(1507);
       // usleep(25000);
       // DesireSpeed_Write(80);

       DesireSpeed_Write(0);
        overtaking_step=50;
        Winker_Write(ALL_OFF);

    }
    else if(overtaking_step==50)
    {
       return 1;
    }



   input_img.copyTo(output_img);
   return 0;
}
/*
int overtaking(Mat input_img, Mat& output_img)
{
	if(overtaking_step == 1)
	{
		Mat img;
		input_img.copyTo(img);

		Mat img_grayscale;
		cvtColor(img,img_grayscale,COLOR_RGB2GRAY);

		Mat img_threshold;
		threshold(img_grayscale,img_threshold,threshold_value,255,THRESH_BINARY);

		Mat img_warp;
		WARP(img_threshold,img_warp);

		calculate_steering_angle5(img_warp, img_warp, 1);

		int dist_1;
			dist_1 = dist_milli(1);

		if(dist_1<300)
		{
			
			if(dist_1 <250)
			{
				DesireSpeed_Write(-50);
			}
			else if(dist_1 > 280)
			{
				DesireSpeed_Write(50);
			}
			else
			{
				overtaking_step ++;
				DesireSpeed_Write(0);
			}
		}
		//cvtColor(img_warp,img_warp,COLOR_GRAY2BGR);
	
		img_warp.copyTo(output_img);
		return 0;

	}
	else if(overtaking_step == 2)
	{
		CameraXServoControl_Write(1800);
		usleep(700000);
		overtaking_step++;

	}
	else if(overtaking_step < 8)
	{
		usleep(10000);
		overtaking_step++;
	}
	else if(overtaking_step == 8)
	{
		Mat img_left;
		input_img.copyTo(img_left);

		Mat img_left_grayscale;
		cvtColor(img_left, img_left_grayscale, COLOR_RGB2GRAY);

		Mat img_left_threshold;
		threshold(img_left_grayscale, img_left_threshold, 70, 255, THRESH_BINARY);

		for(int row = 50; row < 100; row++)
		{
			uchar* overtake_left_row = img_left_threshold.ptr<uchar>(row);

			for(int col = 120; col<200; col++)
			{
				if(overtake_left_row[col] == 0)
					overtaking_left_count++;
			}
		}
		cout<<" LEFT count : "<<overtaking_left_count<<endl;
		overtaking_step++;
	}
	else if(overtaking_step == 9)
	{
		CameraXServoControl_Write(1200);
		usleep(700000);
		overtaking_step++;
	}
	else if(overtaking_step < 15)
	{
		usleep(10000);
		overtaking_step++;
	}
	else if(overtaking_step == 15)
	{
		Mat img_right;
		input_img.copyTo(img_right);

		Mat img_right_grayscale;
		cvtColor(img_right, img_right_grayscale, COLOR_RGB2GRAY);

		Mat img_right_threshold;
		threshold(img_right_grayscale, img_right_threshold, 70, 255, THRESH_BINARY);

		for(int row = 50; row < 100; row++)
		{
			uchar* overtake_right_row = img_right_threshold.ptr<uchar>(row);

			for(int col = 120; col<200; col++)
			{
				if(overtake_right_row[col] == 0)
					overtaking_right_count++;
			}
		}
		cout<<" RIGHT count : "<<overtaking_right_count<<endl;
		overtaking_step++;
	}
	else if(overtaking_step == 16)
	{
		if(overtaking_left_count > overtaking_right_count)
		{
			Winker_Write(RIGHT_ON);
			overtaking_step = 20;	//turn right 		
		}
		else if(overtaking_left_count < overtaking_right_count)
		{
			Winker_Write(LEFT_ON);
			overtaking_step = 30;	//turn left
		}
		CameraXServoControl_Write(1500);
		usleep(500000);
		//overtaking_step++;
	}
	else if(overtaking_step == 20)	//turn right
	{
		//Winker_Write(ALL_OFF);
		//overtaking_step++;
		SteeringServoControl_Write(1050);
		overtaking_step++;
	}
	else if(overtaking_step == 21)
	{
		int speed = 100; // speed set     --> speed must be set when using position controller
        DesireSpeed_Write(speed);

        //control on/off
        PositionControlOnOff_Write(CONTROL);
        
        int gain = 5;
        PositionProportionPoint_Write(gain);

        int move_distance = 900;
        
        if(move_distance>0)
	        DesireEncoderCount_Write(move_distance);

		int sleep_time = (move_distance/500)*1000000 + 1000000;
        usleep(sleep_time);
		PositionControlOnOff_Write(UNCONTROL);

        SteeringServoControl_Write(1950);
        usleep(25000);
        move_distance = 1000;
        
        DesireSpeed_Write(speed);
	    PositionControlOnOff_Write(CONTROL);

        if(move_distance>0)
	        DesireEncoderCount_Write(move_distance);
	    usleep(sleep_time);

	    PositionControlOnOff_Write(UNCONTROL);
	    DesireSpeed_Write(80);
	    SteeringServoControl_Write(1507);
	    Winker_Write(ALL_OFF);
        overtaking_step++;
	}
	else if(overtaking_step == 22)
	{
		Mat img;
		input_img.copyTo(img);

		//Mat img_grayscale;
		//cvtColor(img,img_grayscale,COLOR_RGB2GRAY);

		//Mat img_threshold;
		//threshold(img_grayscale,img_threshold,threshold_value,255,THRESH_BINARY);
		Mat img_warp;
		Mat img_yellow;
		inRange_yellow(img, img_yellow);
		WARP(img_yellow, img_warp);


//		WARP(img_threshold, img_warp);

		//calculate_steering_angle5(img_warp, img_warp, 1);
		overtaking_lane_driving(img_warp, output_img);

		int dist_5;
		dist_5 = dist_milli(5);

		if(dist_5 < 250)	// overtaking start!
		{
			Winker_Write(LEFT_ON);
			overtaking_step++;
		}
		return 0;

	}
	else if(overtaking_step == 23)
	{
		Mat img;
		input_img.copyTo(img);

		Mat img_warp;
		Mat img_yellow;
		inRange_yellow(img, img_yellow);
		WARP(img_yellow, img_warp);


		overtaking_lane_driving(img_warp, output_img);

		int dist_5;
		dist_5 = dist_milli(5);

		if(dist_5 > 250)	// overtaking end!
		{
			SteeringServoControl_Write(1950);
			overtaking_step++;
		}
		return 0;
	}
	else if(overtaking_step == 24)
	{
		int speed = 100; // speed set     --> speed must be set when using position controller
        DesireSpeed_Write(speed);

        //control on/off
        PositionControlOnOff_Write(CONTROL);
        
        int gain = 5;
        PositionProportionPoint_Write(gain);

        int move_distance = 1000;
        
        if(move_distance>0)
	        DesireEncoderCount_Write(move_distance);

		int sleep_time = (move_distance/500)*1000000 + 1000000;
        usleep(sleep_time);
        PositionControlOnOff_Write(UNCONTROL);


	
        SteeringServoControl_Write(1050);
        usleep(25000);

		DesireSpeed_Write(speed);
	    PositionControlOnOff_Write(CONTROL);

        move_distance = 950;
        
        if(move_distance>0)
	        DesireEncoderCount_Write(move_distance);
	    
	    usleep(sleep_time);

	    PositionControlOnOff_Write(UNCONTROL);
	    SteeringServoControl_Write(1507);
	    usleep(25000);
	    DesireSpeed_Write(80);


        overtaking_step=50;
        Winker_Write(ALL_OFF);

	}





	else if(overtaking_step == 30)	//turn left
	{
//		Winker_Write(ALL_OFF);

		SteeringServoControl_Write(1950);
		overtaking_step++;
	}
    else if(overtaking_step == 31)
    {
        int speed = 100; // speed set     --> speed must be set when using position controller
 		DesireSpeed_Write(speed);

    	//control on/off
	    PositionControlOnOff_Write(CONTROL);
	    
	    int gain = 5;
	    PositionProportionPoint_Write(gain);

	    int move_distance = 1000;
	    
	    if(move_distance>0)
            DesireEncoderCount_Write(move_distance);

        int sleep_time = (move_distance/500)*1000000 + 1000000;
	    usleep(sleep_time);
	    PositionControlOnOff_Write(UNCONTROL);


	    SteeringServoControl_Write(1050);
	    usleep(25000);
	    move_distance = 1000;
	    DesireSpeed_Write(speed);
	    PositionControlOnOff_Write(CONTROL);
	    if(move_distance>0)
            DesireEncoderCount_Write(move_distance);

        usleep(sleep_time);
	        
        PositionControlOnOff_Write(UNCONTROL);
        DesireSpeed_Write(80);
        SteeringServoControl_Write(1507);
        Winker_Write(ALL_OFF);
	    overtaking_step++;

	   
    }
    else if(overtaking_step == 32)
    {
        Mat img;
        input_img.copyTo(img);

   		Mat img_warp;
   		Mat img_yellow;
		inRange_yellow(img, img_yellow);
		WARP(img_yellow, img_warp);

        //calculate_steering_angle5(img_warp, img_warp, 1);
        overtaking_lane_driving(img_warp, output_img);
        

        int dist_3;
        dist_3 = dist_milli(3);

        if(dist_3 < 250)        // overtaking start!
        {

        	Winker_Write(RIGHT_ON);
            overtaking_step++;
        }
        return 0;
    }
    else if(overtaking_step == 33)
    {
        Mat img;
        input_img.copyTo(img);

        Mat img_warp;
        Mat img_yellow;
		inRange_yellow(img, img_yellow);
		WARP(img_yellow, img_warp);

        overtaking_lane_driving(img_warp, output_img);

        int dist_3;
        dist_3 = dist_milli(3);

        if(dist_3 > 250)        // overtaking end!
        {
            SteeringServoControl_Write(1050);
            overtaking_step++;
        }
        return 0;
    }
    else if(overtaking_step == 34)
    {
        int speed = 100; // speed set     --> speed must be set when using position controller
	    DesireSpeed_Write(speed);

	    //control on/off
	    PositionControlOnOff_Write(CONTROL);
	    
	    int gain = 5;
	    PositionProportionPoint_Write(gain);

	    int move_distance = 1000;
	    
	    if(move_distance>0)
            DesireEncoderCount_Write(move_distance);

        int sleep_time = (move_distance/500)*1000000 + 1000000;
	    usleep(sleep_time);
	    PositionControlOnOff_Write(UNCONTROL);


	    SteeringServoControl_Write(1950);
	    usleep(25000);

	    DesireSpeed_Write(speed);
	    PositionControlOnOff_Write(CONTROL);

	    move_distance = 1000;
	    
	    if(move_distance>0)
            DesireEncoderCount_Write(move_distance);
	        
        usleep(sleep_time);
        PositionControlOnOff_Write(UNCONTROL);
        DesireSpeed_Write(80);

        Winker_Write(ALL_OFF);
	    overtaking_step=50;

    }
    else if(overtaking_step==50)
    {
    	return 1;
    }



	input_img.copyTo(output_img);
	return 0;
}
*/

// 2020-10-05 11 :14 AM 
/* 
* input_img : warp_img, grayscale, white or yellow inRange;
*/


int overtaking_lane_driving(Mat input_img, Mat& output_img)
{
	Mat img;
	input_img.copyTo(img);

//이미지 표시용 Mat 선언
	Mat img_line;

	//보조선
	cvtColor(img, img_line, COLOR_GRAY2BGR);

	Mat img_warp_rotate(img.cols,img.rows,CV_8UC1);
	
	bool left_check = 0, right_check = 0;
	int curve_y=0,left_x = 0, right_x = 0;

	double angle = 0;

	int steering_angle = 1507;

	for (int i = 0; i < img.cols;i++)	//rows
	{
		uchar* img_warp_rotate_pointer_row = img_warp_rotate.ptr<uchar>(i);
		for (int j = 0; j < img.rows;j++)	//cols
		{
			img_warp_rotate_pointer_row[j] = img.at<uchar>(179-j,i);
		}
	}


//커브 검출
	uchar* curve_pointer_row = img_warp_rotate.ptr<uchar>(160);
	
	int h_lane_detect = 0;

	for (int col = 0; col < 180; col++)
	{
		uchar color = curve_pointer_row[col];
		//printf("%d ", color);
		if (color > 0)
		{
			printf("CURVE OK\n");
			h_lane_detect = 1;
			curve_y = col;
			circle(img_line, Point(160, 180 - col), 5, Scalar(0, 0, 255), -1);
			break;
		}
	}



	if( h_lane_detect)
	{
		int left = 0, right = 0;

		uchar* img_warp_rotate_pointer_row = img_warp_rotate.ptr<uchar>(100);
		for (int i = 0; i< 179; i++)
		{
			if(img_warp_rotate_pointer_row[i] && img_warp_rotate_pointer_row[i+1])
			{
				left = i;
				break;
			}
			
		}
		img_warp_rotate_pointer_row = img_warp_rotate.ptr<uchar>(220);
		for (int i = 0; i< 179; i++)
		{
			if(img_warp_rotate_pointer_row[i]  && img_warp_rotate_pointer_row[i+1] )
			{
				right = i;
				break;
			}
			
		}

		int left_right_sub;
		left_right_sub = abs(left-right);

		if(left&&right&&left_right_sub<10)
		{

			SteeringServoControl_Write(1507 + (right-left)*10);
			line(img_line, Point2f(80,180-left),Point2f(240,180-right), Scalar(0,0,255),2);

		}
	}
	else
	{
		//직진 차선 검출 왼쪽
		uchar* left_pointer_row = img.ptr<uchar>(90);
		for (int col = 9; col < 149; col += 2)
		{
			uchar color1 = left_pointer_row[col];
			uchar color2 = left_pointer_row[col + 1];
			//printf("%d ", color);
			if (color1 > 0 && color2 > 0)
			{
				printf("LEFT OK\n");
				left_check = 1;
				left_x = col;
				circle(img_line, Point(col, 90), 5, Scalar(0, 0, 255), -1);
				break;
			}
		}


		//직진 차선 검출 오른쪽
		uchar* right_pointer_row = img.ptr<uchar>(90);
		for (int col = 309; col > 169; col -= 2)
		{
			uchar color1 = right_pointer_row[col];
			uchar color2 = right_pointer_row[col - 1];
			//printf("%d ", color);
			if (color1 > 0 && color2 > 0)
			{
				right_check = 1;
				printf("RIGHT OK\n");
				right_x = col;
				circle(img_line, Point(col, 90), 5, Scalar(0, 0, 255), -1);
				break;
			}
		}


		if(left_check)
		{
			circle(img_line, Point(left_x + 215, 90), 5, Scalar(220, 100, 220), -1);
					
			int avg_x = (left_x*2 + 215) / 2;
			angle = atan2(160 - avg_x, 90)*180/CV_PI;
			printf("angle : %lf\n", angle);

		
			line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
		}
		else if(right_check)
		{
			circle(img_line, Point(right_x - 215, 90), 5, Scalar(220, 100, 220), -1);

			int avg_x = (right_x * 2 - 215) / 2;
			angle = atan2(160 - avg_x, 90)*180/CV_PI;
			printf("angle : %lf\n", angle);

			line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
		}


		if (angle > -50 && angle < 50)
		{
			//cout<<"test"<<endl;
			steering_angle = 1507 + angle * 5;
			
			SteeringServoControl_Write(steering_angle);
			//usleep(50000);
		}
	}
	img_line.copyTo(output_img);
	return 0;
}








// 2020-09-28 04 :12 PM 
int calculate_steering_angle5(Mat input_img, Mat& output_img, bool steering_control_onoff)
{
	//input_img 는 WARP 이미지 입력받아야함

	Mat img;
	input_img.copyTo(img);

	int steering_angle = 1507;

	//이미지 회전
	// Mat img_warp_rotate;
	// rotate(img, img_warp_rotate, 1);

	Mat img_warp_rotate(img.cols,img.rows,CV_8UC1);
		
	for (int i = 0; i < img.cols;i++)	//rows
	{
		uchar* img_warp_rotate_pointer_row = img_warp_rotate.ptr<uchar>(i);
		for (int j = 0; j < img.rows;j++)	//cols
		{
			img_warp_rotate_pointer_row[j] = img.at<uchar>(179-j,i);
		}
	}

	//이미지 표시용 Mat 선언
	Mat img_line;
	input_img.copyTo(img_line);

	//보조선
	cvtColor(img_line, img_line, COLOR_GRAY2BGR);
	line(img_line, Point2f(0, 90), Point2f(320, 90), Scalar(0, 255, 255), 2);
	line(img_line, Point2f(160, 90), Point2f(160, 180), Scalar(255, 0, 255), 2);

	// 직진 차선 검출용
	line(img_line, Point2f(9, 90), Point2f(149, 90), Scalar(0, 255, 0), 2);
	line(img_line, Point2f(169, 90), Point2f(309, 90), Scalar(0, 255, 0), 2);

	// 직진 차선 중앙 유지용
	line(img_line, Point2f(52, 80), Point2f(52, 100), Scalar(0, 0, 255), 2);
	line(img_line, Point2f(267, 80), Point2f(267, 100), Scalar(0, 0, 255), 2);


	bool curve_check = 0, left_check = 0, right_check = 0;
	int curve_y = 0, left_x = 0, right_x = 0;

	double angle = 0;

	

	//커브 검출
	uchar* curve_pointer_row = img_warp_rotate.ptr<uchar>(160);
	for (int col = 0; col < 180; col++)
	{
		uchar color = curve_pointer_row[col];
		//printf("%d ", color);
		if (color > 0)
		{
			printf("CURVE OK\n");
			curve_check = 1;
			curve_y = col;
			circle(img_line, Point(160, 180 - col), 5, Scalar(0, 0, 255), -1);
			break;
		}
	}


	//직진 차선 검출 왼쪽
	uchar* left_pointer_row = img.ptr<uchar>(90);
	for (int col = 9; col < 149; col += 2)
	{
		uchar color1 = left_pointer_row[col];
		uchar color2 = left_pointer_row[col + 1];
		//printf("%d ", color);
		if (color1 > 0 && color2 > 0)
		{
			printf("LEFT OK\n");
			left_check = 1;
			left_x = col;
			circle(img_line, Point(col, 90), 5, Scalar(0, 0, 255), -1);
			break;
		}
	}


	//직진 차선 검출 오른쪽
	uchar* right_pointer_row = img.ptr<uchar>(90);
	for (int col = 309; col > 169; col -= 2)
	{
		uchar color1 = right_pointer_row[col];
		uchar color2 = right_pointer_row[col - 1];
		//printf("%d ", color);
		if (color1 > 0 && color2 > 0)
		{
			right_check = 1;
			printf("RIGHT OK\n");
			right_x = col;
			circle(img_line, Point(col, 90), 5, Scalar(0, 0, 255), -1);
			break;
		}
	}


	if( lane_mode == 0 )	//직진
	{
		if (curve_check)
		{
			if(curve_y<80)
			{
				short speed;
				speed = DesireSpeed_Read();

				if(speed>100)
				{
					DesireSpeed_Write(100);
				}
			}
			

			if(curve_y<=40)
			{
				int left_pixel_count = 0, right_pixel_count = 0;

				for(int row = 90; row<170; row++)
				{
					uchar* curve_down_pointer_row = img.ptr<uchar>(row);

					for(int col = 0; col<160; col++)
					{
						uchar left_pixel = curve_down_pointer_row[col];
						if(left_pixel>0)
							left_pixel_count++;
					}
					for(int col = 160; col<320; col++)
					{
						uchar right_pixel = curve_down_pointer_row[col];
						if(right_pixel>0)
							right_pixel_count++;
					}
				}

				if(left_pixel_count>right_pixel_count)
				{
					lane_mode = 1;
				}
				else
				{
					lane_mode = -1;
				}

			}
			

		}
		else
		{

			if (left_check && right_check)
			{
				int avg_x=(left_x +  right_x)/2;
				angle = atan2(160 - avg_x, 90)*180/CV_PI;
				printf("angle : %lf\n", angle);

				line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
			}
			else if (left_check && !right_check)
			{//215
				circle(img_line, Point(left_x + 215, 90), 5, Scalar(220, 100, 220), -1);
				
				int avg_x = (left_x*2 + 215) / 2;
				angle = atan2(160 - avg_x, 90)*180/CV_PI;
				printf("angle : %lf\n", angle);

				line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
			}
			else if (!left_check && right_check)
			{
				circle(img_line, Point(right_x - 215, 90), 5, Scalar(220, 100, 220), -1);

				int avg_x = (right_x * 2 - 215) / 2;
				angle = atan2(160 - avg_x, 90)*180/CV_PI;
				printf("angle : %lf\n", angle);

				line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
			}
		}

	}
	else if(lane_mode==1)	//좌회전
	{
		if (left_check && right_check && !curve_check)
		{
			lane_mode=0;
			short speed;
			speed = DesireSpeed_Read();

			if(speed>0)
			{
				DesireSpeed_Write(main_speed);
			}
		}
	}
	else if(lane_mode==-1)	//우회전
	{
		if (left_check && right_check && !curve_check)
		{
			lane_mode=0;
			short speed;
			speed = DesireSpeed_Read();

			if(speed>0)
			{
				DesireSpeed_Write(main_speed);
			}
		}

	}

	
	if(lane_mode==1)
	{
		//steering_angle = 1950;
		steering_angle = 1950;
		if (steering_control_onoff == 1)
			SteeringServoControl_Write(steering_angle);
	}
	else if(lane_mode==-1)
	{
		// steering_angle = 1050;
				steering_angle = 1050;
		if (steering_control_onoff == 1)
			SteeringServoControl_Write(steering_angle);
	}
	else if (angle > -50 && angle < 50)
	{
		//cout<<"test"<<endl;
		steering_angle = 1507 + angle * 5;
		if (steering_control_onoff == 1)
			SteeringServoControl_Write(steering_angle);
		//usleep(50000);
	}


	
		


	img_line.copyTo(output_img);

	if (!left_check && !right_check && !curve_check)
	{
		return 0;
	}


	return steering_angle;
}









// 2020-09-27 11 :43 PM 
/*
	2020 09 20 작성
	return	0 : 미션 끝
			1 : 미션 도중
	//highway_end_count > 5  :  FINISH

	// 2020-09-27 08 :10 PM 
	modifying
	using distance_driving_4 !!
	perfectly!!!	
*/
// 2020-09-28 02 :17 PM 
// Add When on the downhill, speed slowly!
// Perfect!

int highway(Mat input_img, Mat &output_img)
{
	Mat highway_img;
	input_img.copyTo(highway_img);

	if(highway_step == 0)
	{
		if(dist_milli(1) < 150)
		{
			char myText[20]="start";
			putText(highway_img, myText, Point(140,90), 3, 1, Scalar(0,0,255), 1, 8);

			highway_step++;
			
		}
		
	}
	else if(highway_step ==1)
	{
		sleep(2);
		highway_step++;
	}
	else if(highway_step == 2)
	{
		//int speed = 180;
        DesireSpeed_Write(main_speed);
        highway_step++;
	}
	else if(highway_step == 3)
	{
		if( gloabal_encoder_read > 7000 && downhill_check==0)
		{
			downhill_check = 1;
			CarLight_Write(REAR_ON);
			DesireSpeed_Write(120);
		}
		if(distance_driving_4(highway_img, highway_img, 1) == 0)
		{
			highway_img.copyTo(output_img);
			downhill_check = 0;
			CarLight_Write(ALL_OFF);
			return 0;
		}
	}
	
	highway_img.copyTo(output_img);

	return 1;
}


// 2020-09-27 11 :48 PM 
// 	return
//	1 : escape mission ( 2, 6 : O )
//	0 : no detect

int distance_driving_4(Mat input_img, Mat& output_img,int steering_control_onoff)
{
	
	// steering_control_onoff
	//	1 = on
	//	0 = off

	// return 
	// 0 : escape mission
	// steering_angle

	Mat img;
	input_img.copyTo(img);
	
	int dist_num[7];	//add null data
		dist_num[0] = 0;	
		dist_num[1] = 0;	//dist_2
		dist_num[2] = 0;	//dist_3
		dist_num[3] = 0;
		dist_num[4] = 0;	//dist_5
		dist_num[5] = 0;	//dist_6



	Point dist_pt[7];
		dist_pt[0] = Point(140, 40);
		dist_pt[1] = Point(210, 70);
		dist_pt[2] = Point(210, 130);
		dist_pt[3] = Point(140, 160);
		dist_pt[4] = Point(90, 130);
		dist_pt[5] = Point(90, 70);

	for (int i = 0; i < 6; i++)
	{
		if(i!=0 && i!=3)
		{
			char myText[20];
			dist_num[i] = dist_milli(i + 1);
			//myText = double.toString(dist_cesnti(i+1));
			sprintf(myText, "%d", dist_num[i]);
			//sprintf(myText, "%d", i+1);
			if(dist_num[i]<80)
			{
				putText(img, myText, dist_pt[i], 3, 1, Scalar(0,0,255), 1, 8);
			}
			else if(dist_num[i]<150)
			{
				putText(img, myText, dist_pt[i], 3, 1, Scalar(0,255,0), 1, 8);
			}
			else if(dist_num[i]<250)
			{
				putText(img, myText, dist_pt[i], 3, 1, Scalar(255,0,0), 1, 8);
			}
			else 
				putText(img, myText, dist_pt[i], 3, 1, Scalar::all(255), 1, 8);

		}		
	}

	img.copyTo(output_img);

	int dist_2 = 0;
	int dist_3 = 0;
	int dist_5 = 0;
	int dist_6 = 0;

	int steering_angle = 1507;

	if (dist_num[1] < 220)
		dist_2 = dist_num[1];
	if (dist_num[2] < 220)
		dist_3 = dist_num[2];
	if (dist_num[4] < 220)
		dist_5 = dist_num[4];
	if (dist_num[5] < 220)
		dist_6 = dist_num[5];



	if (dist_2 + dist_3 + dist_5 + dist_6 == 0)
	{
		cout << "non detect" << endl;
		return 0;
	}

	

	if(!dist_2 && dist_3 && dist_5 && dist_6)
	{
		if(pre_speed_check == 0 && downhill_check==0)
		{
			pre_speed = DesireSpeed_Read();
			int curve_speed = 150;

			if(pre_speed >150)
				DesireSpeed_Write(curve_speed);
			
			cout<<"pre_speed : "<<pre_speed<<endl;
			pre_speed_check = 1;
		}
		
		

		steering_angle=1050;
		if (steering_control_onoff)
			SteeringServoControl_Write(steering_angle);

	}
	else if (dist_2 && dist_3 && dist_5 && dist_6 )
	{
		if(pre_speed_check == 1 && downhill_check == 0)
		{
			int now_speed = DesireSpeed_Read();

			if (now_speed<main_speed)
				DesireSpeed_Write(main_speed);
			cout<<"now_speed : "<<now_speed<<endl;
			pre_speed_check = 0;
		}

		// cout << "all distance detect" <<  endl;

		double left_angle = 0, right_angle = 0, avg_angle = 0;
		int left_dist, right_dist, sub_dist;
		left_dist = dist_5 + dist_6;
		right_dist = dist_2 + dist_3;
		sub_dist = left_dist - right_dist;

		left_angle = atan(double(dist_6 - dist_5) / 280) * 180 / CV_PI;
		right_angle = atan(double(dist_3 - dist_2) / 280) * 180 / CV_PI;
		avg_angle = (left_angle + right_angle) / 2;

		// cout<<"left_angle : " << left_angle <<endl;
		// cout<<"right_angle : " << right_angle <<endl;

		//cout << "avg_angle : " << avg_angle << endl;
		//    / : '-'  , \ : '+'

		steering_angle = 1507 + int(avg_angle * 16.67) + sub_dist;
		if (steering_angle <= 1000)
			steering_angle = 1000;
		else if (steering_angle >= 2000)
			steering_angle = 2000;

		//cout << "steering_angle : " << steering_angle << endl;
		// 60 : 1000, 90 : 1507,  120 : 2000
		if (steering_control_onoff)
			SteeringServoControl_Write(steering_angle);

		pre_dist2 = dist_2;
		pre_dist3 = dist_3;
		pre_dist5 = dist_5;
		pre_dist6 = dist_6;
		pre_encoder = EncoderCounter_Read();
		usleep(10000);
	}
	else if (dist_2 && dist_6)
	{
		//cout << "front distance detect" << endl;
		//pre_dist_right = dist_2, pre_dist_left = dist_6;


		double left_angle = 0, right_angle = 0, avg_angle = 0;

		int left_dist, right_dist, sub_dist;
		left_dist = dist_6;
		right_dist = dist_2;
		sub_dist = left_dist - right_dist;


		int now_encoder = EncoderCounter_Read();
		usleep(10000);
		//cout << "now_encoder : " << now_encoder << endl;
		//cout << "pre_encoder_front : " << pre_encoder << endl;


		if (now_encoder != pre_encoder && pre_dist2 && pre_dist6)
		{
			left_angle = atan(double(dist_6 - pre_dist6) / double((now_encoder - pre_encoder) / 2)) * 180 / CV_PI;

			right_angle = atan(double(pre_dist2 - dist_2) / double((now_encoder - pre_encoder) / 2)) * 180 / CV_PI;

			avg_angle = (left_angle + right_angle) / 2;
		//	cout << "avg_angle : " << avg_angle << endl;



			steering_angle = 1507 + int(avg_angle * 16.67) + sub_dist;
			if (steering_angle <= 1000)
				steering_angle = 1000;
			else if (steering_angle >= 2000)
				steering_angle = 2000;

		//	cout << "steering_angle : " << steering_angle << endl;
			// 60 : 1000, 90 : 1507,  120 : 2000
			if (steering_control_onoff)
				SteeringServoControl_Write(steering_angle);
		}

		pre_dist2 = dist_2;
		pre_dist6 = dist_6;
		pre_encoder = now_encoder;

	}
	else if (dist_3 && dist_5 && !dist_2 && !dist_6)
	{
		//cout << "rear distance detect" << endl;

		if(pre_speed_check == 1)
		{
			int now_speed = DesireSpeed_Read();

			if (now_speed<pre_speed)
				DesireSpeed_Write(pre_speed);

			pre_speed_check = 0;
		}

		

		double left_angle = 0, right_angle = 0, avg_angle = 0;

		int left_dist, right_dist, sub_dist;
		left_dist = dist_5;
		right_dist = dist_3;
		sub_dist = left_dist - right_dist;


		int now_encoder = EncoderCounter_Read();
		usleep(10000);
		//cout << "now_encoder : " << now_encoder << endl;
		//cout << "pre_encoder_rear : " << pre_encoder << endl;

		if (now_encoder != pre_encoder && pre_dist3 && pre_dist5)
		{
			left_angle = atan(double(dist_5 - pre_dist5) / double((now_encoder - pre_encoder) / 2)) * 180 / CV_PI;

			right_angle = atan(double(pre_dist3 - dist_3) / double((now_encoder - pre_encoder) / 2)) * 180 / CV_PI;

			avg_angle = (left_angle + right_angle) / 2;
		//	cout << "avg_angle : " << avg_angle << endl;


			steering_angle = 1507 + int(avg_angle * 16.67) + sub_dist;
			if (steering_angle <= 1000)
				steering_angle = 1000;
			else if (steering_angle >= 2000)
				steering_angle = 2000;

		//	cout << "steering_angle : " << steering_angle << endl;
			// 60 : 1000, 90 : 1507,  120 : 2000
			if (steering_control_onoff)
				SteeringServoControl_Write(steering_angle);
		

		}

		pre_dist3 = dist_3;
		pre_dist5 = dist_5;
		pre_encoder = now_encoder;

	}
	else
	{
		pre_dist2 = dist_2;
		pre_dist6 = dist_6;
		pre_dist3 = dist_3;
		pre_dist5 = dist_5;
		pre_encoder = EncoderCounter_Read();
		usleep(10000);
	}


	return steering_angle;
}
































int tunnel(Mat input_img, Mat &output_img)
{
	Mat tunnel_img;
	input_img.copyTo(tunnel_img);

	
	if(distance_driving_tunnel(tunnel_img, tunnel_img, 1) == 0)
	{
		//tunnel_step ++;	// tunnel END
		//CarLight_Write(ALL_OFF);
		tunnel_img.copyTo(output_img);
		return 1;
	}

	tunnel_img.copyTo(output_img);
	return 0;
}











// 2020-09-27 08 :17 PM 
// Developing ...
// roi pixel count system for turn

int calculate_steering_angle4(Mat input_img, Mat& output_img, bool steering_control_onoff)
{
	//input_img 는 WARP 이미지 입력받아야함

	Mat img;
	input_img.copyTo(img);

	int steering_angle = 1507;

	//이미지 회전
	// Mat img_warp_rotate;
	// rotate(img, img_warp_rotate, 1);

	Mat img_warp_rotate(img.cols,img.rows,CV_8UC1);
		
	for (int i = 0; i < img.cols;i++)	//rows
	{
		uchar* img_warp_rotate_pointer_row = img_warp_rotate.ptr<uchar>(i);
		for (int j = 0; j < img.rows;j++)	//cols
		{
			img_warp_rotate_pointer_row[j] = img.at<uchar>(179-j,i);
		}
	}

	//이미지 표시용 Mat 선언
	Mat img_line;
	input_img.copyTo(img_line);

	//보조선
	cvtColor(img_line, img_line, COLOR_GRAY2BGR);
	line(img_line, Point2f(0, 90), Point2f(320, 90), Scalar(0, 255, 255), 2);
	line(img_line, Point2f(160, 90), Point2f(160, 180), Scalar(255, 0, 255), 2);

	// 직진 차선 검출용
	line(img_line, Point2f(9, 90), Point2f(149, 90), Scalar(0, 255, 0), 2);
	line(img_line, Point2f(169, 90), Point2f(309, 90), Scalar(0, 255, 0), 2);

	// 직진 차선 중앙 유지용
	line(img_line, Point2f(52, 80), Point2f(52, 100), Scalar(0, 0, 255), 2);
	line(img_line, Point2f(267, 80), Point2f(267, 100), Scalar(0, 0, 255), 2);


	bool curve_check = 0, left_check = 0, right_check = 0;
	int curve_y = 0, left_x = 0, right_x = 0;

	double angle = 0;

	

	//커브 검출
	uchar* curve_pointer_row = img_warp_rotate.ptr<uchar>(160);
	for (int col = 0; col < 180; col++)
	{
		uchar color = curve_pointer_row[col];
		//printf("%d ", color);
		if (color > 0)
		{
			printf("CURVE OK\n");
			curve_check = 1;
			curve_y = col;
			circle(img_line, Point(160, 180 - col), 5, Scalar(0, 0, 255), -1);
			break;
		}
	}

	//직진 차선 검출 왼쪽
	uchar* left_pointer_row = img.ptr<uchar>(90);
	for (int col = 9; col < 149; col += 2)
	{
		uchar color1 = left_pointer_row[col];
		uchar color2 = left_pointer_row[col + 1];
		//printf("%d ", color);
		if (color1 > 0 && color2 > 0)
		{
			printf("LEFT OK\n");
			left_check = 1;
			left_x = col;
			circle(img_line, Point(col, 90), 5, Scalar(0, 0, 255), -1);
			break;
		}
	}

	//직진 차선 검출 오른쪽
	uchar* right_pointer_row = img.ptr<uchar>(90);
	for (int col = 309; col > 169; col -= 2)
	{
		uchar color1 = right_pointer_row[col];
		uchar color2 = right_pointer_row[col - 1];
		//printf("%d ", color);
		if (color1 > 0 && color2 > 0)
		{
			right_check = 1;
			printf("RIGHT OK\n");
			right_x = col;
			circle(img_line, Point(col, 90), 5, Scalar(0, 0, 255), -1);
			break;
		}
	}


	if( lane_mode == 0 )	//직진
	{
		if (curve_check)
		{
			if(curve_y<80)
			{
				short speed;
				speed = DesireSpeed_Read();

				if(speed>80)
				{
					DesireSpeed_Write(80);
				}
			}
			

			if(curve_y<=20)
			{
				int left_pixel_count = 0, right_pixel_count = 0;

				for(int row = 90; row<170; row++)
				{
					uchar* curve_down_pointer_row = img.ptr<uchar>(row);

					for(int col = 0; col<160; col++)
					{
						uchar left_pixel = curve_down_pointer_row[col];
						if(left_pixel>0)
							left_pixel_count++;
					}
					for(int col = 160; col<320; col++)
					{
						uchar right_pixel = curve_down_pointer_row[col];
						if(right_pixel>0)
							right_pixel_count++;
					}
				}

				if(left_pixel_count>right_pixel_count)
				{
					lane_mode = 1;
				}
				else
				{
					lane_mode = -1;
				}

			}
			

		}
		else
		{

			if (left_check && right_check)
			{
				int avg_x=(left_x +  right_x)/2;
				angle = atan2(160 - avg_x, 90)*180/CV_PI;
				printf("angle : %lf\n", angle);

				line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
			}
			else if (left_check && !right_check)
			{//215
				circle(img_line, Point(left_x + 215, 90), 5, Scalar(220, 100, 220), -1);
				
				int avg_x = (left_x*2 + 215) / 2;
				angle = atan2(160 - avg_x, 90)*180/CV_PI;
				printf("angle : %lf\n", angle);

				line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
			}
			else if (!left_check && right_check)
			{
				circle(img_line, Point(right_x - 215, 90), 5, Scalar(220, 100, 220), -1);

				int avg_x = (right_x * 2 - 215) / 2;
				angle = atan2(160 - avg_x, 90)*180/CV_PI;
				printf("angle : %lf\n", angle);

				line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
			}
		}

	}
	else if(lane_mode==1)	//좌회전
	{
		if (left_check && right_check)
		{
			lane_mode=0;
			short speed;
			speed = DesireSpeed_Read();

			if(speed>0)
			{
				DesireSpeed_Write(150);
			}
		}
	}
	else if(lane_mode==-1)	//우회전
	{
		if (left_check && right_check)
		{
			lane_mode=0;
			short speed;
			speed = DesireSpeed_Read();

			if(speed>0)
			{
				DesireSpeed_Write(150);
			}
		}

	}

	
	if(lane_mode==1)
	{
		steering_angle = 1950;
		if (steering_control_onoff == 1)
			SteeringServoControl_Write(steering_angle);
	}
	else if(lane_mode==-1)
	{
		steering_angle = 1050;
		if (steering_control_onoff == 1)
			SteeringServoControl_Write(steering_angle);
	}
	else if (angle > -50 && angle < 50)
	{
		//cout<<"test"<<endl;
		steering_angle = 1507 + angle * 5;
		if (steering_control_onoff == 1)
			SteeringServoControl_Write(steering_angle);
		//usleep(50000);
	}


	
		


	img_line.copyTo(output_img);

	if (!left_check && !right_check && !curve_check)
	{
		return 0;
	}


	return steering_angle;
}





/*2020 09 20 수정
	void -> int
	steering_control onoff 추가
	1 : ON
	0 : OFF
	return : steering angle 반환
	0 반환되면 정상 작동 X */
/*2020 09 19 제작*/
int calculate_steering_angle3(Mat input_img, Mat& output_img, bool steering_control_onoff)
{
	//input_img 는 WARP 이미지 입력받아야함

	Mat img;
	input_img.copyTo(img);

	int steering_angle = 1507;

	//이미지 회전
	// Mat img_warp_rotate;
	// rotate(img, img_warp_rotate, 1);

	Mat img_warp_rotate(img.cols,img.rows,CV_8UC1);
		
	for (int i = 0; i < img.cols;i++)	//rows
	{
		uchar* img_warp_rotate_pointer_row = img_warp_rotate.ptr<uchar>(i);
		for (int j = 0; j < img.rows;j++)	//cols
		{
			img_warp_rotate_pointer_row[j] = img.at<uchar>(179-j,i);
		}
	}

	//이미지 표시용 Mat 선언
	Mat img_line;
	input_img.copyTo(img_line);

	//보조선
	cvtColor(img_line, img_line, COLOR_GRAY2BGR);
	line(img_line, Point2f(0, 90), Point2f(320, 90), Scalar(0, 255, 255), 2);
	line(img_line, Point2f(160, 90), Point2f(160, 180), Scalar(255, 0, 255), 2);

	// 직진 차선 검출용
	line(img_line, Point2f(9, 90), Point2f(149, 90), Scalar(0, 255, 0), 2);
	line(img_line, Point2f(169, 90), Point2f(309, 90), Scalar(0, 255, 0), 2);

	// 직진 차선 중앙 유지용
	line(img_line, Point2f(52, 80), Point2f(52, 100), Scalar(0, 0, 255), 2);
	line(img_line, Point2f(267, 80), Point2f(267, 100), Scalar(0, 0, 255), 2);


	bool curve_check = 0, left_check = 0, right_check = 0;
	int curve_x = 0, curve_y = 0, left_x = 0, right_x = 0;

	double angle = 0;

	

	//커브 검출
	uchar* curve_pointer_row = img_warp_rotate.ptr<uchar>(160);
	for (int col = 0; col < 180; col++)
	{
		uchar color = curve_pointer_row[col];
		//printf("%d ", color);
		if (color > 0)
		{
			printf("CURVE OK\n");
			curve_check = 1;
			curve_y = col;
			circle(img_line, Point(160, 180 - col), 5, Scalar(0, 0, 255), -1);
			break;
		}
	}

	//직진 차선 검출 왼쪽
	uchar* left_pointer_row = img.ptr<uchar>(90);
	for (int col = 9; col < 149; col += 2)
	{
		uchar color1 = left_pointer_row[col];
		uchar color2 = left_pointer_row[col + 1];
		//printf("%d ", color);
		if (color1 > 0 && color2 > 0)
		{
			printf("LEFT OK\n");
			left_check = 1;
			left_x = col;
			circle(img_line, Point(col, 90), 5, Scalar(0, 0, 255), -1);
			break;
		}
	}

	//직진 차선 검출 오른쪽
	uchar* right_pointer_row = img.ptr<uchar>(90);
	for (int col = 309; col > 169; col -= 2)
	{
		uchar color1 = right_pointer_row[col];
		uchar color2 = right_pointer_row[col - 1];
		//printf("%d ", color);
		if (color1 > 0 && color2 > 0)
		{
			right_check = 1;
			printf("RIGHT OK\n");
			right_x = col;
			circle(img_line, Point(col, 90), 5, Scalar(0, 0, 255), -1);
			break;
		}
	}


	if( lane_mode == 0 )	//직진
	{
		if (curve_check)
		{
			if(curve_y<80)
			{
				short speed;
				speed = DesireSpeed_Read();

				if(speed>100)
				{
					DesireSpeed_Write(100);
				}
			}
			

			if(curve_y<=20)
			{

				uchar* curve_down_pointer_row = img.ptr<uchar>(140);
				for (int col = 0; col < 320; col += 2)
				{
					uchar color1 = curve_down_pointer_row[col];
					uchar color2 = curve_down_pointer_row[col - 1];
					//printf("%d ", color);
					if (color1 > 0 && color2 > 0)
					{
						printf("CURVE DOWN OK\n");
						curve_x = col;
						circle(img_line, Point(col, 110), 5, Scalar(0, 0, 255), -1);
						line(img_line, Point(160, 180 - curve_y), Point(curve_x, 140), Scalar(230, 180, 100), 3);

						angle = atan2((-curve_x + 160), (-curve_y + 10)) * 180 / CV_PI;
						if (angle>0)
						{
							lane_mode=1;
						}
						else if (angle<0)
						{
							lane_mode=-1;
						}
						printf("angle : %lf\n", angle);
						break;
					}
				}


			}
			

		}
		else
		{

			if (left_check && right_check)
			{
				int avg_x=(left_x +  right_x)/2;
				angle = atan2(160 - avg_x, 90)*180/CV_PI;
				printf("angle : %lf\n", angle);

				line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
			}
			else if (left_check && !right_check)
			{//215
				circle(img_line, Point(left_x + 215, 90), 5, Scalar(220, 100, 220), -1);
				
				int avg_x = (left_x*2 + 215) / 2;
				angle = atan2(160 - avg_x, 90)*180/CV_PI;
				printf("angle : %lf\n", angle);

				line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
			}
			else if (!left_check && right_check)
			{
				circle(img_line, Point(right_x - 215, 90), 5, Scalar(220, 100, 220), -1);

				int avg_x = (right_x * 2 - 215) / 2;
				angle = atan2(160 - avg_x, 90)*180/CV_PI;
				printf("angle : %lf\n", angle);

				line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
			}
		}

	}
	else if(lane_mode==1)	//좌회전
	{
		if (left_check && right_check)
		{
			lane_mode=0;
			short speed;
			speed = DesireSpeed_Read();

			if(speed>0)
			{
				DesireSpeed_Write(150);
			}
		}
	}
	else if(lane_mode==-1)	//우회전
	{
		if (left_check && right_check)
		{
			lane_mode=0;
			short speed;
			speed = DesireSpeed_Read();

			if(speed>0)
			{
				DesireSpeed_Write(150);
			}
		}

	}

	
	if(lane_mode==1)
	{
		steering_angle = 2000;
		if (steering_control_onoff == 1)
			SteeringServoControl_Write(steering_angle);
	}
	else if(lane_mode==-1)
	{
		steering_angle = 1000;
		if (steering_control_onoff == 1)
			SteeringServoControl_Write(steering_angle);
	}
	else if (angle > -50 && angle < 50)
	{
		//cout<<"test"<<endl;
		steering_angle = 1507 + angle * 5;
		if (steering_control_onoff == 1)
			SteeringServoControl_Write(steering_angle);
		//usleep(50000);
	}


	
		


	img_line.copyTo(output_img);

	if (!left_check && !right_check && !curve_check)
	{
		return 0;
	}


	return steering_angle;
}


void calculate_steering_angle2(Mat input_img, Mat& output_img)
{
	//input_img 는 WARP 이미지 입력받아야함



	Mat img;
	input_img.copyTo(img);

	//이미지 회전
	// Mat img_warp_rotate;
	// rotate(img, img_warp_rotate, 1);

	Mat img_warp_rotate(img.cols,img.rows,CV_8UC1);
		
	for (int i = 0; i < img.cols;i++)	//rows
	{
		uchar* img_warp_rotate_pointer_row = img_warp_rotate.ptr<uchar>(i);
		for (int j = 0; j < img.rows;j++)	//cols
		{
			img_warp_rotate_pointer_row[j] = img.at<uchar>(179-j,i);
		}
	}

	//이미지 표시용 Mat 선언
	Mat img_line;
	input_img.copyTo(img_line);

	//보조선
	cvtColor(img_line, img_line, COLOR_GRAY2BGR);
	line(img_line, Point2f(0, 90), Point2f(320, 90), Scalar(0, 255, 255), 2);
	line(img_line, Point2f(160, 90), Point2f(160, 180), Scalar(255, 0, 255), 2);

	// 직진 차선 검출용
	line(img_line, Point2f(9, 90), Point2f(149, 90), Scalar(0, 255, 0), 2);
	line(img_line, Point2f(169, 90), Point2f(309, 90), Scalar(0, 255, 0), 2);

	// 직진 차선 중앙 유지용
	line(img_line, Point2f(52, 80), Point2f(52, 100), Scalar(0, 0, 255), 2);
	line(img_line, Point2f(267, 80), Point2f(267, 100), Scalar(0, 0, 255), 2);


	bool curve_check = 0, left_check = 0, right_check = 0;
	int curve_x = 0, curve_y = 0, left_x = 0, right_x = 0;

	double angle = 0;

	//커브 검출
	uchar* curve_pointer_row = img_warp_rotate.ptr<uchar>(160);
	for (int col = 0; col < 90; col++)
	{
		uchar color = curve_pointer_row[col];
		//printf("%d ", color);
		if (color > 0)
		{
			printf("CURVE OK\n");
			curve_check = 1;
			curve_y = col;
			circle(img_line, Point(160, 180 - col), 5, Scalar(0, 0, 255), -1);
			break;
		}
	}

	//직진 차선 검출 왼쪽
	uchar* left_pointer_row = img.ptr<uchar>(90);
	for (int col = 9; col < 149; col += 2)
	{
		uchar color1 = left_pointer_row[col];
		uchar color2 = left_pointer_row[col + 1];
		//printf("%d ", color);
		if (color1 > 0 && color2 > 0)
		{
			printf("LEFT OK\n");
			left_check = 1;
			left_x = col;
			circle(img_line, Point(col, 90), 5, Scalar(0, 0, 255), -1);
			break;
		}
	}

	//직진 차선 검출 오른쪽
	uchar* right_pointer_row = img.ptr<uchar>(90);
	for (int col = 309; col > 169; col -= 2)
	{
		uchar color1 = right_pointer_row[col];
		uchar color2 = right_pointer_row[col - 1];
		//printf("%d ", color);
		if (color1 > 0 && color2 > 0)
		{
			right_check = 1;
			printf("RIGHT OK\n");
			right_x = col;
			circle(img_line, Point(col, 90), 5, Scalar(0, 0, 255), -1);
			break;
		}
	}



	if (curve_check)
	{
		
		if (left_check && !right_check)
		{

			angle = atan2((160 - left_x), (90 - curve_y)) * 180 / CV_PI;
			printf("angle : %lf\n", angle);
			line(img_line, Point(160, 180 - curve_y), Point(left_x, 90), Scalar(230, 180, 100), 3);
		}
		else if (!left_check && right_check)
		{
			angle = atan2((160 - right_x), (90 - curve_y)) * 180 / CV_PI;
			printf("angle : %lf\n", angle);
			line(img_line, Point(160, 180 - curve_y), Point(right_x, 90), Scalar(230, 180, 100), 3);
		}
		else
		{
			if (curve_y >= 20)
			{
				uchar* curve_up_pointer_row = img.ptr<uchar>(160);
				for (int col = 0; col < 320; col += 2)
				{
					uchar color1 = curve_up_pointer_row[col];
					uchar color2 = curve_up_pointer_row[col - 1];
					//printf("%d ", color);
					if (color1 > 0 && color2 > 0)
					{
						printf("CURVE UP OK\n");
						curve_x = col;
						circle(img_line, Point(col, 160), 5, Scalar(0, 0, 255), -1);
						line(img_line, Point(160, 180 - curve_y), Point(curve_x, 160), Scalar(230, 180, 100), 3);


						angle = atan2((-curve_x + 160), (curve_y - 20)) * 180 / CV_PI;
						printf("angle : %lf\n", angle);

						break;
					}
				}


			}
			else
			{

				uchar* curve_down_pointer_row = img.ptr<uchar>(150);
				for (int col = 0; col < 320; col += 2)
				{
					uchar color1 = curve_down_pointer_row[col];
					uchar color2 = curve_down_pointer_row[col - 1];
					//printf("%d ", color);
					if (color1 > 0 && color2 > 0)
					{
						printf("CURVE DOWN OK\n");
						curve_x = col;
						circle(img_line, Point(col, 110), 5, Scalar(0, 0, 255), -1);
						line(img_line, Point(160, 180 - curve_y), Point(curve_x, 150), Scalar(230, 180, 100), 3);

						angle = atan2((-curve_x + 160), (-curve_y + 30)) * 180 / CV_PI;
						printf("angle : %lf\n", angle);
						break;
					}
				}


			}
		}

	}
	else
	{

		if (left_check && right_check)
		{
			int avg_x=(left_x +  right_x)/2;
			angle = atan2(160 - avg_x, 90)*180/CV_PI;
			printf("angle : %lf\n", angle);

			line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
		}
		else if (left_check && !right_check)
		{//215
			circle(img_line, Point(left_x + 215, 90), 5, Scalar(220, 100, 220), -1);
			
			int avg_x = (left_x*2 + 215) / 2;
			angle = atan2(160 - avg_x, 90)*180/CV_PI;
			printf("angle : %lf\n", angle);

			line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
		}
		else if (!left_check && right_check)
		{
			circle(img_line, Point(right_x - 215, 90), 5, Scalar(220, 100, 220), -1);

			int avg_x = (right_x * 2 - 215) / 2;
			angle = atan2(160 - avg_x, 90)*180/CV_PI;
			printf("angle : %lf\n", angle);

			line(img_line, Point(160, 180), Point(avg_x, 90), Scalar(230, 180, 100), 3);
		}
	}

	
	if (opencv_steering_control == 1)
	{
		if (angle > -50 && angle < 50)
		{
			//cout<<"test"<<endl;
			SteeringServoControl_Write(1507 + angle * 5);
			//usleep(50000);
		}
		else if ((angle >= 50 || angle <= -50)&&(curve_y<20) )
		{
			if (angle*16 >500)
				SteeringServoControl_Write(2000);
			else if(angle*16<-500)
				SteeringServoControl_Write(1000);
			else
				SteeringServoControl_Write(1507 + angle * 16);
			//usleep(50000);
			//cout<<"test2"<<endl;
		}

	}
		


	img_line.copyTo(output_img);


	return;
}

void traffic_sign_new(Mat input_image, Mat* img_out)
{

	if(traffic_step == 0)
	{
		DesireSpeed_Write(80);
		char line_sensor=LineSensor_Read();
		printf("%d\n",line_sensor);
		if(line_sensor==0) //라인센서 너무 민감해서 오작동 심함... 2020/09/07 09:31
		{
			DesireSpeed_Write(0);
			traffic_step ++;
		}


	}
	else if(traffic_step ==1)
	{
		CameraYServoControl_Write(1580);
		usleep(800000);

		
		traffic_step ++;
	}
	else if(traffic_step <10)
	{
		usleep(10000);

		
		traffic_step ++;
	}
	else if(traffic_step == 10)
	{
		Mat img_bgr;
		input_image.copyTo(img_bgr);

		Mat img_gray;
		cvtColor(img_bgr, img_gray, COLOR_BGR2GRAY);

		Mat img_threshold;
		threshold(img_gray, img_threshold, 100, 255, THRESH_BINARY);

		Mat img_dilate, img_closing;
		dilate(img_threshold, img_dilate, Mat::ones(Size(5, 5), CV_8UC1), Point(-1, -1), 1);
		erode(img_dilate, img_closing, Mat::ones(Size(5, 5), CV_8UC1), Point(-1, -1), 1);
  

		// Mat test;
		// cvtColor(img_closing,test,COLOR_GRAY2BGR);
		// test.copyTo(*img_out);



		int pixel_count_row[90] = { 0, };

		for (int row = 0; row < 90; row++)
		{
			
			uchar* pointer_row = img_closing.ptr<uchar>(row);
			int count = 0;
			for (int col = 0; col < img_closing.cols; col++)
			{
				uchar color = pointer_row[col];
				//printf("%d ", color);
				if (color == 0)
					count++;
			}
			//cout << "\n" << endl;
			pixel_count_row[row] = count;
			//cout << pixel_count_row[row] << endl;
		}

		int max_data = 0 ;
		int max_row = 0;
		for (int i = 0; i < 90; i++)
		{

			if (pixel_count_row[i] > max_data)
			{
				max_data = pixel_count_row[i];
				max_row = i;
			}
				

		}
		cout << "max_data : "<< max_data << endl;
		cout << "max_row : "<< max_row << endl;

		uchar* max_pointer_row = img_closing.ptr<uchar>(max_row);
		//cout << max_pointer_row[] << endl;
	

		if(max_row<30)
			return;

		
		for (int i = 0; i < 320; i++)
		{
			/*if (max_pointer_row[i] == 255)
				max_pointer_row[i] = 1;*/
			//printf("max_ %d ", max_pointer_row[i]);

			if (max_pointer_row[i] > max_pointer_row[i + 1])
			{
				if (red_left == 0)
					red_left = i;
				else if (yellow_left == 0)
					yellow_left = i;
				else if (left_left == 0)
					left_left = i;
				else if (right_left == 0)
					right_left = i;
			}

			if (max_pointer_row[i] < max_pointer_row[i + 1])
			{
				if (red_right == 0)
					red_right = i+1;
				else if (yellow_right == 0)
					yellow_right = i+1;
				else if (left_right == 0)
					left_right = i+1;
				else if (right_right == 0)
				{
					right_right = i+1;
					break;
				}
			}
		}	// for() end
		
		red_roi = Rect(Point(red_left, max_row - (red_right - red_left) / 2), Point(red_right, max_row + (red_right - red_left) / 2));
		yellow_roi = Rect(Point(yellow_left, max_row - (yellow_right - yellow_left) / 2), Point(yellow_right, max_row + (yellow_right - yellow_left) / 2));
		left_roi = Rect(Point(left_left, max_row - (left_right - left_left) / 2), Point(left_right, max_row + (left_right - left_left) / 2));
		right_roi = Rect(Point(right_left, max_row - (right_right - right_left) / 2), Point(right_right, max_row + (right_right - right_left) / 2));


		traffic_step ++;

	}
	else if(traffic_step==11)
	{
		// rectangle(img_out, red_roi, Scalar(0,0,255), 1);
		// rectangle(img_out, yellow_roi, Scalar(0, 0, 255), 1);
		// rectangle(img_out, left_roi, Scalar(0, 0, 255), 1);
		// rectangle(img_out, right_roi, Scalar(0, 0, 255), 1);
		opencv_lcd_control = 4;
		Mat img_bgr;
		input_image.copyTo(img_bgr);

		Mat img_gray;
		cvtColor(img_bgr, img_gray, COLOR_BGR2GRAY);
		
		/*
		2020-09-12
		기존에 img_gray*1.5를 더 알맞게 수정
		
		10만큼 빼주고 1.5배를 시켜서 확실하게 찾게함
		*/
		//img_gray = img_gray * 1.5;

		img_gray -= 10;
		img_gray = img_gray * 3;

		Mat red_img;
		img_gray(red_roi).copyTo(red_img);

		Mat yellow_img;
		img_gray(yellow_roi).copyTo(yellow_img);

		Mat left_img;
		img_gray(left_roi).copyTo(left_img);

		Mat right_img;
		img_gray(right_roi).copyTo(right_img);

		int left_count = 0;
		for (int i = left_img.rows / 3; i < left_img.rows * 2 / 3; i++)
		{
			for (int j = left_img.cols / 3; j < left_img.cols * 2 / 3; j++)
			{
				if (left_img.at<uchar>(j, i) > 150)
				{
					left_count++;
				}
				
			}
		}
		if (left_count > 5)
		{
			cout << "left detect!" << endl;
			traffic_step = 20;
		}

		int right_count = 0;
		for (int i = right_img.rows / 3; i < right_img.rows * 2 / 3; i++)
		{
			for (int j = right_img.cols / 3; j < right_img.cols * 2/ 3; j++)
			{
				if (right_img.at<uchar>(j, i) > 150)
				{
					right_count++;
				}

			}
		}
		if (right_count > 5)
		{
			cout << "right detect!" << endl;
			traffic_step = 30;
		}

	}
	else if(traffic_step == 20)// turn left
	{
		Alarm_Write(ON);
		usleep(500000);
		Alarm_Write(ON);

		Winker_Write(LEFT_ON);
		
	    SteeringServoControl_Write(1507);
	    usleep(200000);

	    traffic_step ++;
	    DesireSpeed_Write(100);

	}

	else if(traffic_step == 21)
	{
		if(dist_milli(1) <250)
			traffic_step ++;
	}
	else if(traffic_step == 22)
	{
		
		SpeedControlOnOff_Write(CONTROL);   // speed controller must be also ON !!!
        int speed = 150; // speed set     --> speed must be set when using position controller
        DesireSpeed_Write(speed);

        //control on/off
        PositionControlOnOff_Write(CONTROL);

        //position controller gain set
        int gain = 5;
        PositionProportionPoint_Write(gain);

		SteeringServoControl_Write(2000);
		usleep(500000);	//100ms

        int move_distance =  800*CV_PI/2 ;	// perfectly !!

        if(move_distance>0)
	        DesireEncoderCount_Write(move_distance);


	
        cout<<"move_distance : "<<move_distance<<endl;
        int sleep_time = (move_distance/500)*1000000 + 1000000;
        usleep(sleep_time);

        SteeringServoControl_Write(1507);
        usleep(100000);

        move_distance = 900;
        DesireEncoderCount_Write(move_distance);

        sleep_time = (move_distance/500)*1000000 + 1000000;
        usleep(sleep_time);


        PositionControlOnOff_Write(UNCONTROL);

		traffic_step = 50;

	}
	else if(traffic_step == 30) //turn right
	{
		Alarm_Write(ON);
		Winker_Write(RIGHT_ON);
		
		SteeringServoControl_Write(1507);
	    usleep(200000);

		
		traffic_step++;
		DesireSpeed_Write(100);

	}
	else if( traffic_step ==31)
	{
		if(dist_milli(1) < 230)
			traffic_step ++;
	}
	else if( traffic_step == 32)
	{
		SpeedControlOnOff_Write(CONTROL);   // speed controller must be also ON !!!
        int speed = 150; // speed set     --> speed must be set when using position controller
        DesireSpeed_Write(speed);

        //control on/off
        PositionControlOnOff_Write(CONTROL);

        //position controller gain set
        int gain = 5;
        PositionProportionPoint_Write(gain);

		SteeringServoControl_Write(1050);
		usleep(500000);	//100ms

        int move_distance =  800*CV_PI/2 ;	// perfectly !!

        if(move_distance>0)
	        DesireEncoderCount_Write(move_distance);


	
        cout<<"move_distance : "<<move_distance<<endl;
        int sleep_time = (move_distance/500)*1000000 + 1000000;
        usleep(sleep_time);

        SteeringServoControl_Write(1507);
        usleep(100000);

        move_distance = 900;
        DesireEncoderCount_Write(move_distance);

        sleep_time = (move_distance/500)*1000000 + 1000000;
        usleep(sleep_time);


        PositionControlOnOff_Write(UNCONTROL);
		traffic_step = 50;

	}
	else if(traffic_step == 50)
	{	
		DesireSpeed_Write(0);
		DesireEncoderCount_Write(0);
		PositionControlOnOff_Write(UNCONTROL);
		Winker_Write(ALL_OFF);
		Alarm_Write(ON);
		sleep(1);
		Alarm_Write(OFF);
		DesireSpeed_Write(0);

		sleep(10);
		traffic_step++;
	}
	else
	{
		DesireSpeed_Write(0);

	}

	return;


}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////

void openCV_code(unsigned char* srcBuf, int iw, int ih, unsigned char* outBuf, int* pointer_driving_status, short* pointer_speed, short* pointer_angle, bool* pointer_steering_control, bool* pointer_stop_line_control, bool* pointer_cout_control, int* pointer_lcd_control)
{
	Mat img_out(ih, iw, CV_8UC3, outBuf);	//output image
	Mat img(ih, iw, CV_8UC3, srcBuf);		//making image buf to Mat
	Mat img_edges, img_grayline;


	//img= img*0.6;
	//img=img*1.6;
	//img = img*1.2;

// pointer_variables copy to global_variables,	Ctrl+Shift+]
	opencv_driving_status = *pointer_driving_status;
	opencv_steering_control = *pointer_steering_control;
	opencv_stop_line_control = *pointer_stop_line_control;
	opencv_cout_control = *pointer_cout_control;
	opencv_lcd_control = *pointer_lcd_control;

	Mat img_lane;
	Mat img_yellow;
	Mat img_warp;
	Mat img_highway;
	Mat img_round_rotary;
	Mat img_tunnel;
	Mat img_parking;
	Mat img_overtaking;
	
	int Steering_angle=1507;
// mission check, steering_control, Ctrl+Shift+]
	switch(*pointer_driving_status)
	{
		case 0:	mission = "Manual-driving";
				opencv_steering_control = 0;
				inRange_yellow(img, img_yellow);
				WARP(img_yellow, img_warp);
				calculate_steering_angle5(img_warp, img_lane, 0);
				break;

		case 1: mission = "Auto-driving";
				opencv_steering_control = 1;
				inRange_yellow(img, img_yellow);
				WARP(img_yellow, img_warp);
				//overtaking_lane_driving(img_warp, img_lane);
				calculate_steering_angle5(img_warp, img_lane, 1);
				break;

		case 2: mission = "Highway";
				opencv_steering_control = 1;
				//inRange_yellow(img, img_yellow);r
				//WARP(img_yellow, img_warp);
				if (highway(img, img_highway) == 0)
				{
					DesireSpeed_Write(120);

					if(auto_status == 0)
						*pointer_driving_status = 1;
					else if(auto_status == 1)
						*pointer_driving_status = 3;
				}
				opencv_lcd_control = 11;
				break;

		case 3:	mission = "Stop sign";
				opencv_steering_control = 1;
				inRange_yellow(img, img_yellow);
				WARP(img_yellow, img_warp);
				//overtaking_lane_driving(img_warp, img_lane);
				calculate_steering_angle5(img_warp, img_lane, 1);
				find_stop_sign(img);
				if(red_find == 2)
				{
					DesireSpeed_Write(150);
					main_speed = 150;

					if(auto_status==0)
						*pointer_driving_status = 1;
					else if(auto_status==1)
						*pointer_driving_status = 4;
					red_find =0;
				}
				break;

		case 4: mission = "S curve";
				//opencv_steering_control = 1;inRange_yellow(img, img_yellow);
				inRange_yellow(img, img_yellow);	
				WARP(img_yellow, img_warp);
				if( S_curve(img_warp, img_lane, 1) == 1 )
				{
					DesireSpeed_Write(150);
					main_speed=150;
					if(auto_status==0)
						*pointer_driving_status = 1;
					else if(auto_status==1)
						*pointer_driving_status = 5;
					
				}
				opencv_lcd_control = 2;

				break;

		case 5: mission = "Parking";
				//opencv_steering_control = 1;
				opencv_lcd_control = 3;
				inRange_yellow(img, img_yellow);
				WARP(img_yellow, img_warp);
				

				//calculate_steering_angle3(img_warp, img_lane,1);
				//calculate_steering_angle5(img_warp, img_lane, 1);
				if(parking_check(img_warp,img_parking) == 100 )
				{
					if(auto_status==0)
						*pointer_driving_status = 1;
					else if(auto_status==1)
						*pointer_driving_status = 6;
				} 
				opencv_lcd_control=14;
				break;

		case 6:	mission = "Round rotary";
				inRange_yellow(img, img_yellow);
				WARP(img_yellow, img_warp);
				if(round_rotary_step == 0)
				{
					round_rotary(img, img_round_rotary);
					go_turn_right_rotary(img,img_round_rotary);


				}
								else if ( round_rotary_step <20)
				{
					round_rotary(img, img_round_rotary);
				}
				else if( round_rotary_step==20)
				{
					calculate_steering_angle5(img_warp, img_round_rotary,1);
					
					if( lane_mode == 1)
					{
						round_rotary_step = 50;


					}
				}
					
					
				else if ( round_rotary_step == 50)
				{
					calculate_steering_angle5(img_warp, img_round_rotary,1);

					if( lane_mode == 0)
					{
						if(auto_status==0)
							*pointer_driving_status = 1;
						else if(auto_status==1)
							*pointer_driving_status = 7;

					}
				}
				opencv_lcd_control = 15;
				break;

		case 7: mission = "Tunnel";
				if(tunnel_check == 0)
				{
					DesireSpeed_Write(130);
					main_speed = 130;

					CarLight_Write(ALL_ON);
					tunnel_check ++;

					inRange_yellow(img, img_yellow);
					WARP(img_yellow, img_warp);
					calculate_steering_angle5(img_warp, img_tunnel, 1);
				}
				else if(tunnel_check == 1)
				{

					inRange_yellow(img, img_yellow);
					WARP(img_yellow, img_warp);
					calculate_steering_angle5(img_warp, img_tunnel, 1);
				

					if(dist_milli(2)<150)
					{
						tunnel_check ++;
						DesireSpeed_Write(100);
						pre_dist2 = 0;
						pre_dist3 = 0;
						pre_dist5 = 0;
						pre_dist6 = 0;
						pre_encoder = 0;
					}
				}
				else if(tunnel_check == 2)
				{
					if( distance_driving_tunnel(img, img_tunnel, 1) == 0)
					{
						if(auto_status==0)
						{
							*pointer_driving_status = 1;
							CarLight_Write(ALL_OFF);
						}
						else if(auto_status==1)
						{
							CarLight_Write(ALL_OFF);	
							*pointer_driving_status = 8;
						}
					}
				}

				opencv_lcd_control = 16;
				break;

		case 8: mission = "Overtaking";
				// opencv_steering_control = 1;
				
				if( overtaking(img, img_overtaking) == 1)
				{
					if(auto_status==0)
					{
						*pointer_driving_status = 1;
						CarLight_Write(ALL_OFF);
					}
					else if(auto_status==1)
					{
						CarLight_Write(ALL_OFF);	
						*pointer_driving_status = 9;
					}
				}
				opencv_lcd_control = 17;
				break;

		case 9: mission = "traffic sign";
				opencv_steering_control = 1;
				traffic_sign_new(img, &img_out);
				break;
		
		case 21: mission = "steering_left";
				Steering_angle = SteeringServoControl_Read() + 80;
	            SteeringServoControl_Write(Steering_angle);
	            usleep(50000);
				*pointer_driving_status = 0;
				break;	
		case 22: mission = "steering_right";
				Steering_angle = SteeringServoControl_Read() - 80;
	            SteeringServoControl_Write(Steering_angle);
				usleep(50000);
				*pointer_driving_status = 0;
				break;
		case 30: mission = "dist_driving";
				distance_driving_4(img, img_out, 1);
				break;

		case 50: mission = "capture";
				 capture(img);
				*pointer_driving_status = 0;
				break;


		case 100: mission = "GG";
				usleep(3000000);
				*pointer_driving_status = 3;
				DesireSpeed_Write(150);
				auto_status = 1;
				break;
	/*	case 9: mission = "traffic sign";
				opencv_steering_control = 1;
				break;
		case 9: mission = "traffic sign";
				opencv_steering_control = 1;
				break;
		case 9: mission = "traffic sign";
				opencv_steering_control = 1;
				break;

		case 9: mission = "traffic sign";
				opencv_steering_control = 1;
				break;*/
	}


	if(opencv_lcd_control == 0)
	{
		img.copyTo(img_out);
	}
	else if(opencv_lcd_control == 1)
	{
		Mat img_gray;
		cvtColor(img, img_gray, COLOR_BGR2GRAY);
		threshold(img_gray, img_gray, 150, 255, THRESH_OTSU);
		cvtColor(img_gray,img_out,COLOR_GRAY2BGR);
		//img_gray.copyTo(img_out);
	}
	else if(opencv_lcd_control == 2)
	{

		img_lane.copyTo(img_out);
	}
	else if(opencv_lcd_control == 3)
	{
		img.copyTo(img_out);

		//string myText = "500";
		Point dist_pt[6];
		dist_pt[0] = Point(140, 40);
		dist_pt[1] = Point(210, 70);
		dist_pt[2] = Point(210, 130);
		dist_pt[3] = Point(140, 160);
		dist_pt[4] = Point(90, 130);
		dist_pt[5] = Point(90, 70);

		for (int i = 0; i < 6; i++)
		{
			char myText[20];
			int dist = int(dist_milli(i + 1) );
			//myText = double.toString(dist_cesnti(i+1));
			sprintf(myText, "%d", dist);
			//sprintf(myText, "%d", i+1);
			if(dist<80)
			{
				putText(img_out, myText, dist_pt[i], 3, 1, Scalar(0,0,255), 1, 8);
			}
			else if(dist<150)
			{
				putText(img_out, myText, dist_pt[i], 3, 1, Scalar(0,255,0), 1, 8);
			}
			else if(dist<250)
			{
				putText(img_out, myText, dist_pt[i], 3, 1, Scalar(255,0,0), 1, 8);
			}
			else 
				putText(img_out, myText, dist_pt[i], 3, 1, Scalar::all(255), 1, 8);
			
		}
	}
	else if(opencv_lcd_control == 4)
	{
		img.copyTo(img_out);

		rectangle(img_out, red_roi, Scalar(0,0,255), 1);
		rectangle(img_out, yellow_roi, Scalar(0, 0, 255), 1);
		rectangle(img_out, left_roi, Scalar(0, 0, 255), 1);
		rectangle(img_out, right_roi, Scalar(0, 0, 255), 1);



	}
	else if (opencv_lcd_control == 11)	// highway_img
	{
		img_highway.copyTo(img_out);


	}
	else if (opencv_lcd_control == 14)	// highway_img
	{
		img_parking.copyTo(img_out);


	}
	else if (opencv_lcd_control == 15)
	{
		img_round_rotary.copyTo(img_out);
	}
	else if (opencv_lcd_control == 16)	// highway_img
	{
		img_tunnel.copyTo(img_out);


	}
	else if (opencv_lcd_control == 17)	// highway_img
	{
		img_overtaking.copyTo(img_out);


	}





		

	 //*pointer_driving_status = opencv_driving_status;
	 //*pointer_steering_control = opencv_steering_control;
	 /**pointer_stop_line_control = opencv_stop_line_control;
	 *pointer_cout_control = opencv_cout_control;
	 *pointer_lcd_control = opencv_lcd_control;*/

	


	// 2020-09-28 01 :57 PM 
	// encoder -> change to gloabal variable
	char myText_encoder[10];
	gloabal_encoder_read = EncoderCounter_Read();
	usleep(100);
	sprintf(myText_encoder, "%d", gloabal_encoder_read);


	putText(img_out, myText_encoder, Point(180,170), 2, 1, Scalar(0,0,255), 1, 8);
	putText(img_out, mission, Point(80,30), 1, 1, Scalar(0,0,255), 1, 8);
	
	cout<<"encoder : "<<gloabal_encoder_read<<endl;



	return;
}





void inRange_yellow(Mat input_img, Mat &output_img)	// input : color  , output : gray
{
	Mat img_bgr;
	input_img.copyTo(img_bgr);

	Mat img_hsv;
	cvtColor(img_bgr, img_hsv, COLOR_BGR2HSV);

	Mat yellow_mask;

	Scalar lower_yellow = Scalar(20, 20, 100);
		// Scalar lower_yellow = Scalar(30, 40, 70);
	Scalar upper_yellow = Scalar(40, 255, 255);
		// Scalar upper_yellow = Scalar(50, 220, 230);

	inRange(img_hsv, lower_yellow, upper_yellow, yellow_mask);
	
	// erode(yellow_mask, yellow_mask, Mat::ones(Size(9, 3), CV_8UC1), Point(-1, -1));
	// dilate(yellow_mask, yellow_mask, Mat::ones(Size(3, 15), CV_8UC1), Point(-1, -1));
	//erode(yellow_mask, yellow_mask, Mat::ones(Size(5, 5), CV_8UC1), Point(-1, -1));
	//dilate(yellow_mask, yellow_mask, Mat::ones(Size(5, 5), CV_8UC1), Point(-1, -1));


	/* 2020 09 19 추가 - 차선 더 잘 검출 됨*/
	erode(yellow_mask, yellow_mask, Mat::ones(Size(3, 3), CV_8UC1), Point(-1, -1));
	dilate(yellow_mask, yellow_mask, Mat::ones(Size(5, 5), CV_8UC1), Point(-1, -1));

	dilate(yellow_mask, yellow_mask, Mat::ones(Size(9, 9), CV_8UC1), Point(-1, -1));
	erode(yellow_mask, yellow_mask, Mat::ones(Size(11, 11), CV_8UC1), Point(-1, -1));
	////



	yellow_mask.copyTo(output_img);
	return;
}



void inRange_white(Mat input_img, Mat& output_img)
{
	Mat img_bgr;
	input_img.copyTo(img_bgr);

	Mat white_mask;

	Scalar lower_white = Scalar(210, 210, 210); 
	Scalar upper_white = Scalar(255, 255, 255);

	inRange(img_bgr, lower_white, upper_white, white_mask);

	erode(white_mask, white_mask, Mat::ones(Size(5, 5), CV_8UC1), Point(-1, -1));
	dilate(white_mask, white_mask, Mat::ones(Size(5, 5), CV_8UC1), Point(-1, -1));

	white_mask.copyTo(output_img);
	return;
}



void WARP(Mat input_img, Mat& output_img)
{
	Mat img;
	input_img.copyTo(img);


	/* 2020 09 19 주석처리 함*/
	//vector<Point2f> corners(4);
	//corners[0] = Point2f(60, 70);
	//corners[1] = Point2f(260, 70);
	//corners[2] = Point2f(-80, 130);
	//corners[3] = Point2f(400, 130);

	/* 2020 09 19 더 넓은 영영 WARPING 함*/
	vector<Point2f> corners(4);
	corners[0] = Point2f(60, 70);
	corners[1] = Point2f(260, 70);
	corners[2] = Point2f(-196, 180);
	corners[3] = Point2f(516, 180);




	Size warpSize(320, 180);
	Mat img_warp(warpSize, img.type());

	vector<Point2f> warpCorners(4);
	warpCorners[0] = Point2f(0, 0);
	warpCorners[1] = Point2f(img_warp.cols, 0);
	warpCorners[2] = Point2f(0, img_warp.rows);
	warpCorners[3] = Point2f(img_warp.cols, img_warp.rows);

	Mat trans = getPerspectiveTransform(corners, warpCorners);
	warpPerspective(img, img_warp, trans, warpSize);

	img_warp.copyTo(output_img);
	return;
}

void calculate_steering_angle(Mat input_img, Mat& output_img) 	// input_img : GRAY ,  output_img : BGR
{
	Mat img;
	input_img.copyTo(img);

	uchar* pointer_row_1 = img.ptr<uchar>(30);
	int left_1 = 0;
	int right_1 = 320;

	for (int i = 100; i > 20; i--)
	{
		uchar pixel = pointer_row_1[i];
		if (pixel > 0)
		{
			left_1 = i;
			//printf("%d ", left_1);
			break;
		}
	}

	for (int i = 220; i < 300; i++)
	{
		uchar pixel = pointer_row_1[i];
		if (pixel > 0)
		{
			right_1 = i;
			//printf("%d ", right_1);
			break;
		}
	}


	uchar* pointer_row_2 = img.ptr<uchar>(100);
	int left_2 = 0;
	int right_2 = 320;

	for (int i = 100; i > 20; i--)
	{
		uchar pixel = pointer_row_2[i];
		if (pixel > 0)
		{
			left_2 = i;
			//printf("%d ", left_2);
			break;
		}
	}

	for (int i = 220; i < 300; i++)
	{
		uchar pixel = pointer_row_2[i];
		if (pixel > 0)
		{
			right_2 = i;
			//printf("%d ", right_2);
			break;
		}
	}

	uchar* pointer_row_3 = img.ptr<uchar>(170);
	int left_3 = 0;
	int right_3 = 320;

	for (int i = 100; i > 20; i--)
	{
		uchar pixel = pointer_row_3[i];
		if (pixel > 0)
		{
			left_3 = i;
			//printf("%d ", left_3);
			break;
		}
	}

	for (int i = 220; i < 300; i++)
	{
		uchar pixel = pointer_row_3[i];
		if (pixel > 0)
		{
			right_3 = i;
			//printf("%d ", right_3);
			break;
		}
	}

	Mat img_color;
	cvtColor(img, img_color, COLOR_GRAY2BGR);

	line(img_color, Point(20, 30), Point(100, 30), Scalar(0, 0, 255), 2, 8);
	line(img_color, Point(220, 30), Point(300, 30), Scalar(0, 0, 255), 2, 8);

	line(img_color, Point(20, 100), Point(100, 100), Scalar(0, 0, 255), 2, 8);
	line(img_color, Point(220, 100), Point(300, 100), Scalar(0, 0, 255), 2, 8);

	line(img_color, Point(20, 170), Point(100, 170), Scalar(0, 0, 255), 2, 8);
	line(img_color, Point(220, 170), Point(300, 170), Scalar(0, 0, 255), 2, 8);


	circle(img_color, Point(left_1, 30), 3, Scalar(0, 255, 0), -1);
	circle(img_color, Point(right_1, 30), 3, Scalar(0, 255, 0), -1);
	circle(img_color, Point(left_2, 100), 3, Scalar(0, 255, 0), -1);
	circle(img_color, Point(right_2, 100), 3, Scalar(0, 255, 0), -1);
	circle(img_color, Point(left_3, 170), 3, Scalar(0, 255, 0), -1);
	circle(img_color, Point(right_3, 170), 3, Scalar(0, 255, 0), -1);

	if ((left_1 != 0) && (right_1 != 320) && (left_2 != 0) && (right_2 != 320) && (left_3 != 0) && (right_3 != 320))	// straight 6_points
	{

		float angle_1, angle_2;
		angle_1 = float(((left_1 + right_1) / 2) - ((left_3 + right_3) / 2)) / 140;
		angle_2 = float(((left_2 + right_2) / 2) - ((left_3 + right_3) / 2)) / 70;
		//int angle = int( (angle_1 + angle_2) / 2 * 22);
		int angle = int((angle_1 + angle_2) * 11);
		cout<<"All"<<endl;
		cout<<"angle : " <<angle<<endl;
		//cout<<*pointer_steering_control<<endl;
		if (opencv_steering_control == 1)
			SteeringServoControl_Write(1507 - angle*20);

		char myText[10];
 		sprintf(myText, "%d", 1507 - angle*20);
		putText(img_color, myText, Point(150,150), 3, 1, Scalar(0, 0, 255), 1, 8);

		circle(img_color, Point((left_1 + right_1) / 2, 30), 3, Scalar(0, 0, 255), -1);
		circle(img_color, Point((left_2 + right_2) / 2, 100), 3, Scalar(0, 0, 255), -1);
		circle(img_color, Point((left_3 + right_3) / 2, 170), 3, Scalar(0, 0, 255), -1);
	}
	else if( (left_2 != 0) && (right_2 != 320) && (left_3 != 0) && (right_3 != 320)  )	// straight 4_points
	{
		float angle_1;
		angle_1 = float(((left_2 + right_2) / 2) - ((left_3 + right_3) / 2)) / 70;

		int angle = int(angle_1* 22);
		cout<<"3456"<<endl;
		cout<<"angle : " <<angle<<endl;

		if (opencv_steering_control == 1)
			SteeringServoControl_Write(1507 - angle*20);

		char myText[10];
 		sprintf(myText, "%d", 1507 - angle*20);
		putText(img_color, myText, Point(150,150), 3, 1, Scalar(0, 0, 255), 1, 8);

		circle(img_color, Point((left_2 + right_2) / 2, 100), 3, Scalar(0, 0, 255), -1);
		circle(img_color, Point((left_3 + right_3) / 2, 170), 3, Scalar(0, 0, 255), -1);
	}
	else if( (left_1 != 0) && (left_2 != 0) && (left_3 != 0)  )		// straight 3_points only left 135
	{
		float angle_1, angle_2;
		angle_1 = float( left_1 - left_3 ) / 140;
		angle_2 = float( left_2 - left_3 ) / 70;
	
		int angle = int((angle_1 + angle_2) * 11);
		cout<<"135"<<endl;
		cout<<"angle : " <<angle<<endl;

		if (opencv_steering_control == 1)
			SteeringServoControl_Write(1507 - angle*20);

		char myText[10];
 		sprintf(myText, "%d", 1507 - angle*20);
		putText(img_color, myText, Point(150,150), 3, 1, Scalar(0, 255, 255), 1, 8);

	}
	else if( (right_1 != 0) && (right_2 != 0) && (right_3 != 0)  )	// straight 3_points only right 246
	{
		float angle_1, angle_2;
		angle_1 = float( right_1 - right_3 ) / 140;
		angle_2 = float( right_2 - right_3 ) / 70;
	
		int angle = int((angle_1 + angle_2) * 11);
		cout<<"246"<<endl;
		cout<<"angle : " <<angle<<endl;

		if (opencv_steering_control == 1)
			SteeringServoControl_Write(1507 - angle*20);

		char myText[10];
 		sprintf(myText, "%d", 1507 - angle*20);
		putText(img_color, myText, Point(150,150), 3, 1, Scalar(0, 255, 0), 1, 8);

	}
	else if( (left_2 != 0) && (left_3 != 0) )		// straight 2_points only left 35
	{
		float angle_1;
		angle_1 = float( left_2 - left_3 ) / 70;
	
		int angle = int(angle_1 * 22);
		cout<<"35"<<endl;
		cout<<"angle : " <<angle<<endl;

		if (opencv_steering_control == 1)
			SteeringServoControl_Write(1507 - angle*20);

		char myText[10];
 		sprintf(myText, "%d", 1507 - angle*20);
		putText(img_color, myText, Point(150,150), 3, 1, Scalar(0, 255, 255), 1, 8);

	}
	else if( (right_2 != 0) && (right_3 != 0)  )	// straight 2_points only right 46
	{
		float angle_1;
		angle_1 = float( right_2 - right_3 ) / 70;
	
		int angle = int(angle_1 * 22);
		cout<<"46"<<endl;
		cout<<"angle : " <<angle<<endl;

		if (opencv_steering_control == 1)
			SteeringServoControl_Write(1507 - angle*20);

		char myText[10];
 		sprintf(myText, "%d", 1507 - angle*20);
		putText(img_color, myText, Point(150,150), 3, 1, Scalar(0, 255, 0), 1, 8);

	}
	// else
	// {
	// 	calculate_steering_angle_2
	// }

	


	img_color.copyTo(output_img);
	return;
}




// void calculate_steering_angle_2(Mat input_img, Mat& output_img, short* pointer_speed, short* pointer_angle, bool* pointer_steering_control)
// {

// }


void Hough_line(Mat input_img, Mat& output_img)
{
	Mat img;
	input_img.copyTo(img);

	Mat img_canny;
	Canny(img, img_canny, 150, 255);

	vector<Vec2f> lines;
	HoughLines(img_canny, lines, 1, CV_PI / 180, 70);

	Mat img_hough;
	img.copyTo(img_hough);

	Mat img_lane;
	//threshold(img_canny, img_lane, 150, 255, THRESH_MASK);

	cvtColor(img_hough, img_hough, COLOR_GRAY2BGR);

	for (size_t i = 0; i < lines.size(); i++)
	{
		float rho = lines[i][0], theta = lines[i][1];
		Point pt1, pt2;
		double a = cos(theta), b = sin(theta);
		double x0 = a * rho, y0 = b * rho;
		pt1.x = cvRound(x0 + 1000 * (-b));
		pt1.y = cvRound(y0 + 1000 * (a));
		pt2.x = cvRound(x0 - 1000 * (-b));
		pt2.y = cvRound(y0 - 1000 * (a));
		line(img_hough, pt1, pt2, Scalar(0, 0, 255), 2, 8);
	//	line(img_lane, pt1, pt2, Scalar::all(255), 1, 8);
	}


	img_hough.copyTo(output_img);

	return;
}


// 2020-10-10 11 :45 AM 
// void -> int

 	

// int parking_check()
// {
	
	

// 	if (!step_1 && dist_milli(2)<240)
// 	{	
// 		step_1=1;
// 		//Alarm_Write(ON);
		
// 	}
// 	else if (step_1 && !step_2 && dist_milli(2)>240)
// 	{
// 		step_2=1;
// 		encoder_start = EncoderCounter_Read();
// 		//Alarm_Write(ON);
		
// 	}
// 	else if (step_1 && step_2 && !step_3 && dist_milli(2)<240)
// 	{
// 		step_3=1;
// 		encoder_end = EncoderCounter_Read();
// 		//Alarm_Write(ON);

		
		
// 	}
// 	else if (step_1 && step_2 && step_3 && dist_milli(3)<240)
// 	{
// 		DesireSpeed_Write(0);
// 		parking_length = encoder_end-encoder_start;

// 		if(parking_length<850)
// 		{
// 			cout<<"V_parking"<<endl;
// 			opencv_steering_control = 0;
// 			Alarm_Write(ON);
// 			usleep(500000);
// 			Alarm_Write(ON);
// 			usleep(10000);

// 			return 1;	//vertical 

// 			//V_parking(parking_length);
// 		}
// 		else
// 		{
// 			cout<<"H_parking"<<endl;
// 			opencv_steering_control = 0;
// 			Alarm_Write(ON);
// 			usleep(10000);
// 			//H_parking(parking_length);

// 			return 2;	//helical

// 		}
// 	}

	

// 	return 0;

// }



int v_parking_step = 0;


int V_parking(int parking_length, Mat input_img, Mat& output_img)
{
	Mat img;
	input_img.copyTo(img);

	if(v_parking_step==0)
	{
		int distance_3 = dist_milli(3);			// 0829 _ 5cm


		if(distance_3 <= (parking_length) )		// 2 encoder = 1 mm 
		{
			SpeedControlOnOff_Write(CONTROL);   // speed controller must be also ON !!!
	        int speed = 100; // speed set     --> speed must be set when using position controller
	        DesireSpeed_Write(speed);

	        //control on/off
	        PositionControlOnOff_Write(CONTROL);

	        //position controller gain set
	        int gain = 5;
	        PositionProportionPoint_Write(gain);

	        int move_distance = (parking_length/2) - distance_3/2 - 80;

	        if(move_distance>0)
		        DesireEncoderCount_Write(move_distance);


		
	        cout<<"move_distance : "<<move_distance<<endl;
	        int sleep_time = (move_distance/500)*1000000 + 1000000;
	        usleep(sleep_time);

			//DesireSpeed_Write(0);
			Alarm_Write(ON);


			SteeringServoControl_Write(1000);
			usleep(100000);	//100ms

			speed = -150; // speed set     --> speed must be set when using position controller
	        DesireSpeed_Write(speed);

			move_distance = -( (parking_length + distance_3*2) * CV_PI/3   + 20) ;
			cout<<"move_distance : "<<move_distance<<endl;

	        DesireEncoderCount_Write(move_distance);



			sleep_time = abs(move_distance/500)*1000000 + 1000000;
			
	        usleep(sleep_time);
	        
	        PositionControlOnOff_Write(UNCONTROL);
	        
	        usleep(100000);






			SteeringServoControl_Write(1507);
			usleep(500000);	//100ms

			
			//int dist_2=0, dist_3=0, dist_5=0, dist_6=0;

			DesireSpeed_Write(-50);
			
			while( dist_milli(4) > 100)
			{
				distance_driving_2();
			}

			DesireSpeed_Write(0);
			SteeringServoControl_Write(1507);
			Alarm_Write(ON);
			sleep(3);
			
			//usleep(200000);
			// sleep(5);
			v_parking_step ++;
		}
		return 0;
	}	
	else if(v_parking_step==1)	// escape start _ go straight
	{
		
		DesireSpeed_Write(100);

		//overtaking_lane_driving(img_warp, output_img);
		//parking_img

		Mat img_line;
		cvtColor(img, img_line, COLOR_GRAY2BGR);


		Mat img_warp_rotate(img.cols,img.rows,CV_8UC1);
		
		for (int i = 0; i < img.cols;i++)	//rows
		{
			uchar* img_warp_rotate_pointer_row = img_warp_rotate.ptr<uchar>(i);
			for (int j = 0; j < img.rows;j++)	//cols
			{
				img_warp_rotate_pointer_row[j] = img.at<uchar>(179-j,i);
			}
		}

		int left = 0, right = 0;

		uchar* img_warp_rotate_pointer_row = img_warp_rotate.ptr<uchar>(80);
		for (int i = 0; i< 179; i++)
		{
			if(img_warp_rotate_pointer_row[i] && img_warp_rotate_pointer_row[i+1])
			{
				left = i;
				break;
			}
			
		}
		img_warp_rotate_pointer_row = img_warp_rotate.ptr<uchar>(240);
		for (int i = 0; i< 179; i++)
		{
			if(img_warp_rotate_pointer_row[i]  && img_warp_rotate_pointer_row[i+1] )
			{
				right = i;
				break;
			}
			
		}
		int left_right_sub;
		left_right_sub = abs(left-right);


		if(left>10 && right>10 && left<45 && right<45)
		{
			DesireSpeed_Write(0);
			return 1;

			//v_parking_step++;
		}
		else if(left && right && left_right_sub<10)
		{

			SteeringServoControl_Write(1507 + (right-left)*10);
			line(img_line, Point2f(80,180-left),Point2f(240,180-right), Scalar(0,0,255),2);

		}
	
	
	
		img_line.copyTo(output_img);
		return 0;
	}


	img.copyTo(output_img);
	return 0;


}


int h_parking_step = 0;
int distance_3;

int H_parking(int parking_length, Mat input_img, Mat& output_img)
{
	Mat img;
	input_img.copyTo(img);

	int speed;
	int move_distance;
	int sleep_time ;

	if(h_parking_step==0)
	{
		distance_3 = dist_milli(3);	


		if(distance_3 <= (parking_length) )		// 2 encoder = 1 mm 
		{
			SpeedControlOnOff_Write(CONTROL);   // speed controller must be also ON !!!
	        speed = 100; // speed set     --> speed must be set when using position controller
	        DesireSpeed_Write(speed);

	        //control on/off
	        PositionControlOnOff_Write(CONTROL);

	        //position controller gain set
	        int gain = 5;
	        PositionProportionPoint_Write(gain);

	        // int move_distance = (parking_length/2) - distance_3/2 - 80;
			move_distance = 200;
	        

	        if(move_distance>0)
		        DesireEncoderCount_Write(move_distance);


	
	        cout<<"move_distance : "<<move_distance<<endl;
	        sleep_time = (move_distance/500)*1000000 + 1000000;
	        usleep(sleep_time);

			//DesireSpeed_Write(0);
			Alarm_Write(ON);
			h_parking_step++;
		}
		return 0;
	}
	else if(h_parking_step == 1)
	{
		SteeringServoControl_Write(1000);
		usleep(500000);	//100ms

		speed = -150; // speed set     --> speed must be set when using position controller
        DesireSpeed_Write(speed);

		// move_distance = -( (parking_length + distance_3*2) * CV_PI/3   + 20) ;
		move_distance =  -800*CV_PI/2 ;	// perfectly !!
		cout<<"move_distance : "<<move_distance<<endl;

        DesireEncoderCount_Write(move_distance);



		sleep_time = abs(move_distance/500)*1000000 + 1000000;
		
        usleep(sleep_time);
        
        PositionControlOnOff_Write(UNCONTROL);
        
        usleep(200000);



		DesireSpeed_Write(0);
        SteeringServoControl_Write(1507);
		usleep(1000000);	//100ms


		if (dist_milli(4) > 200)
		{
			DesireSpeed_Write(-100);
			cout<<"dist_4 > 290"<<endl;
			while( dist_milli(4) > 200)
			{
				distance_driving_2();
			}
		}
		else
		{
			DesireSpeed_Write(100);
			cout<<"dist_4 < 290"<<endl;	
			while( dist_milli(4) < 200)
			{
				distance_driving_2();
			}
		}

		h_parking_step++;
		return 0;
	}
	else if(h_parking_step == 2)
	{
		speed = 150; // speed set     --> speed must be set when using position controller
        DesireSpeed_Write(speed);

        //control on/off
        PositionControlOnOff_Write(CONTROL);

        //position controller gain set
       

        move_distance = 560;

        if(move_distance>0)
	        DesireEncoderCount_Write(move_distance);


	
        cout<<"move_distance : "<<move_distance<<endl;
        sleep_time = (move_distance/500)*1000000 + 1000000;
        usleep(sleep_time);


        PositionControlOnOff_Write(UNCONTROL);

		DesireSpeed_Write(0);

		h_parking_step++;
	}
	else if(h_parking_step == 3)
	{
		SteeringServoControl_Write(2000);
		usleep(200000);


		DesireSpeed_Write(-100);
		while ( dist_milli(4) > 50 || dist_milli(1) <180)
		{
			usleep(1000);
		}

		h_parking_step++;
	}
	else if(h_parking_step ==4)
	{
		DesireSpeed_Write(0);
		Alarm_Write(ON);
		sleep(3);

		h_parking_step ++;
	}
	else if(h_parking_step ==5)
	{
 		speed = 120; // speed set     --> speed must be set when using position controller
        DesireSpeed_Write(speed);

        //control on/off
        PositionControlOnOff_Write(CONTROL);

        //position controller gain set
       

        move_distance = 800 * CV_PI / 2 - 150;

        if(move_distance>0)
	        DesireEncoderCount_Write(move_distance);


	
        cout<<"move_distance : "<<move_distance<<endl;
        sleep_time = (move_distance/500)*1000000 + 1000000;
        usleep(sleep_time);


        PositionControlOnOff_Write(UNCONTROL);
        DesireSpeed_Write(0);
        usleep(200000);
        h_parking_step++;
	}
	else if(h_parking_step == 6)
	{

		SteeringServoControl_Write(1507);
		usleep(400000);
		DesireSpeed_Write(-100);


		cout<<"distance_3 : "<<distance_3<<endl;
		cout<<"total : "<<240 + distance_3 - 200<<endl;
		while(dist_milli(4) > 150)	// distance sensor ......
		{
			usleep(1000);
		}

		DesireSpeed_Write(0);
		h_parking_step++;
	}
	else if(h_parking_step ==7)
	{
		DesireSpeed_Write(100);

		//overtaking_lane_driving(img_warp, output_img);
		//parking_img

		Mat img_line;
		cvtColor(img, img_line, COLOR_GRAY2BGR);


		Mat img_warp_rotate(img.cols,img.rows,CV_8UC1);
		
		for (int i = 0; i < img.cols;i++)	//rows
		{
			uchar* img_warp_rotate_pointer_row = img_warp_rotate.ptr<uchar>(i);
			for (int j = 0; j < img.rows;j++)	//cols
			{
				img_warp_rotate_pointer_row[j] = img.at<uchar>(179-j,i);
			}
		}

		int left = 0, right = 0;

		uchar* img_warp_rotate_pointer_row = img_warp_rotate.ptr<uchar>(80);
		for (int i = 0; i< 179; i++)
		{
			if(img_warp_rotate_pointer_row[i] && img_warp_rotate_pointer_row[i+1])
			{
				left = i;
				break;
			}
			
		}
		img_warp_rotate_pointer_row = img_warp_rotate.ptr<uchar>(240);
		for (int i = 0; i< 179; i++)
		{
			if(img_warp_rotate_pointer_row[i]  && img_warp_rotate_pointer_row[i+1] )
			{
				right = i;
				break;
			}
			
		}
		int left_right_sub;
		left_right_sub = abs(left-right);


		if(left && right && left<35 && right<35)
		{
			DesireSpeed_Write(0);
			return 1;

			//v_parking_step++;
		}
		else if(left && right && left_right_sub<10)
		{

			SteeringServoControl_Write(1507 + (right-left)*10);
			line(img_line, Point2f(80,180-left),Point2f(240,180-right), Scalar(0,0,255),2);

		}
	
	
	
		img_line.copyTo(output_img);
		return 0;
	
	}


	img.copyTo(output_img);
	return 0;

}


/*
void H_parking(int parking_length)
{
	int distance_3 = dist_milli(3);			// 0829 _ 5cm

	if(distance_3 <= (parking_length) )		// 2 encoder = 1 mm 
	{
		SpeedControlOnOff_Write(CONTROL);   // speed controller must be also ON !!!
        int speed = 100; // speed set     --> speed must be set when using position controller
        DesireSpeed_Write(speed);

        //control on/off
        PositionControlOnOff_Write(CONTROL);

        //position controller gain set
        int gain = 5;
        PositionProportionPoint_Write(gain);

        // int move_distance = (parking_length/2) - distance_3/2 - 80;
		int move_distance = 200;
        

        if(move_distance>0)
	        DesireEncoderCount_Write(move_distance);


	
        cout<<"move_distance : "<<move_distance<<endl;
        int sleep_time = (move_distance/500)*1000000 + 1000000;
        usleep(sleep_time);

		//DesireSpeed_Write(0);
		Alarm_Write(ON);



		// int encoder_start = EncoderCounter_Read();
		// usleep(30000);
		// int encoder_end = encoder_start + distance_3 +20;	// go dist_3 / 2 mm	
		// int now_encoder;
		
		// now_encoder = EncoderCounter_Read();
		// usleep(30000);

		// DesireSpeed_Write(50);
		// while( now_encoder < encoder_end)
		// {
		// 	now_encoder = EncoderCounter_Read();
		// 	usleep(30000);	//10ms
		// 	cout<<now_encoder<<endl;
		// }

		// DesireSpeed_Write(0);
		// Alarm_Write(ON);
		
		// sleep(5);


		SteeringServoControl_Write(1000);
		usleep(500000);	//100ms

		speed = -150; // speed set     --> speed must be set when using position controller
        DesireSpeed_Write(speed);

		// move_distance = -( (parking_length + distance_3*2) * CV_PI/3   + 20) ;
		move_distance =  -800*CV_PI/2 ;	// perfectly !!
		cout<<"move_distance : "<<move_distance<<endl;

        DesireEncoderCount_Write(move_distance);



		sleep_time = abs(move_distance/500)*1000000 + 1000000;
		
        usleep(sleep_time);
        
        PositionControlOnOff_Write(UNCONTROL);
        
        usleep(200000);



		DesireSpeed_Write(0);
        SteeringServoControl_Write(1507);
		usleep(1000000);	//100ms


		if (dist_milli(4) > 200)
		{
			DesireSpeed_Write(-100);
			cout<<"dist_4 > 290"<<endl;
			while( dist_milli(4) > 200)
			{
				distance_driving_2();
			}
		}
		else
		{
			DesireSpeed_Write(100);
			cout<<"dist_4 < 290"<<endl;	
			while( dist_milli(4) < 200)
			{
				distance_driving_2();
			}
		}



        speed = 150; // speed set     --> speed must be set when using position controller
        DesireSpeed_Write(speed);

        //control on/off
        PositionControlOnOff_Write(CONTROL);

        //position controller gain set
       

        move_distance = 560;

        if(move_distance>0)
	        DesireEncoderCount_Write(move_distance);


	
        cout<<"move_distance : "<<move_distance<<endl;
        sleep_time = (move_distance/500)*1000000 + 1000000;
        usleep(sleep_time);


        PositionControlOnOff_Write(UNCONTROL);




		DesireSpeed_Write(0);
		usleep(500000);
















		// SteeringServoControl_Write(1000);
		// usleep(500000);	//500ms



		// encoder_start = EncoderCounter_Read();
		// usleep(30000);

		// encoder_end = encoder_start - ( (distance_3+15) * CV_PI *3 / 2);		// 2pi * distance_3 * 1/4 mm
		
		// now_encoder = EncoderCounter_Read();
		// usleep(30000);

		// DesireSpeed_Write(-120);


		// while( now_encoder > encoder_end)
		// {
		// 	now_encoder = EncoderCounter_Read();
		// 	usleep(100);	//10ms
		// 	cout<<now_encoder<<endl;
		// }

		// DesireSpeed_Write(0);
		// Alarm_Write(ON);
		// SteeringServoControl_Write(1507);
		// usleep(100000);	//100ms
		









		// int distance_4 = dist_milli(4);
		// DesireSpeed_Write(-80);
		// while (distance_4 > 260)
		// {
		// 	distance_4 = dist_milli(4);
		// 	usleep(10000);
		// }
		// DesireSpeed_Write(0);





		SteeringServoControl_Write(2000);
		usleep(200000);


		DesireSpeed_Write(-100);
		while ( dist_milli(4) > 50 || dist_milli(1) <180)
		{
			usleep(1000);
		}



		encoder_start = EncoderCounter_Read();
		usleep(100);

		//encoder_end = encoder_start + 320 - ( distance_4 * CV_PI *3 / 2);		// 2pi * distance_4 * 1/4 mm
		encoder_end = encoder_start - (800 * CV_PI / 2);		// 2pi * distance_4 * 1/4 mm

		now_encoder = EncoderCounter_Read();
		usleep(20000);

		DesireSpeed_Write(-120);


		while( now_encoder > encoder_end)
		{
			now_encoder = EncoderCounter_Read();
			usleep(20000);	//10ms
		}




		DesireSpeed_Write(0);
		Alarm_Write(ON);
		sleep(3);




		// encoder_end = now_encoder + 400;
		// DesireSpeed_Write(80);

		// while( now_encoder < encoder_end)
		// {
		// 	now_encoder = EncoderCounter_Read();
		// 	usleep(20000);	//10ms
		// }

		// DesireSpeed_Write(0);
		// usleep(50000);

		// SteeringServoControl_Write(1507);
		// usleep(50000);

		// DesireSpeed_Write(-80);
		// usleep(1000000);

		// DesireSpeed_Write(0);
		// usleep(50000);


		// SteeringServoControl_Write(1000);
		// usleep(50000);


        speed = 120; // speed set     --> speed must be set when using position controller
        DesireSpeed_Write(speed);

        //control on/off
        PositionControlOnOff_Write(CONTROL);

        //position controller gain set
       

        move_distance = 800 * CV_PI / 2 - 150;

        if(move_distance>0)
	        DesireEncoderCount_Write(move_distance);


	
        cout<<"move_distance : "<<move_distance<<endl;
        sleep_time = (move_distance/500)*1000000 + 1000000;
        usleep(sleep_time);






		
		// encoder_start = EncoderCounter_Read();
		
		// usleep(100);
		// now_encoder = encoder_start;

		// encoder_end = encoder_start + (400 * CV_PI / 4);	// 2pi * distance_4 * 1/4 mm
		// DesireSpeed_Write(120);

		// while( now_encoder < encoder_end)
		// {
		// 	now_encoder = EncoderCounter_Read();
		// 	usleep(100);	//10ms
		// 	cout<<now_encoder<<endl;
		// }

		// DesireSpeed_Write(0);
		// // usleep(25000);

		// SteeringServoControl_Write(1507);
		// usleep(300000);



  //       speed = 800; // speed set     --> speed must be set when using position controller
  //       DesireSpeed_Write(speed);

  //       //control on/off
  //       //PositionControlOnOff_Write(CONTROL);

  //       move_distance = 600;
		// DesireEncoderCount_Write(move_distance);
	
  //       cout<<"move_distance : "<<move_distance<<endl;
  //       sleep_time = (move_distance/500)*1000000 + 1000000;
  //       usleep(sleep_time);







        PositionControlOnOff_Write(UNCONTROL);
        DesireSpeed_Write(0);
        usleep(200000);
		// DesireSpeed_Write(-100);
		// usleep(800000);
		// DesireSpeed_Write(0);

		SteeringServoControl_Write(1507);
		usleep(400000);
		DesireSpeed_Write(-100);


		cout<<"distance_3 : "<<distance_3<<endl;
		cout<<"total : "<<240 + distance_3 - 200<<endl;
		while(dist_milli(4) > 200)	// distance sensor ......
		{
			usleep(1000);
		}

		DesireSpeed_Write(0);


		SteeringServoControl_Write(1000);
		usleep(200000);
		
		
		speed = 150; // speed set     --> speed must be set when using position controller
        DesireSpeed_Write(speed);

        //control on/off
        PositionControlOnOff_Write(CONTROL);

        move_distance = 800 * CV_PI / 2;
        DesireEncoderCount_Write(move_distance);

        sleep_time = abs(move_distance/500)*1000000 + 1000000;
		
        usleep(sleep_time);
        PositionControlOnOff_Write(UNCONTROL);

		SteeringServoControl_Write(1507);
		//opencv_driving_status = 1;
		DesireSpeed_Write(0);
		usleep(1000000);

		parking_status = 1;








		// DesireSpeed_Write(100);
		// usleep(3000000);


		// encoder_start = EncoderCounter_Read();
		// usleep(100);
		// now_encoder = encoder_start;
		
		// DesireSpeed_Write(0);
		// usleep(20000);
		// SteeringServoControl_Write(1150);
		// usleep(50000);
		
		// encoder_end = encoder_start + (850 * CV_PI / 4);		// 2pi * distance_4 * 1/4 mm
		// DesireSpeed_Write(120);

		// while( now_encoder < encoder_end)
		// {
		// 	now_encoder = EncoderCounter_Read();
		// 	usleep(100);	//10ms
		// 	cout<<now_encoder<<endl;
		// }






		// DesireSpeed_Write(0);
		// Alarm_Write(ON);
		// usleep(3000000);



		

		// // SteeringServoControl_Write(1507);
		// // DesireSpeed_Write(80);
		// // usleep(1800000);
		// // SteeringServoControl_Write(1000);
		// // usleep(4800000);
		// // SteeringServoControl_Write(1507);
		
		// DesireSpeed_Write(0);
		// usleep(1000000);
		// parking_status = 1;
	}
	return;

}
*/






/* 2020 09 20 추가  카메라 사용하면서 거리센서 주행 코드*/
int distance_driving_3(int steering_control_onoff)
{
	
	// steering_control_onoff
	//	1 = on
	//	0 = off

	// return 
	// 0 : not working
	// steering_angle

	int dist_2 = 0;
	int dist_3 = 0;
	int dist_5 = 0;
	int dist_6 = 0;

	int steering_angle = 1507;

	if (dist_milli(2) < 250)
		dist_2 = dist_milli(2);
	if (dist_milli(3) < 250)
		dist_3 = dist_milli(3);
	if (dist_milli(5) < 250)
		dist_5 = dist_milli(5);
	if (dist_milli(6) < 250)
		dist_6 = dist_milli(6);

	if (dist_2 + dist_3 + dist_5 + dist_6 == 0)
	{
		cout << "non detect" << endl;
		return 0;
	}


	if (dist_2 && dist_3 && dist_5 && dist_6)
	{
		cout << "all distance detect" << endl;

		double left_angle = 0, right_angle = 0, avg_angle = 0;
		int left_dist, right_dist, sub_dist;
		left_dist = dist_5 + dist_6;
		right_dist = dist_2 + dist_3;
		sub_dist = left_dist - right_dist;

		left_angle = atan(double(dist_6 - dist_5) / 280) * 180 / CV_PI;
		right_angle = atan(double(dist_3 - dist_2) / 280) * 180 / CV_PI;
		avg_angle = (left_angle + right_angle) / 2;

		// cout<<"left_angle : " << left_angle <<endl;
		// cout<<"right_angle : " << right_angle <<endl;

		cout << "avg_angle : " << avg_angle << endl;
		//    / : '-'  , \ : '+'

		steering_angle = 1507 + int(avg_angle * 16.67) + sub_dist;
		if (steering_angle <= 1000)
			steering_angle = 1000;
		else if (steering_angle >= 2000)
			steering_angle = 2000;

		cout << "steering_angle : " << steering_angle << endl;
		// 60 : 1000, 90 : 1507,  120 : 2000
		if (steering_control_onoff)
			SteeringServoControl_Write(steering_angle);

		pre_dist2 = dist_2;
		pre_dist3 = dist_3;
		pre_dist5 = dist_5;
		pre_dist6 = dist_6;
		pre_encoder = EncoderCounter_Read();
		usleep(10000);
	}
	else if (dist_2 && dist_6)
	{
		cout << "front distance detect" << endl;
		//pre_dist_right = dist_2, pre_dist_left = dist_6;


		double left_angle = 0, right_angle = 0, avg_angle = 0;

		int left_dist, right_dist, sub_dist;
		left_dist = dist_6;
		right_dist = dist_2;
		sub_dist = left_dist - right_dist;


		int now_encoder = EncoderCounter_Read();
		usleep(10000);
		cout << "now_encoder : " << now_encoder << endl;
		cout << "pre_encoder_front : " << pre_encoder << endl;


		if (now_encoder != pre_encoder && pre_dist2 && pre_dist6)
		{
			left_angle = atan(double(dist_6 - pre_dist6) / double((now_encoder - pre_encoder) / 2)) * 180 / CV_PI;

			right_angle = atan(double(pre_dist2 - dist_2) / double((now_encoder - pre_encoder) / 2)) * 180 / CV_PI;

			avg_angle = (left_angle + right_angle) / 2;
			cout << "avg_angle : " << avg_angle << endl;



			steering_angle = 1507 + int(avg_angle * 16.67) + sub_dist;
			if (steering_angle <= 1000)
				steering_angle = 1000;
			else if (steering_angle >= 2000)
				steering_angle = 2000;

			cout << "steering_angle : " << steering_angle << endl;
			// 60 : 1000, 90 : 1507,  120 : 2000
			if (steering_control_onoff)
				SteeringServoControl_Write(steering_angle);
		}

		pre_dist2 = dist_2;
		pre_dist6 = dist_6;
		pre_encoder = now_encoder;

	}
	else if (dist_3 && dist_5)
	{
		cout << "rear distance detect" << endl;

		double left_angle = 0, right_angle = 0, avg_angle = 0;

		int left_dist, right_dist, sub_dist;
		left_dist = dist_5;
		right_dist = dist_3;
		sub_dist = left_dist - right_dist;


		int now_encoder = EncoderCounter_Read();
		usleep(10000);
		cout << "now_encoder : " << now_encoder << endl;
		cout << "pre_encoder_rear : " << pre_encoder << endl;

		if (now_encoder != pre_encoder && pre_dist3 && pre_dist5)
		{
			left_angle = atan(double(dist_5 - pre_dist5) / double((now_encoder - pre_encoder) / 2)) * 180 / CV_PI;

			right_angle = atan(double(pre_dist3 - dist_3) / double((now_encoder - pre_encoder) / 2)) * 180 / CV_PI;

			avg_angle = (left_angle + right_angle) / 2;
			cout << "avg_angle : " << avg_angle << endl;


			steering_angle = 1507 + int(avg_angle * 16.67) + sub_dist;
			if (steering_angle <= 1000)
				steering_angle = 1000;
			else if (steering_angle >= 2000)
				steering_angle = 2000;

			cout << "steering_angle : " << steering_angle << endl;
			// 60 : 1000, 90 : 1507,  120 : 2000
			if (steering_control_onoff)
				SteeringServoControl_Write(steering_angle);
		}

		pre_dist3 = dist_3;
		pre_dist5 = dist_5;
		pre_encoder = now_encoder;
	}
	else
	{
		pre_dist2 = dist_2;
		pre_dist6 = dist_6;
		pre_dist3 = dist_3;
		pre_dist5 = dist_5;
		pre_encoder = EncoderCounter_Read();
		usleep(10000);
	}


	return steering_angle;
}















int distance_driving_2()
{

	//int dist_1 = 0;
	int dist_2 = 0;
	int dist_3 = 0;
	//int dist_4 = 0;
	int dist_5 = 0;
	int dist_6 = 0;

	int steering_angle = 1507;

	// if ( dist_milli(1) < 250 )
	// 	dist_1 = dist_milli(1);
	if ( dist_milli(2) < 250 )
		dist_2 = dist_milli(2);
	if ( dist_milli(3) < 250 )
		dist_3 = dist_milli(3);
	// if ( dist_milli(4) < 250 )
	// 	dist_4 = dist_milli(4);
	if ( dist_milli(5) < 250 )
		dist_5 = dist_milli(5);
	if ( dist_milli(6) < 250 )
		dist_6 = dist_milli(6);


	if (dist_2 + dist_3 + dist_5 + dist_6 == 0)
	{
		cout<<"non detect"<<endl;
		return 0;
	}




	if (dist_2 && dist_3 && dist_5 && dist_6)
	{
		cout<<"all distance detect"<<endl;

		double left_angle = 0, right_angle = 0, avg_angle = 0;
		int left_dist, right_dist, sub_dist;
		left_dist = dist_5 + dist_6;
		right_dist = dist_2 + dist_3;
		sub_dist = left_dist-right_dist;



		left_angle = atan( double(dist_6-dist_5)/280 ) * 180 / CV_PI ;

		right_angle = atan( double(dist_3-dist_2)/280 )* 180 / CV_PI ;

		avg_angle = (left_angle + right_angle)/2;

// cout<<"left_angle : " << left_angle <<endl;
// cout<<"right_angle : " << right_angle <<endl;

		cout<<"avg_angle : " << avg_angle <<endl;
		//    / : '-'  , \ : '+'



		if(DesireSpeed_Read() > 0)
		{
			steering_angle = 1507 + int(avg_angle*16.67) + sub_dist;
		}

		else if(DesireSpeed_Read()<0)
		{
			steering_angle = 1507 - int(avg_angle*16.67) - sub_dist;

		}
		if(steering_angle <=1000)
			steering_angle = 1000;
		else if(steering_angle >=2000)
			steering_angle = 2000;

		cout<<"steering_angle : " << steering_angle <<endl;
		// 60 : 1000, 90 : 1507,  120 : 2000
		if(opencv_steering_control)
			SteeringServoControl_Write(steering_angle);	


		pre_dist2 = dist_2;
		pre_dist3 = dist_3;
		pre_dist5 = dist_5;
		pre_dist6 = dist_6;
		pre_encoder =  EncoderCounter_Read();
		usleep(10000);


	}
	else if (dist_2 && dist_6)
	{
		cout<<"front distance detect"<<endl;
		//pre_dist_right = dist_2, pre_dist_left = dist_6;
		

		double left_angle = 0, right_angle = 0, avg_angle = 0;

		int left_dist, right_dist, sub_dist;
		left_dist = dist_6;
		right_dist = dist_2;
		sub_dist = left_dist-right_dist;


		int now_encoder = EncoderCounter_Read();
		usleep(10000);
		cout<< "now_encoder : " << now_encoder <<endl;
		cout<< "pre_encoder_front : " << pre_encoder <<endl;


		if(now_encoder != pre_encoder && pre_dist2 && pre_dist6)
		{
			left_angle = atan( double(dist_6 - pre_dist6) / double((now_encoder - pre_encoder)/2) ) * 180 / CV_PI;

			right_angle = atan( double(pre_dist2 - dist_2) / double((now_encoder - pre_encoder)/2) ) * 180 / CV_PI;

			avg_angle = (left_angle + right_angle)/2;
			cout<<"avg_angle : " << avg_angle <<endl;

			
			if(DesireSpeed_Read() > 0)
			{
				steering_angle = 1507 + int(avg_angle*16.67) + sub_dist;
			}

			else if(DesireSpeed_Read()<0)
			{
				steering_angle = 1507 - int(avg_angle*16.67) - sub_dist;

			}
		
			if(steering_angle <=1000)
				steering_angle = 1000;
			else if(steering_angle >=2000)
				steering_angle = 2000;

			cout<<"steering_angle : " << steering_angle <<endl;
			// 60 : 1000, 90 : 1507,  120 : 2000
			if(opencv_steering_control)
				SteeringServoControl_Write(steering_angle);	
		}
		
		pre_dist2 = dist_2;
		pre_dist6 = dist_6;
		pre_encoder = now_encoder;

	}
	else if (dist_3 && dist_5)
	{
		cout<<"rear distance detect"<<endl;

		double left_angle = 0, right_angle = 0, avg_angle = 0;

		int left_dist, right_dist, sub_dist;
		left_dist = dist_5;
		right_dist = dist_3;
		sub_dist = left_dist-right_dist;


		int now_encoder = EncoderCounter_Read();
		usleep(10000);
		cout<< "now_encoder : " << now_encoder <<endl;
		cout<< "pre_encoder_rear : " << pre_encoder <<endl;

		if(now_encoder != pre_encoder && pre_dist3 && pre_dist5)
		{
			left_angle = atan( double(dist_5 - pre_dist5) / double((now_encoder - pre_encoder)/2) ) * 180 / CV_PI;

			right_angle = atan( double(pre_dist3 - dist_3) / double((now_encoder - pre_encoder)/2) ) * 180 / CV_PI;

			avg_angle = (left_angle + right_angle)/2;
			cout<<"avg_angle : " << avg_angle <<endl;

			if(DesireSpeed_Read() > 0)
			{
				steering_angle = 1507 + int(avg_angle*16.67) + sub_dist;
			}

			else if(DesireSpeed_Read()<0)
			{
				steering_angle = 1507 - int(avg_angle*16.67) - sub_dist;

			}
			if(steering_angle <=1000)
				steering_angle = 1000;
			else if(steering_angle >=2000)
				steering_angle = 2000;

			cout<<"steering_angle : " << steering_angle <<endl;
			// 60 : 1000, 90 : 1507,  120 : 2000
			if(opencv_steering_control)
				SteeringServoControl_Write(steering_angle);	
		}
		

		

		pre_dist3 = dist_3;
		pre_dist5 = dist_5;
		pre_encoder = now_encoder;
	}
	else
	{
		pre_dist2 = dist_2;
		pre_dist6 = dist_6;
		pre_dist3 = dist_3;
		pre_dist5 = dist_5;
		pre_encoder = EncoderCounter_Read();
		usleep(10000);
	}


	return steering_angle;


}













void distance_driving()		// adjust steering by distance 	
{
	int dist_1 = 0;
	int dist_2 = 0;
	int dist_3 = 0;
	int dist_4 = 0;
	int dist_5 = 0;
	int dist_6 = 0;


	if ( dist_milli(1) < 250 )
		dist_1 = dist_milli(1);
	if ( dist_milli(2) < 250 )
		dist_2 = dist_milli(2);
	if ( dist_milli(3) < 250 )
		dist_3 = dist_milli(3);
	if ( dist_milli(4) < 250 )
		dist_4 = dist_milli(4);
	if ( dist_milli(5) < 250 )
		dist_5 = dist_milli(5);
	if ( dist_milli(6) < 250 )
		dist_6 = dist_milli(6);

	if (dist_2 + dist_3 + dist_5 + dist_6 == 0)
	{
		return;
	}

	if(dist_1)
	{
		cout << "detect front 		wall : "<< dist_1 << endl;
	}
	
	if(dist_2)
	{
		cout << "detect front right wall : "<< dist_2 << endl;
	}

	if(dist_3)
	{
		cout << "detect rear right wall : "<< dist_3 << endl;
	}

	if(dist_4)
	{
		cout << "detect rear 		wall : "<< dist_4 << endl;
	}

	if(dist_5)
	{
		cout << "detect rear left wall : "<< dist_5 << endl;
	}

	if(dist_6)
	{
		cout << "detect front left wall : "<< dist_6 << endl;
	}



	if(dist_1 && dist_1 < 50 && DesireSpeed_Read() > 0)
	{
		DesireSpeed_Write(0);
		cout << "front :: emergency stop : " << dist_1 << endl;
	}

	if(dist_4 && dist_4 < 50 && DesireSpeed_Read() < 0)
	{
		DesireSpeed_Write(0);
		cout << "rear :: emergency stop : " << dist_4 << endl;
	}

	int front_sum = dist_2 + dist_6;
	int rear_sum = dist_3 + dist_5;

	if( front_sum > 200 && front_sum < 240)
	{
		if( dist_2 > dist_6)
			dist_6 = 180-dist_2;
		else
			dist_2 = 180-dist_6;
	}
	if( rear_sum > 200 && rear_sum < 240)
	{
		if( dist_3 > dist_5)
			dist_5 = 180-dist_3;
		else
			dist_3 = 180-dist_5;
	}






/*

|    \|		|    /|		|    ||
|   \ |		|   / |		|   | |
|  \  |		|  /  |		|  |  |
| \   |		| /   |		| |   |
|\    |		|/    |		||    |


┌──────		
|  
|  |
|  |  |
|     |
|     |

──────┐
      |
   |  |
|  |  |
|     |
|     |


*/


	if( !dist_1 && dist_2 && dist_3 && dist_5 && dist_6)	// straight _ front&rear
	{
		SteeringServoControl_Write(1507 + (dist_5 + dist_6 - dist_2 - dist_3)*2 );
	}

	else if( !dist_1 && dist_2 && dist_6)	// straight _ front
	{
		//int steering_angle = SteeringServoControl_Read();
		SteeringServoControl_Write(1507 + (dist_6 - dist_2)*2 );
		//usleep(25000);	// 25ms
	}
	else if( dist_1 && dist_2 && dist_3 && dist_5 && dist_6 )
	{
		SteeringServoControl_Write(1507 + (dist_5 + dist_6 - dist_2 - dist_3)*3 );
	}

	else if( dist_1 && dist_2 > 150 && dist_3 && dist_5 && dist_6 )	// turn right
	{
		int adjust_value = (dist_2 - dist_3)*4;

		if ( adjust_value > 500 )
			adjust_value = 500;
				
		SteeringServoControl_Write(1507 - adjust_value );

	}
	else if( dist_1 && dist_2 && dist_3 && dist_5 && dist_6 > 150 )	// turn left
	{
		int adjust_value = (dist_6 - dist_5)*4;

		if ( adjust_value > 490 )
			adjust_value = 490;
				
		SteeringServoControl_Write(1507 + adjust_value );
	}

	else if( dist_1 && !dist_2 && dist_3 && dist_5 && dist_6 )	// turn right
	{
		SteeringServoControl_Write(1050);
	}
	else if( dist_1 && dist_2 && dist_3 && dist_5 && !dist_6 )	// turn left
	{
		SteeringServoControl_Write(1950);
	}



	return;


}
































// void filter_lane_detector(Mat* input_img, Mat* output_img, Mat* img_out, Mat* img_grayline, bool* pointer_steering_control, bool* pointer_cout_control, int* pointer_lcd_control)
// {
// 	Mat img_bgr, img_gray, img_blur, img_RoI, img_canny, img_hough, img_annotated;
// 	Mat img_filtered;
// 	Mat line_img;
// 	Mat curve_lane;

// 	input_img->copyTo(img_bgr);

// 	//int width = img.size().width;
// 	//int height = img.size().height;
// 	//int count = 0;
// 	//int start_sign = 1;
// 	//flip(img, img, -1);

// 	//cvtColor(img_bgr, img_gray, COLOR_RGB2GRAY);

// 	/* Lane Dectect Algorithme */
// 	GaussianBlur(img_bgr, img_blur, Size(9, 9), 0, 0);

// 	filter_colors(img_blur, img_filtered);

// 	//cvtColor(img_filtered, *output_img, COLOR_BGR2GRAY);
// 	img_filtered->copyTo(*img_grayline);


// 	//img_gray_line.copyTo(img_out);
// 	//Canny(img_gray, img_canny, 150, 350, 3);



// 	line_detector(*output_img);
// 	if (*pointer_lcd_control == 0)
// 	{
// 		make_line(img_filtered, pointer_steering_control, pointer_cout_control).copyTo(*img_out);
// 	}
// 	else
// 	{
// 		make_line(img_filtered, pointer_steering_control, pointer_cout_control);
// 	}
// 	//cout << pointer_lcd_control << endl;
// 	if (*pointer_lcd_control==1)
// 	{
// 		img_bgr.copyTo(*img_out);
// 	}
// 	else if(*pointer_lcd_control==2)	// Add 0804 // Show distance // testing
// 	{
// 		img_bgr.copyTo(*img_out);

// 		//pt -> using global variables
//         for (int i = 1; i < 7; i++)
//         {
//         	char myText[10];
// 			int dist = dist_milli(i);
//         	sprintf(myText, "%d", dist);

// 			if (dist<100)
// 				putText(*img_out, myText, dist_pt[i-1], 3, 1, Scalar(0,0,255), 1, 8);
// 			else if (dist < 200)
// 				putText(*img_out, myText, dist_pt[i-1], 3, 1, Scalar(255, 0, 0), 1, 8);
// 			else
// 				putText(*img_out, myText, dist_pt[i-1], 3, 1, Scalar::all(255), 1, 8);
//         }
// 	}
// 	else if (*pointer_lcd_control == 3)	// Add 0807 // Show red count // testing
// 	{
// 		//red_count_global_bool = 1;
// 		char myText[10];
// 		sprintf(myText, "%d", red_count_global);
// 		putText(*img_out, myText, Point(150,150), 3, 1, Scalar(0, 0, 255), 1, 8);


// 	}
// 	//else if (*pointer_lcd_control == 2)	// Add 0802 // Show distance // Low_speed...
// 	//{
// 	//	img_bgr.copyTo(*img_out);

// 	//	//string myText = "500";
// 	//	Point dist_pt[6];
// 	//	dist_pt[0] = Point(140, 40);
// 	//	dist_pt[1] = Point(210, 70);
// 	//	dist_pt[2] = Point(210, 130);
// 	//	dist_pt[3] = Point(140, 160);
// 	//	dist_pt[4] = Point(90, 130);
// 	//	dist_pt[5] = Point(90, 70);

// 	//	for (int i = 0; i < 6; i++)
// 	//	{
// 	//		char myText[20];
// 	//		//myText = double.toString(dist_cesnti(i+1));
// 	//		sprintf(myText, "%d", int(dist_centi(i + 1) * 10));
// 	//		//sprintf(myText, "%d", i+1);
// 	//		putText(*img_out, myText, dist_pt[i], 3, 1, Scalar::all(255), 1, 8);
// 	//	}

// 	//}
	
// 	//img_canny.copyTo(output_img);

// 	return;
// }

  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


/////////////	new code 	//////////////////////
void mission_check(Mat input_img, Mat* img_out, int* pointer_driving_status, bool* pointer_steering_control, bool* pointer_cout_control, int* pointer_lcd_control)				// checking mission
{
	if (*pointer_driving_status == 0)		//standard driving
	{
		mission = "driving";
		*pointer_steering_control = 1;
	}
	else if (*pointer_driving_status == 1)	//suddenly stop
	{
		mission = "suddenly_stop";
		//*pointer_steering_control = 1;
		find_stop_sign(input_img);
		cout << "		" << red_find << endl;
		if (red_find == 2)
		{
			*pointer_driving_status = 0;
		}
	}
	else if (*pointer_driving_status == 2)	//S-curve
	{
		mission = "S-curve";
		*pointer_steering_control = 1;
	}
	else if (*pointer_driving_status == 3)	//parking
	{
		mission = "parking";
		//parking_check();
		//*pointer_steering_control = 0;
	}
	else if (*pointer_driving_status == 4)	//round rotary
	{
		mission = "round rotary";
		//round_rotary(input_img, img_out);
		*pointer_steering_control = 1;
	}
	else if (*pointer_driving_status == 5)	//tunnel
	{
		mission = "tunnel";
		*pointer_steering_control = 0;
	}
	else if (*pointer_driving_status == 6)	//change lane
	{
		mission = "change lane";
		*pointer_steering_control = 0;
	}
	else if (*pointer_driving_status == 7)	//traffic
	{
		if (traffic_servo)
		{
			CameraYServoControl_Write(1580);
			traffic_servo = 0;
			usleep(2000000);
		}
		else if (~traffic_servo)
		{

			traffic_sign(input_img, img_out);

		}
	}
	else if (*pointer_driving_status == 10)	//capture
	{
		capture(input_img);
		*pointer_driving_status = 0;
	}
	else if (*pointer_driving_status == 15)	//follow
	{
		mission = "follow";
		follow(input_img);
		*pointer_steering_control = 0;
	}
	else if (*pointer_driving_status == 50)
	{
		*pointer_steering_control = 0;

	}
	else if (*pointer_driving_status == 60)		//encoder test
	{
		*pointer_steering_control = 0;
		cout << "before encoder" << endl;
		encoder_test();
		cout << "after encoder" << endl;
		*pointer_driving_status = 50;
	}
	else if (*pointer_driving_status == 70)		//encoder test
	{
		*pointer_steering_control = 0;
		cout << "before speed_encoder" << endl;
		speed_encoder_test();
		cout << "after speed_encoder" << endl;
		*pointer_driving_status = 50;
	}

/*
	0 : standard driving
	1 : suddenly stop
	2 : S-curve
	3 : parking
	4 : round rotary
	5 : tunnel
	6 : change lane
	7 : traffic light


	
*/

	return;
}




void encoder_test()
{
	CarControlInit();
	unsigned char status;
	short speed;
	unsigned char gain;
	int position, posInit, posDes, posRead;
//	short angle;
//	int channel;
//	int data;
//	char sensor;
//	int i, j;
	int tol;

	printf("\n\n 1. position control\n");

	//jobs to be done beforehand;
	SpeedControlOnOff_Write(CONTROL);   // speed controller must be also ON !!!
	speed = 80; // speed set     --> speed must be set when using position controller
	DesireSpeed_Write(speed);

	//control on/off
	status = PositionControlOnOff_Read();
	printf("PositionControlOnOff_Read() = %d\n", status);
	PositionControlOnOff_Write(CONTROL);

	//position controller gain set
	gain = PositionProportionPoint_Read();    // default value = 10, range : 1~50
	printf("PositionProportionPoint_Read() = %d\n", gain);
	gain = 30;
	PositionProportionPoint_Write(gain);

	//position write
	posInit = 0;  //initialize
	EncoderCounter_Write(posInit);

	//position set
	posDes = 4000;
	position = posInit + posDes;
	DesireEncoderCount_Write(position);

	position = DesireEncoderCount_Read();
	printf("DesireEncoderCount_Read() = %d\n", position);

	tol = 80;    // tolerance
	while (abs(posRead - position) > tol)
	{
		usleep(10000);
		posRead = EncoderCounter_Read();
		if (posRead != CHECKSUMERROR)
		{
			printf("EncoderCounter_Read() = %d\n", posRead);
		}
		else
		{
			printf("CHECKSUMERROR!, stop reading Encodercount! \n");
			break;
		}
	}

	return;
}



void speed_encoder_test()
{
	int posRead;
	PositionControlOnOff_Write(UNCONTROL);
	DesireSpeed_Write(100);
	EncoderCounter_Write(0);
	while (1)
	{
		posRead = EncoderCounter_Read();
		if (posRead != CHECKSUMERROR)
		{
			printf("EncoderCounter_Read() = %d\n", posRead);
		}
		else
		{
			printf("CHECKSUMERROR!, stop reading Encodercount! \n");
			break;
		}

	}
	return;
}





Mat make_line(Mat img, bool* pointer_steering_control, bool* pointer_cout_control)
{

int steering;
int degree;
  Mat img_bgr;
  img.copyTo(img_bgr);
  
  
  int width = img_bgr.size().width;
  int height = img_bgr.size().height;


   
	
  //left 1
  if(left1)
  {
	line(img_bgr, Point(left1_start, layer_1), Point(left1_start+left1_end, layer_1), Scalar(0, 0, 255), 1);
	circle(img_bgr, Point(left1_x, layer_1),5,Scalar(255,0,0));
  }
  else
    line(img_bgr, Point(left1_start, layer_1), Point(left1_start+left1_end, layer_1), Scalar(0, 255, 0), 1);
  //right 1
  if(right1)
{
	line(img_bgr,  Point(width-left1_start, layer_1),Point(width-(left1_start+left1_end), layer_1), Scalar(0, 0,255), 1);
	circle(img_bgr, Point(right1_x, layer_1),5,Scalar(255,0,0));
}
  else
    line(img_bgr,  Point(width-left1_start, layer_1),Point(width-(left1_start+left1_end), layer_1), Scalar(0, 255, 0), 1);
  //left 2
  if(left2)
  {
	line(img_bgr, Point(left2_start, layer_2), Point(left2_start+left2_end, layer_2), Scalar(0, 0, 255), 1);
	circle(img_bgr, Point(left2_x, layer_2),5,Scalar(255,0,0));
  }
  else
    line(img_bgr, Point(left2_start, layer_2), Point(left2_start+left2_end, layer_2), Scalar(0, 255, 0), 1);

  //right 2
  if(right2)
  {
	line(img_bgr, Point(width-left2_start, layer_2), Point(width-(left2_start+left2_end), layer_2), Scalar(0, 0,255), 1);
	circle(img_bgr, Point(right2_x, layer_2),5,Scalar(255,0,0));
  }
  else
    line(img_bgr, Point(width-left2_start, layer_2), Point(width-(left2_start+left2_end), layer_2), Scalar(0, 255, 0), 1);
  //left 3
  if(left3)
  {
    line(img_bgr, Point(left3_start, layer_3), Point(left3_start+left3_end, layer_3), Scalar(0, 0,255), 1);
    circle(img_bgr, Point(left3_x, layer_3),5,Scalar(255,0,0));
  }
  else
    line(img_bgr, Point(left3_start, layer_3), Point(left3_start+left3_end, layer_3), Scalar(0, 255, 0), 1);
  //right 3
  if(right3)
  {
    line(img_bgr, Point(width-left3_start, layer_3), Point(width-(left3_start+left3_end), layer_3), Scalar(0, 0, 255), 1);
    circle(img_bgr, Point(right3_x, layer_3),5,Scalar(255,0,0));
  }
  else
    line(img_bgr, Point(width-left3_start, layer_3), Point(width-(left3_start+left3_end), layer_3), Scalar(0, 255, 0), 1);
  //layer 4
  if(layer4)
    line(img_bgr, Point(0, layer_4), Point(320, layer_4), Scalar(255, 0,0), 1);
  else
    line(img_bgr, Point(0, layer_4), Point(320, layer_4), Scalar(0, 255, 0), 1);
    //layer 5
  if(layer5)
    line(img_bgr, Point(0, layer_5), Point(320, layer_5), Scalar(255, 0,0), 1);
  else
    line(img_bgr, Point(0, layer_5), Point(320, layer_5), Scalar(0, 255, 0), 1);
  


   
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  if (turn_left)
  {
	  degree = int((atan((160 - (double(2 * high_x - 320) / 2)) / (height - layer_4)) * 180 / pi) + 90);

	  steering = (11 * degree) + 600;		//원래는 500이었음

	  if (*pointer_steering_control == 1)
	  {
		  if (steering < 1000)
			  steering = 1000;
		  else if (steering > 2000)
			  steering = 2000;

		  SteeringServoControl_Write(steering);
	  }


	  if (*pointer_cout_control == 1)
	  {
		  cout << "turn_left" << endl;
		  cout << "	mission		degree		steering	steeringcontrol" << endl;
		  cout << "	" << mission << "		" << degree << "		" << steering << "		" << *pointer_steering_control <<endl;
	  }

	  if ((left1 || left2 || left3) && (right1 || right2 || right3) && ~lane_middle)
		  turn_left = 0;
  }
  else if (turn_right)
  {
	  degree = int((atan((160 - (double(2 * high_x + 320) / 2)) / (height - layer_4)) * 180 / pi) + 90);
	  steering = (11 * degree) + 600;		//원래는 500이었음

	  if (*pointer_steering_control == 1)
	  {
		  if (steering < 1000)
			  steering = 1000;
		  else if (steering > 2000)
			  steering = 2000;

		  SteeringServoControl_Write(steering);
	  }


	  if (*pointer_cout_control == 1)
	  {
		  cout << "turn_right" << endl;
		  cout << "	mission		degree		steering	steeringcontrol" << endl;
		  cout << "	" << mission << "		" << degree << "		" << steering << "		" << *pointer_steering_control << endl;
	  }
	  if ((left1 || left2 || left3) && (right1 || right2 || right3) && ~lane_middle)
		  turn_right = 0;
  }
  

  else if( (left1||left2||left3) && (right1||right2||right3)   )	// left O / right O
   {
		line(img_bgr, Point(160, height-5), Point( ((left_lane + right_lane)/2), layer_1), Scalar(255, 0, 0), 3);
		// cout<<"test : "<<(((double(left3_x)+double(right3_x))/2)-320)/105<<endl;
		degree=int((atan((160-(double(left_lane + right_lane)/2))/(height-layer_1))*180/pi)+90);
    
		//cout<<"degree : "<<steering<<endl;
		steering = (11*degree)+ 500;
		
		if(*pointer_steering_control==1)
		{			
			if(steering<1000)
				steering=1000;
			else if(steering>2000)
				steering=2000;
			
			SteeringServoControl_Write(steering);
 		}
		
		
		
		if(*pointer_cout_control==1)
		{
			cout<<"	mission		degree		steering	steeringcontrol"<<endl;
			cout<<"	"<<mission<<"		"<<degree<<"		"<<steering<<"		"<< *pointer_steering_control<<endl;
		}
		
		
		
     }

   else if ((left1 || left2 || left3)==1  && (right1 || right2 || right3)==0)		// left O / right X
   {
   		line(img_bgr, Point(160, height - 5), Point(((2*left_lane + 260) / 2), layer_1), Scalar(226, 214, 56), 3);
	   // cout<<"test : "<<(((double(left3_x)+double(right3_x))/2)-320)/105<<endl;
	   degree = int((atan((160 - (double(2*left_lane + 300) / 2)) / (height - layer_1)) * 180 / pi) + 90);

	   //line(img_bgr, Point(160, height - 5), Point(((2*left_lane + 260) / 2), layer_1), Scalar(226, 214, 56), 3);
   	// 	line(img_bgr, Point(160, height - 5), Point(((2*left_lane + lane_distance) / 2), layer_1), Scalar(226, 214, 56), 3);

	   // // cout<<"test : "<<(((double(left3_x)+double(right3_x))/2)-320)/105<<endl;
	   // degree = int((atan((160 - (double(2*left_lane + lane_distance) / 2)) / (height - layer_1)) * 180 / pi) + 90);


		steering = (11*degree)+ 500;
		
		if(*pointer_steering_control==1)
		{			
			if(steering<1000)
				steering=1000;
			else if(steering>2000)
				steering=2000;
			
			SteeringServoControl_Write(steering);
 		}
		
		
		if(*pointer_cout_control==1)
		{
			cout<<"	mission		degree		steering	steeringcontrol"<<endl;
			cout<<"	"<<mission<<"		"<<degree<<"		"<<steering<<"		"<< *pointer_steering_control<<endl;
		}
		
		
   }
   else if ((left1 || left2 || left3) == 0 && (right1 || right2 || right3) == 1)		// left X / right O
   {
	   line(img_bgr, Point(160, height - 5), Point(((2 * right_lane - 260) / 2), layer_1), Scalar(226, 214, 56), 3);
	   // cout<<"test : "<<(((double(left3_x)+double(right3_x))/2)-320)/105<<endl;
	   
	   degree = int((atan((160 - (double(2 * right_lane - 300) / 2)) / (height - layer_1)) * 180 / pi) + 90);

	   // //line(img_bgr, Point(160, height - 5), Point(((2 * right_lane - 260) / 2), layer_1), Scalar(226, 214, 56), 3);
	   // line(img_bgr, Point(160, height - 5), Point(((2 * right_lane - lane_distance) / 2), layer_1), Scalar(226, 214, 56), 3);

	   // // cout<<"test : "<<(((double(left3_x)+double(right3_x))/2)-320)/105<<endl;
	   // degree = int((atan((160 - (double(2 * right_lane - (lane_distance)) / 2)) / (height - layer_1)) * 180 / pi) + 90);

		steering = (11*degree)+ 500;
		
		if(*pointer_steering_control==1)
		{			
			if(steering<1000)
				steering=1000;
			else if(steering>2000)
				steering=2000;
			
			SteeringServoControl_Write(steering);
 		}
		
		
		if(*pointer_cout_control==1)
		{
			cout<<"	mission		degree		steering	steeringcontrol"<<endl;
			cout<<"	"<<mission<<"		"<<degree<<"		"<<steering<<"		"<< *pointer_steering_control<<endl;
		}
		
   }
   else if (((left1 || left2 || left3) == 0 && (right1 || right2 || right3) == 0) && (high_bool && low_bool))		// left X / right X / high O / low O
  {
  line(img_bgr, high, low, Scalar(0, 0, 255), 3);

  degree = int((atan((double(low_x - high_x) / double(layer_5 - layer_4))) * 180 / PI) + 90);
  steering = (11 * degree) + 500;

  if (*pointer_steering_control == 1)
  {
	  if (steering < 1000)
		  steering = 1000;
	  else if (steering > 2000)
		  steering = 2000;

	  SteeringServoControl_Write(steering);
  }

  if (degree < 70)
  {
	  turn_right = 1;
  }
  else if (degree > 110)
  {
	  turn_left = 1;
  }

  if (*pointer_cout_control == 1)
  {
	  cout << "	mission		degree		steering	steeringcontrol" << endl;
	  cout << "	" << mission << "		" << degree << "		" << steering << "		" << *pointer_steering_control << endl;
  }
   }


	  // if (high_x > low_x)
	  // {
		 //  //cout<<"high_x : "s<<high_x<<"	"<<"low_x : "<<low_x<<endl;
	  // //	cout<<"steering : "<<int(2*(atan(( double(low_x-high_x)/double(layer_5 - layer_4) ) )*180/PI)+184)<<endl;
		 //  degree = int(1.9*(atan((double(low_x - high_x) / double(layer_5 - layer_4))) * 180 / PI) + 184);

			//steering = (11*degree)+ 500;
		
			//if(*pointer_steering_control==1)
			//{			
			//	if(steering<1000)
			//		steering=1000;
			//	else if(steering>2000)
			//		steering=2000;
			//
			//	SteeringServoControl_Write(steering);
			//}

			//if (degree < 70)
			//{
			//	turn_right = 1;
			//}
			//else if (degree > 110)
			//{
			//	turn_left = 1;
			//}
		 //  
			//if(*pointer_cout_control==1)
			//{
			//	cout<<"	mission		degree		steering	steeringcontrol"<<endl;
			//	cout<<"	"<<mission<<"		"<<degree<<"		"<<steering<<"		"<< *pointer_steering_control<<endl;
			//}
		 //  
	  // }
	  // else
	  // {
		 //  //cout<<"high_x : "<<high_x<<"	"<<"low_x : "<<low_x<<endl;
	  // //	cout<<"steering : "<<int(2*(atan(( double(high_x-low_x)/double(layer_5 - layer_4) ) )*180/PI)+175)<<endl;
		 //  degree = int(1.9*(atan((double(high_x - low_x) / double(layer_5 - layer_4))) * 180 / PI) + 175);



			//steering = (11*degree)+ 500;
		
			//if(*pointer_steering_control==1)
			//{			
			//	if(steering<1000)
			//		steering=1000;
			//	else if(steering>2000)
			//		steering=2000;
			//
			//	SteeringServoControl_Write(steering);
			//}
			//
			//if(*pointer_cout_control==1)
			//{
			//	cout<<"	mission		degree		steering	steeringcontrol"<<endl;
			//	cout<<"	"<<mission<<"		"<<degree<<"		"<<steering<<"		"<< *pointer_steering_control<<endl;
			//}
	  // }
   
   else
   {
	  
		if(*pointer_cout_control==1)
		{
		cout<<"	mission		degree		steering	steeringcontrol"<<endl;
		cout << "	" << mission << "		" << "not found" << "	" << "1500" << "		" << *pointer_steering_control << endl;
		}
	
	
	   if (*pointer_steering_control == 1)
	   {
		   SteeringServoControl_Write(1500);	
	   }
   }

  return img_bgr;
}


















void line_detector(Mat input_img)
{
  Mat img;
  input_img.copyTo(img);
  left1 = 0;
  left2 = 0;
  left3 = 0;
  right1 = 0;
  right2 = 0;
  right3 = 0;

  int width = img.size().width;
//  int height = img.size().height;
  for (int i = 1; i < 90; i++)
  {
	  //left
	  if (img.at<uchar>(i, 160) > 0)
	  {
		  lane_middle = 1;
		  break;
	  }
	  else
	  {
		  lane_middle = 0;
	  }
  }



	//detect left lane
	for(int i=1; i<left1_end; i++)
	{
		//left
		if(img.at<uchar>(layer_1,left1_start+i)>0)
		{
			left1=1;
			left1_x=left1_start+i;
			left_lane=left1_start+i;
			break;
		}
		else if(img.at<uchar>(layer_2,left2_start+i)>0)
		{
			left2=1;
			left2_x=left2_start+i;
			left_lane=left2_start+i;
			break;
		}
		else if(img.at<uchar>(layer_3,left3_start+i)>0)
		{
			left3=1;
			left3_x=left3_start+i;
			left_lane=left3_start+i;
			break;
		}
		else
		{
			left1=0,left2=0,left3=0;
		}
	}


//To faster....................................................................................
/*
if(left1||left2||left3)
{
}
*/
	for(int j=1; j<left1_end; j++)
	{
		//right
		if(img.at<uchar>(layer_1,width-left1_start-j)>0)
		{
			right1=1;
			right1_x=width-left1_start-j;
			right_lane=width-left1_start-j;
			break;
		}
		else if(img.at<uchar>(layer_2,width-left2_start-j)>0)
		{
			right2=1;
			right2_x=width-left2_start-j;
			right_lane=width-left2_start-j;
			break;
		}
		else if(img.at<uchar>(layer_3,width-left3_start-j)>0)
		{
			right3=1;
			right3_x=width-left3_start-j;
			right_lane=width-left3_start-j;
			break;
		}
		else
		{
			right1=0,right2=0,right3=0;
		}
	}





  return ;
    
}








void Find_curve_lane(Mat input_img1)			//input_img : ¿¬»êÇÒ ÀÌ¹ÌÁö, input_img : ¶óÀÎÀ» ÀÔÈú ÀÌ¹00000000ÌÁö
{
	Mat img1;
	input_img1.copyTo(img1);

	int width = img1.size().width;
//	int height = img1.size().height;
	for (int i = layer_4; i < layer_4+5; i++)
	{
		for (int j = 1;j < width;j++)
		{
			if (img1.at<uchar>(i, j) > 0)		//<uchar>(Çà,¿­)
			{
				high_bool=1;
				high = Point(j, i);						//Point(xÁÂÇ¥,yÁÂÇ¥)
				high_x=j;
				i = layer_4+5;
				break;
			}
			else
			{
				high_bool=0;
			}
		}
	}
	for (int i = layer_5; i < layer_5+5; i++)
	{
		for (int j = 1; j < width; j++)
		{
			if (img1.at<uchar>(i, j) > 0)
			{
				low_bool=1;
				low = Point(j, i);
				low_x=j;
				i = layer_5+5;
				break;
			}
			else
			{
				low_bool=0;
			}
		}
	}




	return ;
}
















void filter_colors(Mat _img_bgr, Mat &img_filtered)
{
	// Filter the image to include only yellow and white pixels
	Mat img_bgr;
	_img_bgr.copyTo(img_bgr);
	Mat img_hsv, img_combine;
//	Mat white_mask, white_image;
	Mat yellow_mask, yellow_image;
//	Mat red_mask, red_image;
//	Mat red_dark_mask, red_dark_image;

//Scalar lower_white = Scalar(210, 210, 210); 
//Scalar upper_white = Scalar(255, 255, 255);
Scalar lower_yellow = Scalar(20, 20, 100); 
Scalar upper_yellow = Scalar(40, 255, 255);
//Scalar lower_red = Scalar(0, 100, 30);			
//Scalar upper_red = Scalar(3, 165, 75);
//Scalar lower_dark_red = Scalar(173, 90, 33);			
//Scalar upper_dark_red = Scalar(180, 200, 200);

/*
  //white color
	inRange(img_bgr, lower_white, upper_white, white_mask);
	bitwise_and(img_bgr, img_bgr, white_image, white_mask);
	threshold(white_image, white_image, 100, 255, THRESH_BINARY);
*/
  //yellow color
	cvtColor(img_bgr, img_hsv, COLOR_BGR2HSV);
	inRange(img_hsv, lower_yellow, upper_yellow, yellow_mask);
	//bitwise_and(img_bgr, img_bgr, yellow_image, yellow_mask);
	//threshold(yellow_image, yellow_image, 60, 255, THRESH_BINARY);

//	yellow_image.setTo(Scalar(0, 255, 255), yellow_image);

//	bitwise_or(white_image, yellow_image, img_combine);
	erode(yellow_mask, yellow_mask, Mat::ones(Size(9, 3), CV_8UC1), Point(-1, -1));
	dilate(yellow_mask, yellow_mask, Mat::ones(Size(3, 15), CV_8UC1), Point(-1, -1));
//	img_combine.copyTo(img_filtered);
	yellow_mask.copyTo(img_filtered);
	//yellow_image.copyTo(img_filtered);

	

//erode(img_filtered, img_filtered, getStructuringElement(MORPH_ELLIPSE, Size(5,5)));
//dilate(img_filtered, img_filtered, getStructuringElement(MORPH_ELLIPSE, Size(5,5)));
//
//
//dilate(img_filtered, img_filtered, getStructuringElement(MORPH_ELLIPSE, Size(5,5)));
//erode(img_filtered, img_filtered, getStructuringElement(MORPH_ELLIPSE, Size(5,5)));

}




void filter_white_colors(Mat _img_bgr, Mat &img_filtered)
{
	// Filter the image to include only yellow and white pixels
	Mat img_bgr;
	_img_bgr.copyTo(img_bgr);

	Mat white_mask, white_image;

	Scalar lower_white = Scalar(120, 120, 120);
	Scalar upper_white = Scalar(255, 255, 255);

	//white color
	inRange(img_bgr, lower_white, upper_white, white_mask);
	bitwise_and(img_bgr, img_bgr, white_image, white_mask);
	threshold(white_image, white_image, 100, 255, THRESH_BINARY);

	white_image.copyTo(img_filtered);

	erode(img_filtered, img_filtered, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)));
	dilate(img_filtered, img_filtered, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)));


	dilate(img_filtered, img_filtered, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)));
	erode(img_filtered, img_filtered, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)));

}





/* New stop_sign Code */
/* Developed by Realbro */
/* 2020_08_07 */
// 2020-10-09 09 :27 PM 
// void -> int
int find_stop_sign(Mat input_image)
{

	Mat img_bgr;
	Mat img_hsv;
	int count = 0;

	input_image.copyTo(img_bgr);
	
	Rect middle = Rect(60,0,180,140);	//320 180
	Mat img_roi = img_bgr(middle);

	cvtColor(img_roi, img_hsv, COLOR_BGR2HSV);

	Mat red_mask, red_image;
	Mat dark_red_mask, dark_red_image;

	Scalar lower_red = Scalar(0, 50, 50);
	Scalar upper_red = Scalar(3, 205, 255);
	Scalar lower_dark_red = Scalar(173, 90, 33);
	Scalar upper_dark_red = Scalar(180, 255, 255);

	inRange(img_hsv,lower_red, upper_red, red_mask);	// dst : red_mask
	//bitwise_and(img_bgr, img_bgr, red_image, red_mask);	// dst : red_image
	//grayscale
	//cvtColor(red_image, red_image, COLOR_BGR2GRAY);


	inRange(img_hsv, lower_dark_red, upper_dark_red, dark_red_mask);
	//bitwise_and(img_bgr, img_bgr, dark_red_image, dark_red_mask);
	//grayscale
	//cvtColor(dark_red_image, dark_red_image, COLOR_BGR2GRAY);

	//red_image |= dark_red_image;
	red_mask |= dark_red_mask;
	//threshold(red_image, red_image, 10, 255, THRESH_BINARY);

	for (int j = 0; j < red_mask.rows; j++)
	{
		uchar* pointer_row = red_mask.ptr<uchar>(j);
		for (int i = 0; i < red_mask.cols; i++)
		{
			if (pointer_row[i] > 0)
			{
				count++;
			}

		}
	}


	
	/*
	input find stop sign code
	*/

	cout << "red_count : " << count << endl;
	
	red_count_global = count;
	//char myText[10];
	//sprintf_s(myText, "%d", count);
	//putText(input_image, myText, Point(200,100), 3, 1, Scalar(0, 0, 255), 1, 8);

	if (red_find == 0)
	{
		if (count > 2500)
		{
			//speed = 0;
			DesireSpeed_Write(0);
			red_find = 1;

			Winker_Write(ALL_ON);
			opencv_steering_control = 0;
			//usleep(500000);
			//Winker_Write(ALL_OFF);
			//usleep(400000);
			layer_1=65;
			layer_2=layer_1-2;
			layer_3=layer_2-2;

			/*int left1_start=0;
			int left1_end=60;
			  
			int left2_start=0;
			int left2_end=60;
			  
			int left3_start=0;
			int left3_end=60;*/


		}
	}
	else if (red_find == 1)
	{
		if (count < 1000)
		{
			//speed = 0;
			CameraYServoControl_Write(1660);
			
			usleep(200000);
			//*pointer_steering_control = 1;
			usleep(100000);
			DesireSpeed_Write(100);
			Winker_Write(ALL_OFF);

			
			red_find = 2;
			return 1;
		}
	}
	//1~2ms
	return 0;
}









// 2020-10-11 01 :10 AM 
//void -> int

int stop_line()
{

	char line_sensor=LineSensor_Read();
	if(line_sensor==0)
	{
		DesireSpeed_Write(0);
		Alarm_Write(ON);
		usleep(400000);
		Alarm_Write(OFF);
		return 1;
	}
	else 
	{

	}
	return 0;
}




int round_rotary(Mat input_image, Mat& img_out)
{
	Mat img;
	Mat gray_img;
	Mat mask = getStructuringElement(MORPH_RECT, Size(3, 3), Point(1, 1));
	input_image.copyTo(img);

	if( round_rotary_step == 0)
	{
		if(stop_line() == 1)
		{
			round_rotary_step++;
		}
		return 0;
	}
	else if(round_rotary_step == 1)
	{
		CameraYServoControl_Write(1580);
		CameraXServoControl_Write(1850);
		usleep(1000000);
		round_rotary_step ++;
		return 0;
	}
	else if (round_rotary_step < 10)
	{
		usleep(10000);
		round_rotary_step++;
		return 0;
	}
	else if( round_rotary_step == 10)
	{
		cvtColor(img, gray_img, COLOR_RGB2GRAY);

		Mat sub_cam;

		gray_img = gray_img / 200;
		gray_img = gray_img * 200;
		//imshow("sub_cam", img_small);

		if (img_pre.empty())
		{
			gray_img.copyTo(img_pre);
			round_rotary_step++;
			return 0;
		}
	}
	else if( round_rotary_step == 11)
	{
		if (safety_counter > 19)				// 약 2초정도 안전하다고 측정되면 안전하다고 결론을 내림
		{
			CameraYServoControl_Write(1660);
			usleep(40000);
			CameraXServoControl_Write(1500);
			usleep(40000);			
			round_rotary_step ++;		
			return 0;
		}

		cvtColor(img, gray_img, COLOR_RGB2GRAY);

		Mat sub_cam;

		gray_img = gray_img / 200;
		gray_img = gray_img * 200;
		//imshow("sub_cam", img_small);

		sub_cam = (gray_img - img_pre);			// 움직임을 측정하기 위해서 현재이미지에서 이전 프레임을 뺀다.
		sub_cam = sub_cam * 50;						// 움직인 위치의 픽셀들을 밝게 하기 위해 수를 곱해준다.

		//imshow("cam1", sub_cam);
		erode(sub_cam, sub_cam, mask, Point(-1, -1), 1);	// 노이즈 제거를 위해 사용
		dilate(sub_cam, sub_cam, mask, Point(-1, -1), 1);	// Opening, 실제 픽셀은 체크해야 되니깐 확대해준다.


		int white_pixel_counter = 0;
		for (int i = 0; i < sub_cam.rows; i++)
		{
			uchar* pointer_row = sub_cam.ptr<uchar>(i);		// Add 0807 // .at 을 .ptr 로 변경// 
			for (int j = 0; j < sub_cam.cols;j++)
			{
				if (pointer_row[j] > 0)
					white_pixel_counter++;
			}
		}
		if (white_pixel_counter < 1000)				// 변화가 있는 픽셀들이 1000개 이하면 움직이는 물체가 상대적으로 멀리있다고 판단
		{
			safety_counter++;						// 안전 카운트를 올리고
		}
		else
		{
			safety_counter = 0;					// 변화가 많다면 움직이는 물체가 가까이 있으므로 안전하지 않음
		}

		



		gray_img.copyTo(img_pre);
		cvtColor(sub_cam, sub_cam, COLOR_GRAY2BGR);
		char myText[20];
			
			sprintf(myText, "%d", safety_counter);
			putText(sub_cam, myText, Point(120,60), 3, 2, Scalar(0,0,255), 1, 8);


		sub_cam.copyTo(img_out);

		return 0;
		
	}
	else if(round_rotary_step<18)
	{
		usleep(10000);
		round_rotary_step++;
	}
	else if(round_rotary_step == 18)
	{
		DesireSpeed_Write(150);
		round_rotary_step = 20;
		return 1;
	}


	// if ((CameraYServoControl_Read() != 1580) && (CameraXServoControl_Read() != 1850))
	// {
	// 	CameraYServoControl_Write(1580);
	// 	CameraXServoControl_Write(1850);
	// 	usleep(1000000);
	// }



	// input_image.copyTo(img);
	
	// cvtColor(img, gray_img, COLOR_RGB2GRAY);

	// Mat sub_cam;

	// gray_img = gray_img / 200;
	// gray_img = gray_img * 200;
	// //imshow("sub_cam", img_small);

	// if (img_pre.empty())
	// {
	// 	gray_img.copyTo(img_pre);
	// 	return;
	// }

	// sub_cam = (gray_img - img_pre);			// 움직임을 측정하기 위해서 현재이미지에서 이전 프레임을 뺀다.
	// sub_cam = sub_cam * 50;						// 움직인 위치의 픽셀들을 밝게 하기 위해 수를 곱해준다.

	// //imshow("cam1", sub_cam);
	// erode(sub_cam, sub_cam, mask, Point(-1, -1), 1);	// 노이즈 제거를 위해 사용
	// dilate(sub_cam, sub_cam, mask, Point(-1, -1), 1);	// Opening, 실제 픽셀은 체크해야 되니깐 확대해준다.

	// //imshow("cam2", sub_cam);
	// int white_pixel_counter = 0;
	// for (int i = 0; i < sub_cam.rows; i++)
	// {
	// 	uchar* pointer_row = sub_cam.ptr<uchar>(i);		// Add 0807 // .at 을 .ptr 로 변경// 
	// 	for (int j = 0; j < sub_cam.cols;j++)
	// 	{
	// 		if (pointer_row[j] > 0)
	// 			white_pixel_counter++;
	// 	}
	// }
	// if (white_pixel_counter < 1000)				// 변화가 있는 픽셀들이 1000개 이하면 움직이는 물체가 상대적으로 멀리있다고 판단
	// {
	// 	safety_counter++;						// 안전 카운트를 올리고

	// 	if (*pointer_cout_control == 1)
	// 		cout << "safety : " << safety_counter*5<<"%"<<endl;
		
	// }
	// else
	// {
	// 	safety_counter = 0;					// 변화가 많다면 움직이는 물체가 가까이 있으므로 안전하지 않음
	// }

	// if (safety_counter > 19)				// 약 2초정도 안전하다고 측정되면 안전하다고 결론을 내림
	// {
	// 	if (*pointer_cout_control == 1)
	// 		cout << "safe" << endl;
	// 	safety_counter = 0;
	// }

	// if (*pointer_cout_control == 1)
	// 	cout << "white_pixel_counter : " << white_pixel_counter << endl;

	// gray_img.copyTo(img_pre);
	// cvtColor(sub_cam, sub_cam, COLOR_GRAY2BGR);
	// sub_cam.copyTo(*img_out);

	return 0;
}






















void traffic_sign(Mat input_image, Mat* img_out)
{

	if (CameraYServoControl_Read() == 1580)
	{
		if (cam_counter > 30)
		{

			Mat img, img_roi, img_roi_filtered, img_blur, img_blur_gray, img_threshold, img_edge;
			Rect roi(Point(0, 40), Point(319, 120));


			input_image.copyTo(img);
			img_roi = img(roi);
			filter_white_colors(img_roi, img_roi_filtered);
			GaussianBlur(img_roi_filtered, img_blur, Size(9, 9), 0, 0);
			cvtColor(img_blur, img_blur_gray, COLOR_BGR2GRAY);
			threshold(img_blur_gray, img_threshold, 90, 255, THRESH_BINARY);
			Canny(img_threshold, img_edge, 120, 200, 3);

			cout << "image_end" << endl;
			int middle_num = 0;
			if (traffic_find)
			{


				for (int j = 5; j < img_edge.rows; j++)
				{
					for (int i = 7; i < img_edge.cols; i++)
					{
						if (img_edge.at<uchar>(j, i) > 10)
						{
							upper = Point(i, j);
							j = img_edge.rows;
							break;
						}

					}
				}
				for (int j = upper.y + 5; j < upper.y + 35; j++)
				{
					lower = Point(upper.x, upper.y + 28);
					int counter = 0;
					for (int i = 7; i < img_edge.cols; i++)
					{
						if (img_edge.at<uchar>(j, i) > 10)
						{
							counter++;
						}

					}
					if (counter == 0)
					{
						lower = Point(upper.x, j);
						j = img_edge.rows;
						break;
					}
				}


				for (int i = 7; i < img_edge.cols; i++)
				{
					if (img_edge.at<uchar>((upper.y + lower.y) / 2, i) > 10)
					{
						middle[middle_num] = Point(i, (upper.y + lower.y) / 2);
						middle_num++;

						if (middle_num > 8)
							break;
					}
				}

				red = Rect(Point(middle[0].x, upper.y), Point(middle[1].x, lower.y));
				yellow = Rect(Point(middle[2].x, upper.y), Point(middle[3].x, lower.y));
				green_left = Rect(Point(middle[4].x, upper.y), Point(middle[5].x, lower.y));
				green_right = Rect(Point(middle[6].x, upper.y), Point(middle[7].x, lower.y));


				traffic_find = 0;
				cout << "find_end" << endl;
			}
			for (int i = 0; i < middle_num; i++)
			{
				circle(img_edge, middle[i], 1, Scalar::all(255), 1, 8);
			}


			//line(img_edge, upper, lower, Scalar::all(255), 1, 8);


			cout << "test1" << endl;
			rectangle(img_edge, red, Scalar::all(255), 1, 8);
			rectangle(img_edge, yellow, Scalar::all(255), 1, 8);
			rectangle(img_edge, green_left, Scalar::all(255), 1, 8);
			rectangle(img_edge, green_right, Scalar::all(255), 1, 8);
			cout << "test2" << endl;
			Mat green_left_img = img_roi(green_left);
			Mat green_right_img = img_roi(green_right);
			Mat green_left_img_gray, green_right_img_gray;
			Mat green_left_threshold;
			Mat green_right_threshold;
			cout << "test3" << endl;
			cvtColor(green_left_img, green_left_img_gray, COLOR_BGR2GRAY);
			cvtColor(green_right_img, green_right_img_gray, COLOR_BGR2GRAY);
			cout << "test4" << endl;
			threshold(green_left_img_gray, green_left_threshold, 50, 255, THRESH_BINARY);
			threshold(green_right_img_gray, green_right_threshold, 50, 255, THRESH_BINARY);
			cout << "test5" << endl;



			////imshow("green_left", green_left_img);
			////imshow("green_right", green_right_img);




			int green_left_counter = 0, green_right_counter = 0;
			// green left
			if (green_left_threshold.at<uchar>(int(green_left_threshold.rows / 2) - 1, int(green_left_threshold.cols / 2) - 1) > 5)
				green_left_counter++;
			if (green_left_threshold.at<uchar>(int(green_left_threshold.rows / 2) - 1, int(green_left_threshold.cols / 2)) > 5)
				green_left_counter++;
			if (green_left_threshold.at<uchar>(int(green_left_threshold.rows / 2) - 1, int(green_left_threshold.cols / 2) + 1) > 5)
				green_left_counter++;
			if (green_left_threshold.at<uchar>(int(green_left_threshold.rows / 2), int(green_left_threshold.cols / 2) - 1) > 5)
				green_left_counter++;
			if (green_left_threshold.at<uchar>(int(green_left_threshold.rows / 2), int(green_left_threshold.cols / 2)) > 5)
				green_left_counter++;
			if (green_left_threshold.at<uchar>(int(green_left_threshold.rows / 2), int(green_left_threshold.cols / 2) + 1) > 5)
				green_left_counter++;
			if (green_left_threshold.at<uchar>(int(green_left_threshold.rows / 2) + 1, int(green_left_threshold.cols / 2) - 1) > 5)
				green_left_counter++;
			if (green_left_threshold.at<uchar>(int(green_left_threshold.rows / 2) + 1, int(green_left_threshold.cols / 2)) > 10)
				green_left_counter++;
			if (green_left_threshold.at<uchar>(int(green_left_threshold.rows / 2) + 1, int(green_left_threshold.cols / 2) + 1) > 5)
				green_left_counter++;

			// green right
			if (green_right_threshold.at<uchar>(int(green_right_threshold.rows / 2) - 1, int(green_right_threshold.cols / 2) - 1) > 5)
				green_right_counter++;
			if (green_right_threshold.at<uchar>(int(green_right_threshold.rows / 2) - 1, int(green_right_threshold.cols / 2)) > 5)
				green_right_counter++;
			if (green_right_threshold.at<uchar>(int(green_right_threshold.rows / 2) - 1, int(green_right_threshold.cols / 2) + 1) > 5)
				green_right_counter++;
			if (green_right_threshold.at<uchar>(int(green_right_threshold.rows / 2), int(green_right_threshold.cols / 2) - 1) > 5)
				green_right_counter++;
			if (green_right_threshold.at<uchar>(int(green_right_threshold.rows / 2), int(green_right_threshold.cols / 2)) > 5)
				green_right_counter++;
			if (green_right_threshold.at<uchar>(int(green_right_threshold.rows / 2), int(green_right_threshold.cols / 2) + 1) > 5)
				green_right_counter++;
			if (green_right_threshold.at<uchar>(int(green_right_threshold.rows / 2) + 1, int(green_right_threshold.cols / 2) - 1) > 5)
				green_right_counter++;
			if (green_right_threshold.at<uchar>(int(green_right_threshold.rows / 2) + 1, int(green_right_threshold.cols / 2)) > 10)
				green_right_counter++;
			if (green_right_threshold.at<uchar>(int(green_right_threshold.rows / 2) + 1, int(green_right_threshold.cols / 2) + 1) > 5)
				green_right_counter++;

			cout << "test" << endl;



			//resize(img_edge, img_edge, Size(320, 180));
			cvtColor(img_edge, img_edge, COLOR_GRAY2BGR);
			img_edge.copyTo(*img_out);

			cout << "green_left  : " << green_left_counter << endl;
			cout << "green_right  : " << green_right_counter << endl;

			if (green_left_counter > 6 && green_right_counter < 3)
			{
				cout << "turn left" << endl;
				traffic_turn_left();
				return;
			}
			else if (green_right_counter > 6 && green_left_counter < 3)
			{
				cout << "turn right" << endl;
				traffic_turn_right();
				return;
			}
		}
		else
		{
			cam_counter++;
			return;
		}
	}
	else {
	CameraYServoControl_Write(1580);
	cout << "set to servo Y 1580" << endl;
	}


	return;
}












Mat RoI_triangle(Mat img)	
{
	Mat mask;
	mask = img.zeros(img.size(), 0);

	double width, height;

	width = img.size().width;
	height = img.size().height;

	Point triangle_points[1][4];


	triangle_points[0][0] = Point(int(width*(0.015)), int(height));
	triangle_points[0][1] = Point(int(width*(0.984)), int(height));
	triangle_points[0][2] = Point(int(width*(0.85)), int(height*(0.138)));
	triangle_points[0][3] = Point(int(width*(0.15)), int(height*(0.138)));


	const Point* Array_triangle[1] = { triangle_points[0] };
	int npt[] = { 4 };

	fillPoly(mask, Array_triangle, npt, 1, Scalar::all(255), 8);

	Mat img_tri;
	bitwise_and(img, mask, img_tri);

	return img_tri;
}

Mat FIND_LINE(Mat img1, Mat img2)
{
	Mat line_img;

	vector<Vec4i> lines;
	HoughLinesP(img2, lines, 1, 2 * CV_PI / 180, 100, 50, 10);
	for (size_t i = 0; i < lines.size(); i++)
	{
		Vec4i l = lines[i];
		double angle = atan2(l[3] - l[1], l[2] - l[0]) * 180.0 / CV_PI;

		//if (angle < 5 && angle >= -5)
		//{
		//	// Á¤Áö¼±Àº ÆÄ¶õ»ö
		//	//cout << l[0] << "," << l[1] << "," << l[2] << "," << l[3] << endl;
		//	line(img1, Point(l[0], l[1]), Point(l[2], l[3]), Scalar(255, 0, 0), 8, 1);
		//}
		if (angle > 35 && angle < 80)
		{
			line(img1, Point(l[0], l[1]), Point(l[2], l[3]), Scalar(0, 0, 255), 3);
			Hough_line_val = 1;
		}
		else if (angle > -80 && angle < -35)
		{
			line(img1, Point(l[0], l[1]), Point(l[2], l[3]), Scalar(0, 0, 255), 3);
			Hough_line_val = 1;
		}
		//ÀÏ¹Ý Â÷¼±Àº »¡°£»ö
		else
		{
			Hough_line_val = 0;
		}


	}


	return img1;
}




void capture(Mat input_img)
{
	Mat img;
	input_img.copyTo(img);

	stringstream num_string;
	num_string << capture_num;

	string str1,str2, str3;

	str2 = num_string.str();

	str1 = "capture";
	str3 = str1 + str2 + ".jpg";

	imwrite(str3, img);
	cout << "screen_capture_succeed" << capture_num<< endl;

	capture_num++;
	//imwrite("frame.jpg", frame);
	
	return;
}





























void fine_stopline(Mat input_img)
{
  Mat img;
  input_img.copyTo(img);
  /*
    circle(img_bgr, Point(260, 120),3,Scalar(0,0,255));
  circle(img_bgr, Point(280, 120),3,Scalar(0,0,255));
  circle(img_bgr, Point(300, 120),3,Scalar(0,0,255));
  circle(img_bgr, Point(320, 120),3,Scalar(0,0,255));
  circle(img_bgr, Point(340, 120),3,Scalar(0,0,255));
  circle(img_bgr, Point(360, 120),3,Scalar(0,0,255));
  circle(img_bgr, Point(380, 120),3,Scalar(0,0,255));
  */
  int stop_count=0;
  
  if(img.at<uchar>(120,260)>150)
    stop_count ++;
  if(img.at<uchar>(120,280)>150)
    stop_count ++;  
  if(img.at<uchar>(120,300)>150)
    stop_count ++; 
  if(img.at<uchar>(120,320)>150)
    stop_count ++;  
  if(img.at<uchar>(120,340)>150)
    stop_count ++;  
  if(img.at<uchar>(120,360)>150)
    stop_count ++;  
  if(img.at<uchar>(120,380)>150)
    stop_count ++;

  if(stop_count>5)
  {
    cout<<"Detect stop line"<<endl;
   // sang=int(255);
  }


/*        
	int start_sign =1;
	
	cout<<"Enter 'esc' to run"<<endl;
	
      while(start_sign)
      {
	  if(waitKey(0)==27)
	  {
	    start_sign=0;
	  }
	}
*/	
	
	
    return;
}










void OpenCV_load_file(char* file, unsigned char* outBuf, int nw, int nh)
{
    Mat srcRGB;
    Mat dstRGB(nh, nw, CV_8UC3, outBuf);

    srcRGB = imread(file, CV_LOAD_IMAGE_COLOR); // rgb
    //cvtColor(srcRGB, srcRGB, CV_RGB2BGR);

    cv::resize(srcRGB, dstRGB, cv::Size(nw, nh), 0, 0, CV_INTER_LINEAR);
}

/**
  * @brief  To convert format from BGR to RGB.
  * @param  inBuf: buffer pointer of BGR image
             w: width value of the buffers
             h : height value of the buffers
             outBuf : buffer pointer of RGB image
  * @retval none
  */
void OpenCV_Bgr2RgbConvert(unsigned char* inBuf, int w, int h, unsigned char* outBuf)
{
    Mat srcRGB(h, w, CV_8UC3, inBuf);
    Mat dstRGB(h, w, CV_8UC3, outBuf);

    cvtColor(srcRGB, dstRGB, CV_BGR2RGB);
}

/**
  * @brief  Detect faces on loaded image and draw circles on the faces of the loaded image.
  * @param  file: pointer for load image file in local path
             outBuf: buffer pointer to draw circles on the detected faces
             nw : width value of the destination buffer
             nh : height value of the destination buffer
  * @retval none
  */

/*
void OpenCV_face_detection(char* file, unsigned char* outBuf, int nw, int nh)
{
    Mat srcRGB = imread(file, CV_LOAD_IMAGE_COLOR);
    Mat dstRGB(nh, nw, CV_8UC3, outBuf);
    
    // Load Face cascade (.xml file)
    CascadeClassifier face_cascade;
    face_cascade.load( "haarcascade_frontalface_alt.xml" );
 
    // Detect faces
    std::vector<Rect> faces;
    face_cascade.detectMultiScale( srcRGB, faces, 1.1, 2, 0|CV_HAAR_SCALE_IMAGE, Size(30, 30) );
    
    // Draw circles on the detected faces
    for( int i = 0; i < faces.size(); i++ )
    {
        Point center( faces[i].x + faces[i].width*0.5, faces[i].y + faces[i].height*0.5 );
        ellipse( srcRGB, center, Size( faces[i].width*0.5, faces[i].height*0.5), 0, 0, 360, Scalar( 255, 0, 255 ), 4, 8, 0 );
    }
 
    cv::resize(srcRGB, dstRGB, cv::Size(nw, nh), 0, 0, CV_INTER_LINEAR);
}
*/
/**
  * @brief  To bind two images on destination buffer.
  * @param  file1: file path of first image to bind
             file2: file path of second image to bind
             outBuf : destination buffer pointer to bind
             nw : width value of the destination buffer
             nh : height value of the destination buffer
  * @retval none
  */










  ////////// 돌발 정지 신호 예전 코드 //////////////////////
  //
  //
  //void find_stop_sign(Mat input_image)
  //{
  //	float red_percent=0;
  //	int count=0;
  //	Mat img_bgr;
  //	Mat img_hsv;
  //
  //	input_image.copyTo(img_bgr);
  //	cvtColor(img_bgr, img_hsv, COLOR_BGR2HSV);
  //
  //	Mat red_mask, red_image;
  //	Mat dark_red_mask, dark_red_image;
  //
  //	Scalar lower_red = Scalar(0, 50, 50);
  //	Scalar upper_red = Scalar(3,205,255);
  //	Scalar lower_dark_red = Scalar(173, 90, 33);
  //	Scalar upper_dark_red = Scalar(180, 255, 255);
  //
  //	
  //	inRange(img_hsv, lower_red, upper_red, red_mask);
  //	bitwise_and(img_bgr, img_bgr, red_image, red_mask);
  //	//grayscale
  //	cvtColor(red_image, red_image, COLOR_BGR2GRAY);
  //
  //	
  //	inRange(img_hsv, lower_dark_red, upper_dark_red, dark_red_mask);
  //	bitwise_and(img_bgr, img_bgr, dark_red_image, dark_red_mask);
  //	//grayscale
  //	cvtColor(dark_red_image, dark_red_image, COLOR_BGR2GRAY);
  //	
  //	red_image |= dark_red_image;
  //	threshold(red_image, red_image, 10, 255, THRESH_BINARY);
  //
  //	
  //	for (int j = 0; j < red_image.rows; j++)					
  //	{
  //		for (int i = 0; i < red_image.cols; i++)				
  //		{
  //			if (red_image.at<uchar>(j, i) > 0)				
  //			{
  //				count++;
  //			}
  //
  //		}
  //	}
  //
  //
  //	red_percent = ((float)count / (red_image.rows*red_image.cols) * 100);
  //	
  ///*
  //input find stop sign code
  //*/
  //
  //	cout<<"red_percent : "<<red_percent<<endl;
  //
  //
  //
  //	if(red_find==0)
  //	{
  //		if (red_percent>8)
  //		{
  //			//speed = 0;
  //			DesireSpeed_Write(0);
  //			red_find=1;
  //		}
  //	}
  //	else if(red_find==1)
  //	{
  //		if (red_percent<4)
  //		{
  //			//speed = 0;
  //			DesireSpeed_Write(100);
  //			red_find=2;
  //		}
  //	}
  //	
  //	return;
  //}
  ////////// 돌발 정지 신호 예전 코드 //////////////////////















/*
void OpenCV_binding_image(char* file1, char* file2, unsigned char* outBuf, int nw, int nh)
{
    Mat srcRGB = imread(file1, CV_LOAD_IMAGE_COLOR);
    Mat srcRGB2 = imread(file2, CV_LOAD_IMAGE_COLOR);
    Mat dstRGB(nh, nw, CV_8UC3, outBuf);

    cv::resize(srcRGB2, srcRGB2, cv::Size(srcRGB2.cols/1.5, srcRGB2.rows/1.5));
    cv::Point location = cv::Point(280, 220);
    for (int y = std::max(location.y, 0); y < srcRGB.rows; ++y)
    {
        int fY = y - location.y;
        if (fY >= srcRGB2.rows)
            break;
        
        for (int x = std::max(location.x, 0); x < srcRGB.cols; ++x)
        {
            int fX = x - location.x;
            if (fX >= srcRGB2.cols)
            break;
            
            double opacity = ((double)srcRGB2.data[fY * srcRGB2.step + fX * srcRGB2.channels() + 3]) / 255.;
            for (int c = 0; opacity > 0 && c < srcRGB.channels(); ++c)
            {
                unsigned char overlayPx = srcRGB2.data[fY * srcRGB2.step + fX * srcRGB2.channels() + c];
                unsigned char srcPx = srcRGB.data[y * srcRGB.step + x * srcRGB.channels() + c];
                srcRGB.data[y * srcRGB.step + srcRGB.channels() * x + c] = srcPx * (1. - opacity) + overlayPx * opacity;
            }
        }
    }
 
    cv::resize(srcRGB, dstRGB, cv::Size(nw, nh), 0, 0, CV_INTER_LINEAR);
}
*/
/**
  * @brief  Apply canny edge algorithm and draw it on destination buffer.
  * @param  file: pointer for load image file in local path
             outBuf: destination buffer pointer to apply canny edge
             nw : width value of destination buffer
             nh : height value of destination buffer
  * @retval none
  */
void OpenCV_canny_edge_image(char* file, unsigned char* outBuf, int nw, int nh)
{
    Mat srcRGB = imread(file, CV_LOAD_IMAGE_COLOR);
    Mat srcGRAY;
    Mat dstRGB(nh, nw, CV_8UC3, outBuf);

    cvtColor(srcRGB, srcGRAY, CV_BGR2GRAY);
     // ÄÉŽÏ ŸË°íž®Áò Àû¿ë
    cv::Mat contours;
    cv::Canny(srcGRAY, // ±×·¹ÀÌ·¹º§ ¿µ»ó
        contours, // °á°ú ¿Ü°ûŒ±
        125,  // ³·Àº °æ°è°ª
        350);  // ³ôÀº °æ°è°ª

    // ³ÍÁŠ·Î È­ŒÒ·Î ¿Ü°ûŒ±À» Ç¥ÇöÇÏ¹Ç·Î Èæ¹é °ªÀ» ¹ÝÀü
    //cv::Mat contoursInv; // ¹ÝÀü ¿µ»ó
    //cv::threshold(contours, contoursInv, 128, 255, cv::THRESH_BINARY_INV);
    // ¹à±â °ªÀÌ 128ºžŽÙ ÀÛÀžžé 255°¡ µÇµµ·Ï Œ³Á€
 
    cvtColor(contours, contours, CV_GRAY2BGR);
    
    cv::resize(contours, dstRGB, cv::Size(nw, nh), 0, 0, CV_INTER_LINEAR);
}

/**
  * @brief  Detect the hough and draw hough on destination buffer.
  * @param  srcBuf: source pointer to hough transform
             iw: width value of source buffer
             ih : height value of source buffer
             outBuf : destination pointer to hough transform
             nw : width value of destination buffer
             nh : height value of destination buffer
  * @retval none
  */
void OpenCV_hough_transform(unsigned char* srcBuf, int iw, int ih, unsigned char* outBuf, int nw, int nh)
{
    Scalar lineColor = cv::Scalar(255,255,255);
    
    Mat dstRGB(nh, nw, CV_8UC3, outBuf);
    
    Mat srcRGB(ih, iw, CV_8UC3, srcBuf);
    Mat resRGB(ih, iw, CV_8UC3);
    //cvtColor(srcRGB, srcRGB, CV_BGR2BGRA);

    // Ä³ŽÏ ŸË°íž®Áò Àû¿ë
    cv::Mat contours;
    cv::Canny(srcRGB, contours, 125, 350);
    
    // Œ± °šÁö À§ÇÑ ÇãÇÁ º¯È¯
    std::vector<cv::Vec2f> lines;
    cv::HoughLines(contours, lines, 1, pi/180, // ŽÜ°èº° Å©±â (1°ú ¥ð/180¿¡Œ­ ŽÜ°èº°·Î °¡ŽÉÇÑ žðµç °¢µµ·Î ¹ÝÁöž§ÀÇ Œ±À» Ã£Àœ)
        80);  // ÅõÇ¥(vote) ÃÖŽë °³Œö
    
    // Œ± ±×ž®±â
    cv::Mat result(contours.rows, contours.cols, CV_8UC3, lineColor);
    //printf("Lines detected: %d\n", lines.size());

    // Œ± º€ÅÍžŠ ¹Ýº¹ÇØ Œ± ±×ž®±â
    std::vector<cv::Vec2f>::const_iterator it= lines.begin();
    while (it!=lines.end()) 
    {
        float rho = (*it)[0];   // Ã¹ ¹øÂ° ¿äŒÒŽÂ rho °Åž®
        float theta = (*it)[1]; // µÎ ¹øÂ° ¿äŒÒŽÂ µšÅž °¢µµ
        
        if (theta < PI/4. || theta > 3.*PI/4.) // ŒöÁ÷ Çà
        {
            cv::Point pt1(rho/cos(theta), 0); // Ã¹ Çà¿¡Œ­ ÇØŽç Œ±ÀÇ ±³Â÷Á¡   
            cv::Point pt2((rho-result.rows*sin(theta))/cos(theta), result.rows);
            // ž¶Áöž· Çà¿¡Œ­ ÇØŽç Œ±ÀÇ ±³Â÷Á¡
            cv::line(srcRGB, pt1, pt2, lineColor, 1); // ÇÏŸá Œ±Àž·Î ±×ž®±â

        } 
        else // ŒöÆò Çà
        { 
            cv::Point pt1(0,rho/sin(theta)); // Ã¹ ¹øÂ° ¿­¿¡Œ­ ÇØŽç Œ±ÀÇ ±³Â÷Á¡  
            cv::Point pt2(result.cols,(rho-result.cols*cos(theta))/sin(theta));
            // ž¶Áöž· ¿­¿¡Œ­ ÇØŽç Œ±ÀÇ ±³Â÷Á¡
            cv::line(srcRGB, pt1, pt2, lineColor, 1); // ÇÏŸá Œ±Àž·Î ±×ž®±â
        }
        //printf("line: rho=%f, theta=%f\n", rho, theta);
        ++it;
    }

    cv::resize(srcRGB, dstRGB, cv::Size(nw, nh), 0, 0, CV_INTER_LINEAR);
}


void jinhyeong_test(unsigned char* srcBuf, int iw, int ih, unsigned char* outBuf, int nw, int nh)
{

  Scalar lineColor = cv::Scalar(255,255,255);

    Mat dstRGB(nh, nw, CV_8UC3, outBuf);

    Mat srcRGB(ih, iw, CV_8UC3, srcBuf);
    Mat resRGB(ih, iw, CV_8UC3, lineColor);
	Mat Blur;
	srcRGB.copyTo(Blur);
    //cvtColor(srcRGB, srcRGB, CV_BGR2BGRA);

    // Ä³ŽÏ ŸË°íž®Áò Àû¿ë
    //cv::Mat contours;
    //cv::Canny(srcRGB, contours, 55, 250);
	cv::GaussianBlur(Blur,Blur,Size(3,3),0,0);
	

 line(srcRGB, Point(0,0), Point(200,100), cv::Scalar(255,255,0), 5);
 cv::resize(srcRGB, dstRGB, cv::Size(nw, nh), 1, 0, CV_INTER_LINEAR); //blur oder
 //dstRGB=srcRGB;				   
 //srcRGB.copyTo(dstRGB);

}


/**
  * @brief  Merge two source images of the same size into the output buffer.
  * @param  src1: pointer to parameter of rgb32 image buffer
             src2: pointer to parameter of bgr32 image buffer
             dst : pointer to parameter of rgb32 output buffer
             w : width of src and dst buffer
             h : height of src and dst buffer
  * @retval none
  */
void OpenCV_merge_image(unsigned char* src1, unsigned char* src2, unsigned char* dst, int w, int h)
{
    Mat src1AR32(h, w, CV_8UC4, src1);
    Mat src2AR32(h, w, CV_8UC4, src2);
    Mat dstAR32(h, w, CV_8UC4, dst);

    cvtColor(src2AR32, src2AR32, CV_BGRA2RGBA);

    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            double opacity = ((double)(src2AR32.data[y * src2AR32.step + x * src2AR32.channels() + 3])) / 255.;
            for (int c = 0; opacity > 0 && c < src1AR32.channels(); ++c) {
                unsigned char overlayPx = src2AR32.data[y * src2AR32.step + x * src2AR32.channels() + c];
                unsigned char srcPx = src1AR32.data[y * src1AR32.step + x * src1AR32.channels() + c];
                src1AR32.data[y * src1AR32.step + src1AR32.channels() * x + c] = srcPx * (1. - opacity) + overlayPx * opacity;
            }
        }
    }

    memcpy(dst, src1AR32.data, w*h*4);
}

}




Mat follow(Mat input_img)
{
	Mat frame;
	input_img.copyTo(frame);

	//image diverse 3 section
	Mat left_image, right_image, mid_image;
	Rect left_roi(0, 0, frame.cols*0.35, frame.rows);
	rectangle(frame, left_roi, Scalar(0, 0, 255), 1);
	left_image = input_img(left_roi);

	Rect right_roi(frame.cols*0.65, 0, frame.cols*0.35, frame.rows);
	rectangle(frame, right_roi, Scalar(225, 0, 0), 1);
	right_image = input_img(right_roi);

	Rect mid_roi(frame.cols*0.35, 0, frame.cols*0.3, frame.rows);
	rectangle(frame, mid_roi, Scalar(0, 225, 0), 1);
	mid_image = input_img(mid_roi);


	//convert HSV
	Mat hsv_roi_R, hsv_roi_L, hsv_roi_M;
	cvtColor(left_image, hsv_roi_L, COLOR_BGR2HSV);
	cvtColor(right_image, hsv_roi_R, COLOR_BGR2HSV);
	cvtColor(mid_image, hsv_roi_M, COLOR_BGR2HSV);


	//mask

	Scalar lower_orange = Scalar(20, 20, 100);
	Scalar upper_orange = Scalar(40, 255, 255);

	Mat orange_mask, roi_L, roi_R, roi_M;

	inRange(hsv_roi_L, lower_orange, upper_orange, orange_mask);
	bitwise_and(hsv_roi_L, hsv_roi_L, roi_L, orange_mask);
	//bitwise_and(left_image, left_image, roi_L, orange_mask);
	cvtColor(roi_L, roi_L, COLOR_BGR2GRAY);
	threshold(roi_L, roi_L, 10, 255, THRESH_BINARY);


	inRange(hsv_roi_R, lower_orange, upper_orange, orange_mask);
	bitwise_and(hsv_roi_R, hsv_roi_R, roi_R, orange_mask);
	//bitwise_and(right_image, right_image, roi_R, orange_mask);
	cvtColor(roi_R, roi_R, COLOR_BGR2GRAY);
	threshold(roi_R, roi_R, 10, 255, THRESH_BINARY);


	inRange(hsv_roi_M, lower_orange, upper_orange, orange_mask);
	bitwise_and(hsv_roi_M, hsv_roi_M, roi_M, orange_mask);
	//bitwise_and(mid_image, mid_image, roi_M, orange_mask);	
	cvtColor(roi_M, roi_M, COLOR_BGR2GRAY);
	threshold(roi_M, roi_M, 10, 255, THRESH_BINARY);



	//pixel count
	int count_L = 0;
	for (int j = 0; j < roi_L.rows; j++)
	{
		for (int i = 0; i < roi_L.cols; i++)
		{
			if (roi_L.at<uchar>(j, i) > 0)
			{
				count_L++;
			}
		}
	}


	int count_R = 0;

	for (int j = 0; j < roi_R.rows; j++)
	{
		for (int i = 0; i < roi_R.cols; i++)
		{
			if (roi_R.at<uchar>(j, i) > 0)
			{
				count_R++;
			}

		}
	}


	int count_M = 0;

	for (int j = 0; j < roi_M.rows; j++)
	{
		for (int i = 0; i < roi_M.cols; i++)
		{
			if (roi_M.at<uchar>(j, i) > 0)
			{
				count_M++;
			}
		}
	}



	float L_color_percent = ((float)count_L / (left_image.rows*left_image.cols) * 100);
	float R_color_percent = ((float)count_R / (right_image.rows*right_image.cols) * 100);
	float M_color_percent = ((float)count_M / (mid_image.rows*mid_image.cols) * 100);

	//printf("count_L : %d \n count_R : %d\n count_M : %d\n", count_L, count_R, count_M);
	printf("Left ROI PERCENTAGE : %f \n\n", L_color_percent);
	printf("Right ROI PERCENTAGE : %f \n\n", R_color_percent);
	printf("Middle ROI PERCENTAGE : %f \n\n", M_color_percent);


	if (L_color_percent - R_color_percent > 15)
	{
		printf("turn LEFT\n");
		SteeringServoControl_Write(1800);
	}
	else if (R_color_percent - L_color_percent > 15)
	{
		printf("turn RIGHT\n");
		SteeringServoControl_Write(1200);
	}
	else if (R_color_percent < 10 && L_color_percent < 10)
	{
		printf("Go straight\n");
		SteeringServoControl_Write(1500);
	}


	//cvtColor(roi_M,roi_M,COLOR_GRAY2BGR);



	return frame;
}